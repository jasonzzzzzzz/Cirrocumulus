#!/usr/bin/env python3
"""Build and authenticate the label-free V7 Qwen LongBench-v2 manifest.

This CPU-only audit creates a fresh 131072-token partition.  It constructs
exact-context/question connected components over all 503 pinned benchmark
rows, excludes every component touching the frozen V6 117-row manifest,
requires singleton components and complete chat-rendered inputs, and selects a
fresh 117-row qualification/development/confirmation partition.  It records
only hashes, released metadata, lengths, and deterministic prompt positions;
benchmark answers never enter the emitted manifest.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sievelib import tasks_longbench_v2 as LB  # noqa: E402


MANIFEST_VERSION = "longbench_v2_sieve_v7_qwen131072_manifest_v1"
MODEL_TAG = "qwen3-30b-a3b-2507"
MODEL_ID = "Qwen/Qwen3-30B-A3B-Instruct-2507"
MODEL_REVISION = "0d7cf23991f47feeb3a57ecb4c9cee8ea4a17bfe"
TOKENIZER_REVISION = MODEL_REVISION
TRANSFORMERS_VERSION = "5.16.1"
TOKENIZERS_VERSION = "0.23.1"
CHAT_TEMPLATE_SHA256 = (
    "64f85b198065d0fba2a81f37e10ed68161ce2c19a754c7100e67e0ca2ee9c326"
)
CONTEXT_WINDOW = 131_072
ENABLE_THINKING = False
SCAFFOLD_TOKEN_IDS = (785, 4396, 4226, 374, 320)
CHOICE_BRANCH_IDS = {"A": 32, "B": 33, "C": 34, "D": 35}
CONTENT_GROUPS = ("question", "A", "B", "C", "D")
MAX_CONTENT_TOKENS_PER_GROUP = 8

# These namespaces are frozen before any benchmark outcome is observed.
COMPONENT_ID_NAMESPACE = b"longbench_v2_sieve_v7_qwen131072_component_v1\0"
SELECTION_NAMESPACE = b"longbench_v2_sieve_v7_qwen131072_selection_v1\0"

SPLITS = ("qualification", "development", "confirmation")
SPLIT_ROWS = {"qualification": 20, "development": 52, "confirmation": 45}
EXPECTED_DATASET_ROWS = 503
EXPECTED_ALL_COMPONENTS = 447
EXPECTED_LEGACY_ROWS = 117
EXPECTED_TAINTED_COMPONENTS = 108
EXPECTED_TAINTED_ROWS = 121
EXPECTED_UNTAINTED_SINGLETONS = 324
EXPECTED_ELIGIBLE_ROWS = 152
SELECTED_ROWS = sum(SPLIT_ROWS.values())

LEGACY_MANIFEST_VERSION = "longbench_v2_sieve_v6_qwen30_manifest_v1"
LEGACY_MANIFEST_ID = (
    "h0_measurement/bugs/9_sota_eviction_baselines/"
    "longbench_v2_qwen30_manifest.json"
)
LEGACY_MANIFEST_CONTENT_SHA256 = (
    "c6a951bb5433dd5c918ca6c8c964eb2ed4a4c26f9a079f53fb9111e9a3279f5b"
)
LEGACY_MANIFEST_FILE_SHA256 = (
    "a85b94fe636ce00ccddbc4ffa0f371f4d666aa0aa02750841444a811250a1946"
)

SNAPSHOT_FILE_COUNT = 24
SNAPSHOT_INVENTORY_SHA256 = (
    "4ac169930fba4989c196232eae1528dfea473cc695a439061741aa61df3510c2"
)
SNAPSHOT_METADATA_SHA256 = {
    "config.json": "a1ee086a68d0cbfc87316da00ba4b8507bd1292978108e2496201a30a450f438",
    "generation_config.json": "19d306dd769db12a9d710b44cf7f83b635efbe5166b84fb4358a08fb7d88bb53",
    "merges.txt": "599bab54075088774b1733fde865d5bd747cbcc7a547c5bc12610e874e26f5e3",
    "model.safetensors.index.json": "8dde190b862c7c80ec7403c6495de00c60bbaf246ed479cee4506284989c584c",
    "tokenizer.json": "aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4",
    "tokenizer_config.json": "a62ff0a2472a0fa1b8eaabcb57c59b58afa42a22831dc141400b6e0cf2b65ce3",
    "vocab.json": "ca10d7e9fb3ed18575dd1e277a2579c16d108e32f27439684afa0e10b1440910",
}
# Filled only after focused tests pass and the canonical file is generated.
FROZEN_MANIFEST_CONTENT_SHA256 = "9692c79c22888820fed069ba45be93fa32059e35a148f4524530e4c6b4dfaa84"
FROZEN_MANIFEST_FILE_SHA256 = "27757f06ff49ffa232a20e59866e0779689b0cdd5f20db23106cd42c44750a1c"

EXAMPLE_KEYS = {
    "id", "group_id", "context_hash", "question_hash", "metadata", "split",
    "input_tokens", "prompt_token_hash", "content_token_positions",
}
FORBIDDEN_EXAMPLE_KEYS = {"answer", "gold", "label", "target"}


class V7ManifestError(ValueError):
    """A V7 source, tokenizer, or manifest violates the frozen contract."""


def _fail(message: str) -> None:
    raise V7ManifestError(message)


def _same(expected: Any, actual: Any, description: str) -> None:
    if expected != actual:
        _fail(f"{description}: expected {expected!r}, got {actual!r}")


def sha256_file(path: str | Path) -> str:
    return LB.sha256_file(path)


def sha256_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def token_hash(tokens: Sequence[int]) -> str:
    values = [int(token) for token in tokens]
    if any(isinstance(raw, bool) or raw != value for raw, value in zip(tokens, values)):
        _fail("token hash input contains a non-integer token ID")
    payload = json.dumps(values, separators=(",", ":")).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")


def manifest_content_sha256(manifest: Mapping[str, Any]) -> str:
    payload = dict(manifest)
    payload.pop("content_sha256", None)
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def id_sha256(rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(
        f"{item_id}\n" for item_id in sorted(str(row["id"]) for row in rows)
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def id_token_sha256(rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(
        f"{item_id}\t{tokens}\n"
        for item_id, tokens in sorted(
            (str(row["id"]), int(row["input_tokens"])) for row in rows
        )
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def id_prompt_sha256(rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(
        f"{item_id}\t{prompt_hash}\n"
        for item_id, prompt_hash in sorted(
            (str(row["id"]), str(row["prompt_token_hash"])) for row in rows
        )
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def id_positions_sha256(rows: Iterable[Mapping[str, Any]]) -> str:
    records = sorted(
        (
            str(row["id"]),
            {
                group: [int(position) for position in row["content_token_positions"][group]]
                for group in CONTENT_GROUPS
            },
        )
        for row in rows
    )
    return hashlib.sha256(canonical_json(records)).hexdigest()


def _load_object(path: str | Path, label: str) -> dict[str, Any]:
    candidate = Path(path)
    if candidate.is_symlink() or not candidate.is_file():
        _fail(f"{label} must be an existing regular non-symlink file: {candidate}")
    try:
        value = json.loads(candidate.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _fail(f"cannot read {label} {candidate}: {exc}")
    if not isinstance(value, dict):
        _fail(f"{label} must contain one JSON object")
    return value


def authenticate_legacy_manifest(path: str | Path) -> tuple[dict[str, Any], str]:
    legacy = _load_object(path, "legacy V6 manifest")
    file_hash = sha256_file(path)
    _same(LEGACY_MANIFEST_FILE_SHA256, file_hash, "legacy manifest file SHA-256")
    _same(LEGACY_MANIFEST_VERSION, legacy.get("manifest_version"), "legacy manifest version")
    _same(
        LEGACY_MANIFEST_CONTENT_SHA256,
        legacy.get("content_sha256"),
        "legacy manifest content SHA-256",
    )
    _same(
        LEGACY_MANIFEST_CONTENT_SHA256,
        manifest_content_sha256(legacy),
        "recomputed legacy manifest content SHA-256",
    )
    rows = legacy.get("examples")
    if not isinstance(rows, list) or len(rows) != EXPECTED_LEGACY_ROWS:
        _fail("legacy V6 manifest must contain exactly 117 examples")
    ids = [str(row.get("id", "")) for row in rows if isinstance(row, dict)]
    if len(ids) != len(rows) or len(ids) != len(set(ids)):
        _fail("legacy V6 manifest has malformed or duplicate IDs")
    if any(FORBIDDEN_EXAMPLE_KEYS & set(row) for row in rows):
        _fail("legacy V6 example contains a forbidden outcome field")
    return legacy, file_hash


def authenticate_snapshot(path: str | Path) -> dict[str, Any]:
    """Attest the HF symlink-target-name inventory and pinned metadata hashes.

    Weight-blob bytes are deliberately not rehashed here.
    """
    candidate = Path(path).expanduser()
    if candidate.is_symlink():
        _fail(f"snapshot root must not be a symlink: {candidate}")
    root = candidate.resolve()
    if not root.is_dir() or MODEL_REVISION not in root.parts:
        _fail(f"snapshot must be a directory for pinned revision {MODEL_REVISION}")
    rows: list[str] = []
    files: list[Path] = []
    for entry in sorted(root.rglob("*")):
        if entry.is_dir():
            continue
        relative = entry.relative_to(root).as_posix()
        if not entry.is_symlink():
            _fail(f"snapshot entry must be a frozen symlink: {relative}")
        target = os.readlink(entry)
        rows.append(f"L\t{relative}\t{target}\n")
        resolved_target = entry.resolve()
        if not resolved_target.is_file():
            _fail(f"snapshot target is absent for {relative}")
        try:
            resolved_target.relative_to(root.parent.parent.resolve())
        except ValueError:
            _fail(f"snapshot target escapes its model cache for {relative}")
        files.append(entry)
    inventory_hash = hashlib.sha256("".join(rows).encode("utf-8")).hexdigest()
    _same(SNAPSHOT_FILE_COUNT, len(files), "snapshot file count")
    _same(SNAPSHOT_INVENTORY_SHA256, inventory_hash, "snapshot inventory SHA-256")
    metadata: dict[str, str] = {}
    for name, expected in SNAPSHOT_METADATA_SHA256.items():
        file_path = root / name
        if file_path not in files:
            _fail(f"snapshot metadata file is absent: {name}")
        got = sha256_file(file_path)
        _same(expected, got, f"snapshot metadata SHA-256 {name}")
        metadata[name] = got
    return {
        "revision": MODEL_REVISION,
        "file_count": len(files),
        "inventory_sha256": inventory_hash,
        "metadata_sha256": metadata,
    }


def _flat_ids(value: Any, label: str) -> list[int]:
    if isinstance(value, Mapping) or hasattr(value, "keys"):
        if "input_ids" not in value:
            _fail(f"{label} mapping has no input_ids")
        value = value["input_ids"]
    if hasattr(value, "tolist"):
        value = value.tolist()
    if value and isinstance(value[0], list):
        if len(value) != 1:
            _fail(f"{label} returned batch size {len(value)}, expected one")
        value = value[0]
    try:
        out = [int(token) for token in value]
    except (TypeError, ValueError) as exc:
        _fail(f"{label} returned invalid input IDs: {exc}")
    if not out:
        _fail(f"{label} returned no input IDs")
    return out


def validate_tokenizer(tokenizer: Any) -> None:
    template = getattr(tokenizer, "chat_template", None)
    if not isinstance(template, str) or not template:
        _fail("pinned Qwen tokenizer has no string chat_template")
    _same(CHAT_TEMPLATE_SHA256, sha256_text(template), "Qwen chat-template SHA-256")
    sequences = [
        _flat_ids(
            tokenizer.encode(text, add_special_tokens=False),
            f"canonical response {choice}",
        )
        for choice, text in zip(
            "ABCD", (f"The correct answer is ({choice})" for choice in "ABCD")
        )
    ]
    common = 0
    for column in zip(*sequences):
        if len(set(column)) != 1:
            break
        common += 1
    prefix = tuple(sequences[0][:common])
    branches = {
        choice: int(sequences[index][common])
        for index, choice in enumerate("ABCD")
    }
    suffixes = {tuple(sequence[common + 1 :]) for sequence in sequences}
    _same(SCAFFOLD_TOKEN_IDS, prefix, "canonical response scaffold tokens")
    _same(CHOICE_BRANCH_IDS, branches, "canonical response branch tokens")
    if len(suffixes) != 1:
        _fail("canonical response suffix differs across A/B/C/D")


def load_tokenizer(model_or_snapshot: str) -> Any:
    import tokenizers
    import transformers
    from transformers import AutoTokenizer

    _same(TRANSFORMERS_VERSION, transformers.__version__, "transformers version")
    _same(TOKENIZERS_VERSION, tokenizers.__version__, "tokenizers version")
    candidate = Path(str(model_or_snapshot)).expanduser()
    authenticate_snapshot(candidate)
    tokenizer = AutoTokenizer.from_pretrained(
        str(candidate.resolve()), local_files_only=True, trust_remote_code=True
    )
    validate_tokenizer(tokenizer)
    return tokenizer


def qwen_input_ids(tokenizer: Any, item: Mapping[str, Any]) -> list[int]:
    prompt = LB.render_prompt(dict(item))
    try:
        rendered = tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}],
            tokenize=True,
            add_generation_prompt=True,
            enable_thinking=ENABLE_THINKING,
        )
    except (TypeError, ValueError) as exc:
        _fail(f"Qwen chat rendering failed for {item.get('_id')}: {exc}")
    return _flat_ids(rendered, f"Qwen chat rendering for {item.get('_id')}")


def prompt_with_content_spans(
    item: Mapping[str, Any],
) -> tuple[str, dict[str, tuple[int, int]]]:
    """Render the official prompt and locate the five exact content spans."""
    replacements = {
        "$DOC$": (None, str(item["context"]).strip()),
        "$Q$": ("question", str(item["question"]).strip()),
        "$C_A$": ("A", str(item["choice_A"]).strip()),
        "$C_B$": ("B", str(item["choice_B"]).strip()),
        "$C_C$": ("C", str(item["choice_C"]).strip()),
        "$C_D$": ("D", str(item["choice_D"]).strip()),
    }
    template = LB.OFFICIAL_PROMPT
    cursor = 0
    chunks: list[str] = []
    spans: dict[str, tuple[int, int]] = {}
    length = 0
    while cursor < len(template):
        matches = [
            (template.find(marker, cursor), marker)
            for marker in replacements
            if template.find(marker, cursor) >= 0
        ]
        if not matches:
            suffix = template[cursor:]
            chunks.append(suffix)
            length += len(suffix)
            break
        position, marker = min(matches)
        literal = template[cursor:position]
        chunks.append(literal)
        length += len(literal)
        group, value = replacements[marker]
        start = length
        chunks.append(value)
        length += len(value)
        if group is not None:
            if group in spans or not value:
                _fail(f"invalid or repeated {group} content span for {item.get('_id')}")
            spans[group] = (start, length)
        cursor = position + len(marker)
    prompt = "".join(chunks)
    _same(LB.render_prompt(dict(item)), prompt, f"official prompt rendering {item.get('_id')}")
    _same(set(CONTENT_GROUPS), set(spans), f"content span groups {item.get('_id')}")
    return prompt, spans


def evenly_spaced_positions(
    positions: Sequence[int], *, maximum: int = MAX_CONTENT_TOKENS_PER_GROUP
) -> list[int]:
    """Take deterministic endpoint-inclusive positions from an ordered list."""
    ordered = [int(position) for position in positions]
    if not ordered or any(a >= b for a, b in zip(ordered, ordered[1:])):
        _fail("content-overlap positions must be nonempty and strictly increasing")
    if maximum < 1:
        _fail("maximum sampled content tokens must be positive")
    n = len(ordered)
    m = min(maximum, n)
    indices = [0] if m == 1 else [j * (n - 1) // (m - 1) for j in range(m)]
    selected = [ordered[index] for index in indices]
    if len(selected) != len(set(selected)):
        _fail("evenly spaced content sampling produced a duplicate")
    return selected


def prompt_ids_and_content_positions(
    tokenizer: Any, item: Mapping[str, Any]
) -> tuple[list[int], dict[str, list[int]]]:
    """Render one chat and map each content group to sampled token indices."""
    prompt, prompt_spans = prompt_with_content_spans(item)
    messages = [{"role": "user", "content": prompt}]
    rendered_chat = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=ENABLE_THINKING,
    )
    if not isinstance(rendered_chat, str) or not rendered_chat:
        _fail(f"Qwen string chat rendering failed for {item.get('_id')}")
    prompt_start = rendered_chat.find(prompt)
    if prompt_start < 0 or prompt_start != rendered_chat.rfind(prompt):
        _fail(f"official prompt is absent or repeated in rendered chat for {item.get('_id')}")
    encoded = tokenizer(
        rendered_chat,
        add_special_tokens=False,
        return_offsets_mapping=True,
        return_attention_mask=False,
    )
    ids = _flat_ids(encoded, f"offset chat rendering for {item.get('_id')}")
    offsets = encoded.get("offset_mapping")
    if hasattr(offsets, "tolist"):
        offsets = offsets.tolist()
    if not isinstance(offsets, list) or len(offsets) != len(ids):
        _fail(f"Qwen tokenizer returned invalid offsets for {item.get('_id')}")
    canonical_ids = qwen_input_ids(tokenizer, item)
    _same(canonical_ids, ids, f"offset/canonical prompt tokens {item.get('_id')}")

    groups: dict[str, list[int]] = {}
    for group in CONTENT_GROUPS:
        relative_start, relative_end = prompt_spans[group]
        start, end = prompt_start + relative_start, prompt_start + relative_end
        overlaps: list[int] = []
        for index, pair in enumerate(offsets):
            if not isinstance(pair, (list, tuple)) or len(pair) != 2:
                _fail(f"malformed offset at token {index} for {item.get('_id')}")
            token_start, token_end = int(pair[0]), int(pair[1])
            if token_start < token_end and token_start < end and token_end > start:
                overlaps.append(index)
        chosen = evenly_spaced_positions(overlaps)
        if not chosen or len(chosen) > MAX_CONTENT_TOKENS_PER_GROUP:
            _fail(f"invalid sampled {group} token positions for {item.get('_id')}")
        if chosen[-1] >= len(ids) - 1:
            _fail(
                f"{group} token position reaches the final uncached prompt token "
                f"for {item.get('_id')}"
            )
        groups[group] = chosen
    return ids, groups


class _UnionFind:
    def __init__(self, keys: Iterable[str]):
        self.parent = {str(key): str(key) for key in keys}

    def find(self, key: str) -> str:
        parent = self.parent[key]
        if parent != key:
            self.parent[key] = self.find(parent)
        return self.parent[key]

    def union(self, left: str, right: str) -> None:
        a, b = self.find(left), self.find(right)
        if a == b:
            return
        if b < a:
            a, b = b, a
        self.parent[b] = a


def connected_components(
    records: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, str], dict[str, list[str]]]:
    """Partition all rows by transitive exact stripped-context/question matches."""
    ids = [str(item["_id"]) for item in records]
    if len(ids) != len(set(ids)):
        _fail("dataset IDs are not unique")
    union = _UnionFind(ids)
    contexts: dict[str, str] = {}
    questions: dict[str, str] = {}
    for item in records:
        item_id = str(item["_id"])
        for digest, seen in (
            (LB.context_hash(dict(item)), contexts),
            (sha256_text(str(item["question"]).strip()), questions),
        ):
            previous = seen.setdefault(digest, item_id)
            union.union(previous, item_id)
    roots: dict[str, list[str]] = collections.defaultdict(list)
    for item_id in ids:
        roots[union.find(item_id)].append(item_id)
    component_by_id: dict[str, str] = {}
    members_by_component: dict[str, list[str]] = {}
    for members in roots.values():
        ordered = sorted(members)
        payload = "".join(f"{item_id}\n" for item_id in ordered).encode("ascii")
        component = hashlib.sha256(COMPONENT_ID_NAMESPACE + payload).hexdigest()
        if component in members_by_component:
            _fail("connected-component SHA-256 collision")
        members_by_component[component] = ordered
        for item_id in ordered:
            component_by_id[item_id] = component
    return component_by_id, members_by_component


def salted_order(rows: Iterable[Mapping[str, Any]], namespace: bytes) -> list[str]:
    return sorted(
        (str(row["id"]) for row in rows),
        key=lambda item_id: (
            hashlib.sha256(namespace + item_id.encode("ascii")).digest(), item_id
        ),
    )


def partition_order(rows: Iterable[Mapping[str, Any]]) -> list[str]:
    """Return the single frozen V7 selection/split ordering of row IDs."""
    return salted_order(rows, SELECTION_NAMESPACE)


def ordered_id_sha256(rows: Iterable[Mapping[str, Any]]) -> str:
    """Hash newline-joined IDs in the frozen single salted order."""
    payload = "".join(
        f"{item_id}\n" for item_id in partition_order(rows)
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def _split_summaries(examples: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    output: dict[str, Any] = {}
    for split in SPLITS:
        rows = [row for row in examples if row["split"] == split]
        tokens = [int(row["input_tokens"]) for row in rows]
        output[split] = {
            "rows": len(rows),
            "components": len({str(row["group_id"]) for row in rows}),
            "id_sha256": id_sha256(rows),
            "ordered_id_sha256": ordered_id_sha256(rows),
            "id_token_sha256": id_token_sha256(rows),
            "id_prompt_sha256": id_prompt_sha256(rows),
            "id_positions_sha256": id_positions_sha256(rows),
            "input_tokens_min": min(tokens),
            "input_tokens_max": max(tokens),
        }
    return output


def _derive_manifest(
    data: Sequence[Mapping[str, Any]],
    legacy: Mapping[str, Any],
    tokenizer: Any,
    *,
    legacy_file_hash: str,
) -> dict[str, Any]:
    validate_tokenizer(tokenizer)
    _same(EXPECTED_DATASET_ROWS, len(data), "dataset row count")
    by_id = {str(item["_id"]): item for item in data}
    if len(by_id) != len(data):
        _fail("dataset IDs are not unique")
    legacy_rows = legacy["examples"]
    legacy_ids = {str(row["id"]) for row in legacy_rows}
    if not legacy_ids <= set(by_id):
        _fail("legacy manifest contains IDs absent from the pinned dataset")
    for row in legacy_rows:
        item = by_id[str(row["id"])]
        _same(LB.context_hash(dict(item)), row.get("context_hash"), f"legacy context hash {row['id']}")
        _same(
            sha256_text(str(item["question"]).strip()),
            row.get("question_hash"),
            f"legacy question hash {row['id']}",
        )

    component_by_id, members_by_component = connected_components(data)
    _same(EXPECTED_ALL_COMPONENTS, len(members_by_component), "all component count")
    tainted_components = {component_by_id[item_id] for item_id in legacy_ids}
    tainted_rows = sum(len(members_by_component[group]) for group in tainted_components)
    _same(EXPECTED_TAINTED_COMPONENTS, len(tainted_components), "tainted component count")
    _same(EXPECTED_TAINTED_ROWS, tainted_rows, "tainted row count")

    singleton_items = [
        item
        for item in data
        if component_by_id[str(item["_id"])] not in tainted_components
        and len(members_by_component[component_by_id[str(item["_id"])]]) == 1
    ]
    _same(EXPECTED_UNTAINTED_SINGLETONS, len(singleton_items), "untainted singleton count")

    eligible: list[dict[str, Any]] = []
    over_cap = 0
    for item in singleton_items:
        prompt_ids = qwen_input_ids(tokenizer, item)
        if len(prompt_ids) + len(SCAFFOLD_TOKEN_IDS) > CONTEXT_WINDOW:
            over_cap += 1
            continue
        prompt_ids, content_positions = prompt_ids_and_content_positions(tokenizer, item)
        item_id = str(item["_id"])
        eligible.append(
            {
                "id": item_id,
                "group_id": component_by_id[item_id],
                "context_hash": LB.context_hash(dict(item)),
                "question_hash": sha256_text(str(item["question"]).strip()),
                "metadata": {
                    key: str(item[key])
                    for key in ("domain", "sub_domain", "difficulty", "length")
                },
                "input_tokens": len(prompt_ids),
                "prompt_token_hash": token_hash(prompt_ids),
                "content_token_positions": content_positions,
            }
        )
    _same(EXPECTED_ELIGIBLE_ROWS, len(eligible), "eligible singleton count")
    _same(EXPECTED_UNTAINTED_SINGLETONS - EXPECTED_ELIGIBLE_ROWS, over_cap, "over-cap singleton count")

    eligible_by_id = {str(row["id"]): row for row in eligible}
    selection_order = partition_order(eligible)
    selected_ids = selection_order[:SELECTED_ROWS]
    _same(SELECTED_ROWS, len(selected_ids), "selected row count")
    split_by_id: dict[str, str] = {}
    cursor = 0
    for split in SPLITS:
        stop = cursor + SPLIT_ROWS[split]
        for item_id in selected_ids[cursor:stop]:
            split_by_id[item_id] = split
        cursor = stop
    _same(SELECTED_ROWS, cursor, "split row total")

    examples = [
        {**eligible_by_id[item_id], "split": split_by_id[item_id]}
        for item_id in sorted(selected_ids)
    ]
    split_counts = _split_summaries(examples)
    for split, expected in SPLIT_ROWS.items():
        _same(expected, split_counts[split]["rows"], f"{split} row count")
        _same(expected, split_counts[split]["components"], f"{split} component count")

    manifest: dict[str, Any] = {
        "manifest_version": MANIFEST_VERSION,
        "protocol": {
            "dataset": {
                "repo": LB.DATASET_REPO,
                "revision": LB.DATASET_REVISION,
                "sha256": LB.DATASET_SHA256,
                "bytes": LB.DATASET_BYTES,
            },
            "official_prompt": {
                "code_repo": LB.OFFICIAL_CODE_REPO,
                "code_revision": LB.OFFICIAL_CODE_REVISION,
                "prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
            },
            "legacy_exclusion": {
                "manifest": LEGACY_MANIFEST_ID,
                "manifest_version": LEGACY_MANIFEST_VERSION,
                "manifest_content_sha256": LEGACY_MANIFEST_CONTENT_SHA256,
                "manifest_file_sha256": legacy_file_hash,
                "rule": "exclude_full_transitive_exact_context_or_question_component",
            },
            "model": {
                "tag": MODEL_TAG,
                "id": MODEL_ID,
                "revision": MODEL_REVISION,
                "tokenizer_revision": TOKENIZER_REVISION,
                "transformers_version": TRANSFORMERS_VERSION,
                "tokenizers_version": TOKENIZERS_VERSION,
                "chat_template_sha256": CHAT_TEMPLATE_SHA256,
                "add_generation_prompt": True,
                "enable_thinking": ENABLE_THINKING,
            },
            "forced_choice": {
                "scaffold_token_ids": list(SCAFFOLD_TOKEN_IDS),
                "choice_branch_ids": dict(CHOICE_BRANCH_IDS),
            },
            "eligibility": {
                "context_window": CONTEXT_WINDOW,
                "required_suffix_tokens": len(SCAFFOLD_TOKEN_IDS),
                "complete_input_rule": "chat_input_tokens + 5 <= 131072",
                "component_rule": "untainted_singleton_in_all_503_row_component_graph",
            },
            "partition": {
                "component_id_namespace_utf8": COMPONENT_ID_NAMESPACE.decode("utf-8"),
                "selection_namespace_utf8": SELECTION_NAMESPACE.decode("utf-8"),
                "selection": "first_117_by_sha256(namespace_plus_item_id_ascii)",
                "split_order": "same_selection_order_first_20_next_52_last_45",
                "split_rows": dict(SPLIT_ROWS),
            },
            "content_tokens": {
                "groups": list(CONTENT_GROUPS),
                "overlap": "token_offset_start < content_end and token_offset_end > content_start",
                "maximum_per_group": MAX_CONTENT_TOKENS_PER_GROUP,
                "sampling": "floor(j*(n-1)/(m-1)); m=min(8,n); singleton_index=0",
                "final_uncached_prompt_token_excluded": True,
            },
        },
        "legacy_manifest": LEGACY_MANIFEST_ID,
        "legacy_manifest_content_sha256": LEGACY_MANIFEST_CONTENT_SHA256,
        "legacy_manifest_file_sha256": legacy_file_hash,
        "counts": {
            "dataset_rows": len(data),
            "all_components": len(members_by_component),
            "legacy_rows": len(legacy_ids),
            "tainted_components": len(tainted_components),
            "tainted_rows": tainted_rows,
            "untainted_singletons": len(singleton_items),
            "singleton_rows_over_cap": over_cap,
            "eligible_singletons": len(eligible),
            "selected_rows": len(examples),
        },
        "eligible_id_sha256": id_sha256(eligible),
        "selection_order_sha256": hashlib.sha256(
            "".join(f"{item_id}\n" for item_id in selection_order).encode("ascii")
        ).hexdigest(),
        "selected_id_sha256": id_sha256(examples),
        "split_counts": split_counts,
        "examples": examples,
    }
    manifest["content_sha256"] = manifest_content_sha256(manifest)
    return manifest


def build_manifest(
    *,
    dataset_path: str | Path,
    legacy_manifest_path: str | Path,
    tokenizer: Any,
) -> dict[str, Any]:
    legacy, legacy_file_hash = authenticate_legacy_manifest(legacy_manifest_path)
    data = LB.load_dataset(dataset_path, authenticate=True)
    manifest = _derive_manifest(
        data, legacy, tokenizer, legacy_file_hash=legacy_file_hash
    )
    validate_manifest_schema(manifest, enforce_frozen=False)
    return manifest


def validate_manifest_schema(
    manifest: Mapping[str, Any], *, enforce_frozen: bool = True
) -> None:
    expected_top = {
        "manifest_version", "protocol", "legacy_manifest",
        "legacy_manifest_content_sha256", "legacy_manifest_file_sha256",
        "counts", "eligible_id_sha256", "selection_order_sha256",
        "selected_id_sha256", "split_counts", "examples", "content_sha256",
    }
    _same(expected_top, set(manifest), "V7 manifest top-level schema")
    _same(MANIFEST_VERSION, manifest.get("manifest_version"), "V7 manifest version")
    _same(
        manifest_content_sha256(manifest),
        manifest.get("content_sha256"),
        "V7 manifest content SHA-256",
    )
    if enforce_frozen and FROZEN_MANIFEST_CONTENT_SHA256:
        _same(
            FROZEN_MANIFEST_CONTENT_SHA256,
            manifest.get("content_sha256"),
            "frozen V7 manifest content SHA-256",
        )
    _same(LEGACY_MANIFEST_ID, manifest.get("legacy_manifest"), "legacy manifest ID")
    _same(
        LEGACY_MANIFEST_CONTENT_SHA256,
        manifest.get("legacy_manifest_content_sha256"),
        "legacy content hash",
    )
    _same(
        LEGACY_MANIFEST_FILE_SHA256,
        manifest.get("legacy_manifest_file_sha256"),
        "legacy file hash",
    )
    examples = manifest.get("examples")
    if not isinstance(examples, list) or len(examples) != SELECTED_ROWS:
        _fail("V7 manifest must contain exactly 117 selected examples")
    if any(not isinstance(row, dict) or set(row) != EXAMPLE_KEYS for row in examples):
        _fail("V7 manifest example schema drifted")
    ids = [str(row["id"]) for row in examples]
    if ids != sorted(ids) or len(ids) != len(set(ids)):
        _fail("V7 manifest example IDs must be sorted and unique")
    if any(FORBIDDEN_EXAMPLE_KEYS & set(row) for row in examples):
        _fail("V7 manifest example contains a forbidden outcome field")
    groups = [str(row["group_id"]) for row in examples]
    if len(groups) != len(set(groups)):
        _fail("V7 manifest selected components are not singletons")
    for row in examples:
        positions = row["content_token_positions"]
        if not isinstance(positions, dict) or set(positions) != set(CONTENT_GROUPS):
            _fail(f"content token groups drifted for {row['id']}")
        seen_positions: set[int] = set()
        for group, values in positions.items():
            if not isinstance(values, list) or not 1 <= len(values) <= MAX_CONTENT_TOKENS_PER_GROUP:
                _fail(f"invalid {group} token count for {row['id']}")
            if any(isinstance(value, bool) or not isinstance(value, int) for value in values):
                _fail(f"non-integer {group} token position for {row['id']}")
            if values != sorted(set(values)):
                _fail(f"unordered or duplicate {group} token positions for {row['id']}")
            if values[-1] >= int(row["input_tokens"]) - 1:
                _fail(f"{group} includes final uncached prompt token for {row['id']}")
            if seen_positions & set(values):
                _fail(f"content token groups overlap for {row['id']}")
            seen_positions.update(values)
    _same(EXPECTED_ELIGIBLE_ROWS, manifest["counts"].get("eligible_singletons"), "eligible count")
    _same(SELECTED_ROWS, manifest["counts"].get("selected_rows"), "selected count")
    _same(id_sha256(examples), manifest.get("selected_id_sha256"), "selected ID hash")
    summaries = _split_summaries(examples)
    _same(summaries, manifest.get("split_counts"), "split summaries")
    for split, count in SPLIT_ROWS.items():
        _same(count, summaries[split]["rows"], f"{split} rows")
        _same(count, summaries[split]["components"], f"{split} components")


def validate_manifest_object(
    manifest: Mapping[str, Any],
    *,
    data: Sequence[Mapping[str, Any]],
    legacy_manifest: Mapping[str, Any],
    tokenizer: Any,
) -> None:
    """Strictly reproduce the manifest and compare every value."""
    validate_manifest_schema(manifest)
    expected = _derive_manifest(
        data,
        legacy_manifest,
        tokenizer,
        legacy_file_hash=LEGACY_MANIFEST_FILE_SHA256,
    )
    _same(expected, dict(manifest), "reproduced V7 manifest")


def authenticate_manifest(
    manifest_path: str | Path,
    *,
    dataset_path: str | Path,
    legacy_manifest_path: str | Path,
    tokenizer: Any,
) -> tuple[dict[str, Any], str]:
    legacy, _ = authenticate_legacy_manifest(legacy_manifest_path)
    data = LB.load_dataset(dataset_path, authenticate=True)
    manifest = _load_object(manifest_path, "V7 manifest")
    file_hash = sha256_file(manifest_path)
    if FROZEN_MANIFEST_FILE_SHA256:
        _same(FROZEN_MANIFEST_FILE_SHA256, file_hash, "frozen V7 manifest file SHA-256")
    validate_manifest_object(
        manifest, data=data, legacy_manifest=legacy, tokenizer=tokenizer
    )
    return manifest, file_hash


def write_manifest(path: str | Path, manifest: Mapping[str, Any]) -> None:
    """Atomically write once; accept only an identical existing regular file."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = (
        json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    if target.is_symlink():
        _fail(f"refusing symlink manifest target {target}")
    if target.exists():
        if not target.is_file():
            _fail(f"manifest target is not a regular file: {target}")
        if target.read_bytes() == payload:
            return
        _fail(f"refusing to replace different existing manifest {target}")
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{target.name}.", suffix=".tmp", dir=target.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, help="pinned LongBench-v2 JSON")
    parser.add_argument("--legacy-manifest", required=True, help="frozen V6 Qwen manifest")
    parser.add_argument(
        "--tokenizer", required=True,
        help="local Qwen snapshot path ending in the pinned revision",
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out", help="build and write the deterministic manifest")
    group.add_argument("--manifest", help="audit an existing V7 manifest")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        tokenizer = load_tokenizer(args.tokenizer)
        if args.out:
            manifest = build_manifest(
                dataset_path=args.data,
                legacy_manifest_path=args.legacy_manifest,
                tokenizer=tokenizer,
            )
            write_manifest(args.out, manifest)
            authenticate_manifest(
                args.out,
                dataset_path=args.data,
                legacy_manifest_path=args.legacy_manifest,
                tokenizer=tokenizer,
            )
            print(f"wrote {Path(args.out).resolve()}")
        else:
            authenticate_manifest(
                args.manifest,
                dataset_path=args.data,
                legacy_manifest_path=args.legacy_manifest,
                tokenizer=tokenizer,
            )
            print(f"PASS {Path(args.manifest).resolve()}")
    except (OSError, TypeError, V7ManifestError, ValueError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
