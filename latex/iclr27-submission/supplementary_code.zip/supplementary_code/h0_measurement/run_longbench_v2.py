#!/usr/bin/env python3
"""Run the pinned LongBench-v2 V4 natural-task experiment.

This runner is intentionally separate from ``run_r8.py``.  It reuses R8's
verified cache prefill, allocation, compressed-policy execution, allocation-ID,
and EOS helpers, while owning LongBench's pinned data/manifest contract and its
natural-answer decode (EOS or 128 tokens; no RULER newline stop).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import pandas as pd
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from sievelib import baselines as BL  # noqa: E402
from sievelib import compress as C  # noqa: E402
from sievelib import policy_diagnostic as PD  # noqa: E402
from sievelib import quant, router  # noqa: E402
from sievelib import tasks_longbench_v2 as LB  # noqa: E402
import audit_longbench_v2 as AUDIT  # noqa: E402
import run_h0  # noqa: E402
import run_r8 as R8  # noqa: E402


RUNNER_VERSION = "longbench_v2_runner_v1"
MODEL_TAG = "llama31-8b"
MODEL_ID = "meta-llama/Llama-3.1-8B-Instruct"
CTX = 32768
MAX_NEW = 128
MAX_INPUT = CTX - MAX_NEW
BUDGET = 2
WINDOW = 32
CASCADE_BITS = 4
DTYPE_NAME = "bfloat16"
BIT_LIST = (1, 2, 3, 4, 5, 6, 8)
MAXB = 8
ROT_SEED = 0
NORM_CORRECT = True
CHUNK = 4096
CHOICE_PREFIX_TOKENS = (791, 4495, 4320, 374, 320)
CHOICE_BRANCH_IDS = {"A": 32, "B": 33, "C": 34, "D": 35}
EXPECTED_ELIGIBLE = LB.EXPECTED_ELIGIBLE_ROWS
EXPECTED_DATASET_ROWS = 503
EXPECTED_ELIGIBLE_LIST_SHA256 = LB.EXPECTED_ELIGIBLE_LIST_SHA256
EXPECTED_MANIFEST_CONTENT_SHA256 = (
    "ee951a2c7b2c256125e73de4fba6f7e14485a566bbf6096c14c6e4f23e6407ff"
)
SPLITS = tuple(LB.EXPECTED_SPLITS)
EXPECTED_SPLIT_ROWS = {
    split: int(record["rows"]) for split, record in LB.EXPECTED_SPLITS.items()
}
EXPECTED_SPLIT_ID_SHA256 = {
    split: str(record["id_sha256"]) for split, record in LB.EXPECTED_SPLITS.items()
}
EXPECTED_SPLIT_ID_TOKEN_SHA256 = {
    split: str(record["id_token_sha256"])
    for split, record in LB.EXPECTED_SPLITS.items()
}

QUALIFICATION_RAW_ARMS = ("fp", "uniform")
DEVELOPMENT_RAW_ARMS = (
    "fp",
    "uniform",
    "evict",
    "interior",
    "interior_pool",
    "interior_cascade",
    "obcache_k",
    "obcache_k:alloc=ada@obck_ada",
    "laprox",
)
DEVELOPMENT_LABELS = (
    "fp", "uniform", "evict", "interior", "interior_pool",
    "interior_cascade", "obcache_k", "obck_ada", "laprox",
)


class LongBenchRunnerError(RuntimeError):
    """A frozen V4 contract was violated; partial artifacts must not be used."""


def _fail(message: str) -> None:
    raise LongBenchRunnerError(message)


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_text(value: str) -> str:
    return sha256_bytes(str(value).encode("utf-8"))


def canonical_ids_sha256(ids: Iterable[str]) -> str:
    payload = "".join(f"{value}\n" for value in sorted(ids)).encode("utf-8")
    return sha256_bytes(payload)


def manifest_content_sha256(manifest: Mapping[str, Any]) -> str:
    body = dict(manifest)
    body.pop("content_sha256", None)
    payload = json.dumps(
        body, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return sha256_bytes(payload)


def eligible_list_sha256(examples: Sequence[Mapping[str, Any]]) -> str:
    ordered = sorted(examples, key=lambda row: str(row["id"]))
    payload = "".join(
        f"{row['id']}\t{int(row['input_tokens'])}\n" for row in ordered
    ).encode("utf-8")
    return sha256_bytes(payload)


def load_manifest(path: str | os.PathLike[str]) -> tuple[dict[str, Any], str]:
    manifest_path = Path(path)
    raw = manifest_path.read_bytes()
    try:
        manifest = json.loads(raw)
    except json.JSONDecodeError as exc:
        _fail(f"manifest is not valid JSON: {exc}")
    if not isinstance(manifest, dict):
        _fail("manifest root must be an object")
    required = {
        "manifest_version", "protocol", "counts", "eligible_list_sha256",
        "split_counts", "split_validation", "examples", "content_sha256",
    }
    if set(manifest) != required:
        _fail(f"manifest top-level keys are {sorted(manifest)}, expected {sorted(required)}")
    if manifest.get("manifest_version") != LB.MANIFEST_VERSION:
        _fail(f"manifest version is {manifest.get('manifest_version')!r}, expected "
              f"{LB.MANIFEST_VERSION!r}")
    claimed = manifest.get("content_sha256")
    try:
        AUDIT.verify_manifest_content_hash(manifest)
    except (KeyError, TypeError, ValueError) as exc:
        _fail(f"canonical audit helper rejected manifest content: {exc}")
    computed = manifest_content_sha256(manifest)
    if claimed != computed:
        _fail(f"manifest content_sha256 is {claimed!r}, computed {computed}")
    if claimed != EXPECTED_MANIFEST_CONTENT_SHA256:
        _fail(f"manifest content SHA-256 is {claimed}, expected the checked "
              f"{EXPECTED_MANIFEST_CONTENT_SHA256}")
    if not isinstance(manifest["protocol"], dict):
        _fail("manifest.protocol must be an object")
    if not isinstance(manifest["counts"], dict):
        _fail("manifest.counts must be an object")
    if not isinstance(manifest["split_counts"], dict):
        _fail("manifest.split_counts must be an object")
    if not isinstance(manifest["examples"], list):
        _fail("manifest.examples must be a list")
    return manifest, sha256_bytes(raw)


def _protocol_value(protocol: Mapping[str, Any], *paths: str) -> Any:
    """Read one frozen protocol value, permitting flat or nested JSON spelling.

    The manifest builder owns the spelling; accepting an explicitly enumerated
    nested/flat pair keeps this runner independent of presentation without
    weakening the value check.
    """
    found = []
    for path in paths:
        value: Any = protocol
        ok = True
        for part in path.split("."):
            if not isinstance(value, Mapping) or part not in value:
                ok = False
                break
            value = value[part]
        if ok:
            found.append((path, value))
    if not found:
        _fail(f"manifest protocol lacks any of {paths}")
    values = [value for _, value in found]
    if any(value != values[0] for value in values[1:]):
        _fail(f"manifest protocol aliases disagree: {found}")
    return values[0]


def validate_protocol_static(manifest: Mapping[str, Any]) -> None:
    p = manifest["protocol"]
    checks = (
        (("dataset.repo",), LB.DATASET_REPO, "dataset repo"),
        (("dataset.revision",), LB.DATASET_REVISION, "dataset revision"),
        (("dataset.sha256",), LB.DATASET_SHA256, "dataset SHA-256"),
        (("dataset.bytes",), LB.DATASET_BYTES, "dataset bytes"),
        (("official_evaluation.code_revision",), LB.OFFICIAL_CODE_REVISION,
         "official code revision"),
        (("official_evaluation.prompt_sha256",), LB.OFFICIAL_PROMPT_SHA256,
         "official prompt SHA-256"),
        (("official_evaluation.task_version",), LB.TASK_VERSION, "task version"),
        (("official_evaluation.parser_version",), LB.PARSER_VERSION,
         "parser version"),
        (("model.id",), LB.MODEL_ID, "model id"),
        (("model.revision",), LB.MODEL_REVISION, "model revision"),
        (("model.transformers_version",), LB.TRANSFORMERS_VERSION,
         "transformers version"),
        (("model.tokenizers_version",), LB.TOKENIZERS_VERSION,
         "tokenizers version"),
        (("model.chat_template_sha256",), LB.CHAT_TEMPLATE_SHA256,
         "chat-template SHA-256"),
        (("grouping.context_hash_version",), LB.CONTEXT_HASH_VERSION,
         "context hash version"),
        (("grouping.question_hash_version",), LB.QUESTION_HASH_VERSION,
         "question hash version"),
        (("grouping.split_version",), LB.SPLIT_VERSION, "split version"),
        (("eligibility.context_window",), CTX, "context length"),
        (("eligibility.reserved_output_tokens",), MAX_NEW,
         "reserved generation tokens"),
        (("eligibility.max_rendered_input_tokens",), MAX_INPUT,
         "maximum input tokens"),
    )
    for paths, expected, description in checks:
        got = _protocol_value(p, *paths)
        if got != expected:
            _fail(f"manifest {description} is {got!r}, expected {expected!r}")


def validate_runtime_protocol(protocol: Mapping[str, Any], tokenizer: Any) -> str:
    """Authenticate chat rendering software/template before any model output."""
    import tokenizers
    import transformers

    transformer_version = _protocol_value(protocol, "model.transformers_version")
    tokenizer_version = _protocol_value(protocol, "model.tokenizers_version")
    if transformer_version != transformers.__version__:
        _fail(f"transformers version is {transformers.__version__!r}, manifest pins "
              f"{transformer_version!r}")
    if tokenizer_version != tokenizers.__version__:
        _fail(f"tokenizers version is {tokenizers.__version__!r}, manifest pins "
              f"{tokenizer_version!r}")
    template = getattr(tokenizer, "chat_template", None)
    if not isinstance(template, str) or not template:
        _fail("model tokenizer has no chat_template")
    got_hash = sha256_text(template)
    expected_hash = _protocol_value(protocol, "model.chat_template_sha256")
    if got_hash != expected_hash:
        _fail(f"chat template SHA-256 is {got_hash}, manifest pins {expected_hash}")
    return got_hash


def _validate_manifest_examples_structure(manifest: Mapping[str, Any]) -> None:
    examples = manifest["examples"]
    if len(examples) != EXPECTED_ELIGIBLE:
        _fail(f"manifest has {len(examples)} eligible rows, expected {EXPECTED_ELIGIBLE}")
    exact_keys = {"id", "group_id", "context_hash", "input_tokens", "metadata", "split"}
    exact_metadata = {"domain", "sub_domain", "difficulty", "length"}
    seen_ids: set[str] = set()
    group_splits: dict[str, str] = {}
    counted = {split: 0 for split in SPLITS}
    for position, entry in enumerate(examples):
        if not isinstance(entry, dict) or set(entry) != exact_keys:
            _fail(f"manifest example {position} keys are {sorted(entry) if isinstance(entry, dict) else type(entry)}, expected {sorted(exact_keys)}")
        item_id = entry["id"]
        group_id = entry["group_id"]
        if not isinstance(item_id, str) or not item_id or item_id in seen_ids:
            _fail(f"manifest example has empty/duplicate id {item_id!r}")
        if not isinstance(group_id, str) or not group_id:
            _fail(f"manifest example {item_id} has invalid group_id {group_id!r}")
        if entry["split"] not in SPLITS:
            _fail(f"manifest example {item_id} has invalid split {entry['split']!r}")
        if group_id in group_splits and group_splits[group_id] != entry["split"]:
            _fail(f"manifest group {group_id!r} crosses splits")
        group_splits[group_id] = entry["split"]
        if not isinstance(entry["metadata"], dict) or set(entry["metadata"]) != exact_metadata:
            _fail(f"manifest example {item_id} has invalid metadata schema")
        if not isinstance(entry["context_hash"], str) or len(entry["context_hash"]) != 64:
            _fail(f"manifest example {item_id} has invalid context_hash")
        if (isinstance(entry["input_tokens"], bool) or
                not isinstance(entry["input_tokens"], int) or
                not 0 < entry["input_tokens"] <= MAX_INPUT):
            _fail(f"manifest example {item_id} has invalid input_tokens "
                  f"{entry['input_tokens']!r}")
        seen_ids.add(item_id)
        counted[entry["split"]] += 1

    if manifest["eligible_list_sha256"] != EXPECTED_ELIGIBLE_LIST_SHA256:
        _fail("manifest eligible_list_sha256 differs from the frozen value")
    recomputed = eligible_list_sha256(examples)
    if recomputed != EXPECTED_ELIGIBLE_LIST_SHA256:
        _fail(f"manifest eligible list recomputes to {recomputed}")
    split_counts = manifest["split_counts"]
    if set(split_counts) != set(SPLITS):
        _fail(f"manifest split_counts keys are {sorted(split_counts)}")
    recorded_rows = {}
    for split, value in split_counts.items():
        if not isinstance(value, Mapping) or set(value) < {"rows"}:
            _fail(f"manifest split_counts[{split!r}] must contain rows")
        recorded_rows[split] = int(value["rows"])
    if recorded_rows != counted or recorded_rows != EXPECTED_SPLIT_ROWS:
        _fail(f"manifest split rows {recorded_rows} do not match {counted} / "
              f"{EXPECTED_SPLIT_ROWS}")
    counts = manifest["counts"]
    if counts.get("eligible_rows") != EXPECTED_ELIGIBLE:
        _fail(f"manifest eligible_rows is {counts.get('eligible_rows')!r}, expected "
              f"{EXPECTED_ELIGIBLE}")
    if counts.get("dataset_rows") != EXPECTED_DATASET_ROWS:
        _fail(f"manifest dataset_rows is {counts.get('dataset_rows')!r}")
    if counts.get("eligible_context_groups") != LB.EXPECTED_CONTEXT_GROUPS:
        _fail("manifest eligible_context_groups drifted")
    if counts.get("eligible_split_components") != LB.EXPECTED_SPLIT_COMPONENTS:
        _fail("manifest eligible_split_components drifted")
    validation = manifest.get("split_validation")
    if validation != {
        "pairwise_context_hash_intersection_count": 0,
        "pairwise_id_intersection_count": 0,
        "pairwise_question_hash_intersection_count": 0,
    }:
        _fail(f"manifest split_validation drifted: {validation}")
    for split in SPLITS:
        entries = [entry for entry in examples if entry["split"] == split]
        ids_hash = canonical_ids_sha256(entry["id"] for entry in entries)
        id_token_hash = eligible_list_sha256(entries)
        record = split_counts[split]
        if record.get("groups") != LB.EXPECTED_SPLITS[split]["groups"]:
            _fail(f"manifest {split} group count drifted")
        if (ids_hash != EXPECTED_SPLIT_ID_SHA256[split] or
                record.get("id_sha256") != ids_hash):
            _fail(f"manifest {split} id_sha256 drifted")
        if (id_token_hash != EXPECTED_SPLIT_ID_TOKEN_SHA256[split] or
                record.get("id_token_sha256") != id_token_hash):
            _fail(f"manifest {split} id_token_sha256 drifted")


def authenticate_examples(data: Sequence[dict[str, str]], manifest: Mapping[str, Any],
                          tokenizer: Any, split: str
                          ) -> list[tuple[dict[str, str], dict[str, Any], list[int]]]:
    """Authenticate every eligible manifest row and return the exact split."""
    if split not in SPLITS:
        _fail(f"unknown split {split!r}; expected one of {SPLITS}")
    _validate_manifest_examples_structure(manifest)
    by_id = LB.index_by_id(data)
    selected = []
    context_splits = {name: set() for name in SPLITS}
    question_splits = {name: set() for name in SPLITS}
    context_groups: dict[str, str] = {}
    question_groups: dict[str, str] = {}
    for entry in manifest["examples"]:
        item_id = entry["id"]
        if item_id not in by_id:
            _fail(f"manifest id {item_id!r} is absent from the pinned dataset")
        item = by_id[item_id]
        metadata = {key: item[key] for key in
                    ("domain", "sub_domain", "difficulty", "length")}
        if metadata != entry["metadata"]:
            _fail(f"manifest metadata drift for {item_id}")
        if item["length"] != "short":
            _fail(f"manifest includes ineligible non-short row {item_id}")
        got_context_hash = LB.context_hash(item)
        if got_context_hash != entry["context_hash"]:
            _fail(f"manifest context hash drift for {item_id}")
        got_question_hash = sha256_text(item["question"].strip())
        entry_split = entry["split"]
        context_splits[entry_split].add(got_context_hash)
        question_splits[entry_split].add(got_question_hash)
        for digest, groups, kind in (
                (got_context_hash, context_groups, "context"),
                (got_question_hash, question_groups, "question")):
            previous = groups.setdefault(digest, entry["group_id"])
            if previous != entry["group_id"]:
                _fail(f"identical {kind} hash spans component IDs for {item_id}")
        ids = LB.model_input_ids(tokenizer, item)
        if len(ids) != entry["input_tokens"]:
            _fail(f"manifest token count for {item_id} is {entry['input_tokens']}, "
                  f"rendered {len(ids)}")
        if not len(ids) <= entry["input_tokens"] <= MAX_INPUT:
            _fail(f"full prompt/reserve bound fails for {item_id}")
        if entry["split"] == split:
            selected.append((item, entry, ids))
    for left_index, left in enumerate(SPLITS):
        for right in SPLITS[left_index + 1:]:
            if context_splits[left] & context_splits[right]:
                _fail(f"context hashes overlap {left} and {right}")
            if question_splits[left] & question_splits[right]:
                _fail(f"question hashes overlap {left} and {right}")
    expected = int(manifest["split_counts"][split]["rows"])
    if len(selected) != expected:
        _fail(f"split {split} selected {len(selected)} rows, expected {expected}")
    if not selected:
        _fail(f"split {split} is empty")
    return selected


def parse_csv(value: str, description: str) -> list[str]:
    values = [part.strip() for part in str(value).split(",") if part.strip()]
    if not values:
        _fail(f"{description} must not be empty")
    if len(set(values)) != len(values):
        _fail(f"{description} contains duplicates: {values}")
    return values


def resolve_menu(split: str, raw_arms: Sequence[str], choice_diagnostic: bool,
                 requested_candidates: Sequence[str]
                 ) -> tuple[list[str], dict[str, BL.Baseline], list[str]]:
    raw = tuple(raw_arms)
    if split == "qualification":
        expected_raw = QUALIFICATION_RAW_ARMS
        expected_candidates = ["uniform"]
    elif split == "development":
        expected_raw = DEVELOPMENT_RAW_ARMS
        expected_candidates = list(DEVELOPMENT_LABELS[1:])
    else:
        _fail("confirmation execution requires a later locked-policy manifest; this v1 "
              "runner only executes qualification and development")
    if raw != expected_raw:
        _fail(f"{split} arms must be exactly {expected_raw}, got {raw}")
    try:
        labels, baselines = BL.resolve_arms(list(raw))
    except ValueError as exc:
        _fail(f"invalid arm menu: {exc}")
    expected_labels = (["fp", "uniform"] if split == "qualification"
                       else list(DEVELOPMENT_LABELS))
    if labels != expected_labels:
        _fail(f"resolved arm order {labels} differs from {expected_labels}")
    candidates = list(requested_candidates)
    if not choice_diagnostic:
        _fail(
            f"{split} requires --choice-diagnostic and the frozen candidate menu; "
            "an accuracy-only GPU run is incomplete"
        )
    if candidates != expected_candidates:
        _fail(f"{split} choice candidates must be exactly {expected_candidates}, "
              f"got {candidates}")
    return labels, baselines, candidates


def validate_choice_token_contract(prefix_tokens: Sequence[int],
                                   branch_ids: Mapping[str, int]) -> None:
    prefix = tuple(int(token) for token in prefix_tokens)
    branches = {str(key): int(value) for key, value in branch_ids.items()}
    if prefix != CHOICE_PREFIX_TOKENS or branches != CHOICE_BRANCH_IDS:
        _fail(
            "canonical A/B/C/D token contract drifted: "
            f"prefix={list(prefix)}, branches={branches}"
        )


def choice_branch_logits(model: Any, past: Any, last_prompt_token: int,
                         prefix_tokens: Sequence[int], branch_ids: Mapping[str, int],
                         bits_by_layer: Mapping[int, torch.Tensor] | None,
                         rotation: torch.Tensor, norm_correct: bool, L0: int,
                         device: torch.device | str | None = None) -> torch.Tensor:
    """Evaluate A/B/C/D at the frozen canonical response branch.

    Each call restores the same prompt boundary, applies one complete cache
    policy, then feeds ``[last_prompt_token] + canonical_prefix``.  The returned
    tensor has four transient float32 logits in A/B/C/D order.
    """
    if not prefix_tokens:
        raise ValueError("canonical choice prefix must not be empty")
    if tuple(branch_ids) != tuple("ABCD") or len(set(branch_ids.values())) != 4:
        raise ValueError("branch_ids must contain four unique A/B/C/D token IDs")
    R8.C.crop_to(past, int(L0))
    R8.C.STATE.reset_arm()
    if R8.C.STATE.capture or R8.C.STATE.capture_q:
        raise RuntimeError("choice diagnostic requires capture to be disabled")
    try:
        if bits_by_layer is not None:
            R8.C.apply_bits(
                past, {int(layer): bits.long() for layer, bits in bits_by_layer.items()},
                rotation, bool(norm_correct))
        if device is None:
            device = rotation.device
        tokens = [int(last_prompt_token)] + [int(token) for token in prefix_tokens]
        # The multi-token call remains compressed: sieve_compress_attention routes
        # q_len > 1 with STATE.enabled through _question_view, which substitutes
        # the compressed context and adds causal/eviction masks.  The R8
        # compressed-question test pins equivalence to token-by-token decode and
        # proves evicted context has zero influence.
        input_ids = torch.tensor([tokens], dtype=torch.long, device=device)
        with torch.no_grad():
            output = model(input_ids, past_key_values=past, use_cache=True)
        logits = output.logits
        if not isinstance(logits, torch.Tensor) or logits.ndim != 3:
            raise ValueError("model choice logits must have shape [1, sequence, vocab]")
        if logits.shape[0] != 1 or logits.shape[1] != len(tokens):
            raise ValueError(f"model choice logits have shape {tuple(logits.shape)}, "
                             f"expected [1,{len(tokens)},vocab]")
        ordered_ids = [int(branch_ids[choice]) for choice in "ABCD"]
        if min(ordered_ids) < 0 or max(ordered_ids) >= logits.shape[-1]:
            raise ValueError("choice branch token lies outside the model vocabulary")
        return logits[0, -1, ordered_ids].detach().to(dtype=torch.float32)
    finally:
        R8.C.STATE.enabled = False


def decode_complete_policy(model: Any, past: Any, ids: torch.Tensor,
                           bits_by_layer: Mapping[int, torch.Tensor] | None,
                           rotation: torch.Tensor, norm_correct: bool,
                           eos: set[int], L0: int) -> tuple[list[int], Any]:
    """Natural-task greedy decode to EOS/cap via verified ``run_bits``.

    Passing ``tok=None`` is deliberate: R8's decoder then retains its verified
    greedy/cache behavior but disables the RULER-only newline early stop.
    """
    return R8.run_bits(
        model, past, ids, bits_by_layer, rotation, norm_correct, eos,
        MAX_NEW, L0, None, None)


def validate_accuracy_rows(rows: Sequence[Mapping[str, Any]], item_ids: Sequence[str],
                           arm_order: Sequence[str]) -> None:
    expected = {(item_id, arm) for item_id in item_ids for arm in arm_order}
    observed = [(str(row["item_id"]), str(row["arm"])) for row in rows]
    if len(observed) != len(expected) or set(observed) != expected:
        _fail(f"accuracy row keys differ from exact split x arms: got {len(observed)}, "
              f"expected {len(expected)}")
    if len(set(observed)) != len(observed):
        _fail("accuracy artifact contains duplicate id/arm keys")
    for row in rows:
        expected_budget = 0 if row["arm"] == "fp" else BUDGET
        if row["B"] != expected_budget:
            _fail(f"row {row['item_id']}/{row['arm']} has B={row['B']}, expected "
                  f"{expected_budget}")
        if row["score"] not in (0.0, 1.0):
            _fail("LongBench accuracy score must be binary")
        if not row["valid"] and row["score"] != 0.0:
            _fail("invalid official parse must score zero")
        if not 0 <= int(row["gen_len"]) <= MAX_NEW:
            _fail("generation length lies outside the frozen cap")
        if bool(row["reached_max_new"]) != (int(row["gen_len"]) == MAX_NEW):
            _fail("generation cap flag disagrees with generation length")
        if int(row["input_tokens"]) > MAX_INPUT:
            _fail("output row exceeds the no-truncation input bound")
        if row["arm"] != "fp" and float(row["bits_per_token"]) > BUDGET + 1e-7:
            _fail("compressed row exceeds the equal-memory budget")


def validate_choice_rows(rows: Sequence[Mapping[str, Any]], item_ids: Sequence[str],
                         candidates: Sequence[str]) -> None:
    expected = {(item_id, candidate) for item_id in item_ids for candidate in candidates}
    observed = [(str(row["item_id"]), str(row["candidate"])) for row in rows]
    if len(observed) != len(expected) or set(observed) != expected:
        _fail("choice diagnostic row keys differ from exact split x candidates")
    if len(set(observed)) != len(observed):
        _fail("choice diagnostic contains duplicate id/candidate keys")
    order = {candidate: index for index, candidate in enumerate(candidates)}
    for item_id in item_ids:
        block = [row for row in rows if row["item_id"] == item_id]
        if sorted(int(row["candidate_order"]) for row in block) != list(range(len(candidates))):
            _fail(f"choice candidate order is incomplete for {item_id}")
        selected = {row["selected_policy"] for row in block}
        if len(selected) != 1 or next(iter(selected)) not in order:
            _fail(f"choice selection is invalid for {item_id}")
        for row in block:
            if not math.isfinite(float(row["choice_kl"])) or float(row["choice_kl"]) < -1e-6:
                _fail(f"choice KL is invalid for {item_id}/{row['candidate']}")
            if row["B"] != BUDGET:
                _fail("choice diagnostic budget drifted")


def _common_row(item: Mapping[str, str], entry: Mapping[str, Any], *, split: str,
                manifest_content_hash: str, manifest_file_hash: str,
                prompt_ids: Sequence[int], protocol: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "item_id": item["_id"],
        "group_id": entry["group_id"],
        "split": split,
        "domain": item["domain"],
        "sub_domain": item["sub_domain"],
        "difficulty": item["difficulty"],
        "length": item["length"],
        "context_hash": entry["context_hash"],
        "question_hash": sha256_text(item["question"].strip()),
        "prompt_token_hash": PD.token_hash(prompt_ids),
        "input_tokens": len(prompt_ids),
        "n_prompt_tokens": len(prompt_ids),
        "truncated": False,
        "dataset_sha256": LB.DATASET_SHA256,
        "manifest_content_sha256": manifest_content_hash,
        "manifest_file_sha256": manifest_file_hash,
        "task_version": LB.TASK_VERSION,
        "parser_version": LB.PARSER_VERSION,
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": _protocol_value(protocol, "model.revision"),
        # Tokenizer files are loaded from the same pinned Hub snapshot.  The
        # manifest pins one model revision rather than a second alias.
        "tokenizer_revision": LB.MODEL_REVISION,
        "ctx": CTX,
        "max_new_tokens": MAX_NEW,
        "window": WINDOW,
    }


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, default=str) + "\n")


def _sidecar_base(*, args: argparse.Namespace, manifest: Mapping[str, Any],
                  manifest_path: Path, manifest_file_hash: str,
                  chat_template_hash: str, item_ids: Sequence[str],
                  raw_arms: Sequence[str], arm_labels: Sequence[str],
                  baselines: Mapping[str, BL.Baseline], elapsed_s: float) -> dict[str, Any]:
    import tokenizers
    import transformers

    return {
        "runner_version": RUNNER_VERSION,
        "dataset_repo": LB.DATASET_REPO,
        "dataset_revision": LB.DATASET_REVISION,
        "dataset_sha256": LB.DATASET_SHA256,
        "dataset_bytes": LB.DATASET_BYTES,
        "official_code_repo": LB.OFFICIAL_CODE_REPO,
        "official_code_revision": LB.OFFICIAL_CODE_REVISION,
        "official_prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
        "task_version": LB.TASK_VERSION,
        "parser_version": LB.PARSER_VERSION,
        "context_hash_version": LB.CONTEXT_HASH_VERSION,
        "choice_logit_version": LB.CHOICE_LOGIT_VERSION,
        "manifest": str(manifest_path),
        "manifest_version": manifest["manifest_version"],
        "manifest_content_sha256": manifest["content_sha256"],
        "manifest_file_sha256": manifest_file_hash,
        "eligible_list_sha256": manifest["eligible_list_sha256"],
        "split": args.split,
        "split_count": len(item_ids),
        "split_ids_sha256": canonical_ids_sha256(item_ids),
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": _protocol_value(manifest["protocol"], "model.revision"),
        "tokenizer_revision": LB.MODEL_REVISION,
        "ctx": CTX,
        "max_input_tokens": MAX_INPUT,
        "max_new_tokens": MAX_NEW,
        "decode": "greedy_eos_or_cap",
        "temperature": 0.0,
        "window": WINDOW,
        "budget": BUDGET,
        "cascade_bits": CASCADE_BITS,
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
        "attn_impl": C.IMPL,
        "allocator_budget_rule": "feasible",
        "compress_at": "official_chat_prompt_end",
        "raw_arms": list(raw_arms),
        "arms": list(arm_labels),
        "baselines": {label: baseline.config_record()
                      for label, baseline in baselines.items()} or None,
        "allocation_id_algorithm": R8.ALLOCATION_ID_ALGORITHM,
        "chat_template_sha256": chat_template_hash,
        "transformers_version": transformers.__version__,
        "tokenizers_version": tokenizers.__version__,
        "no_truncation": True,
        "no_raw_logits": True,
        "elapsed_s": float(elapsed_s),
    }


def run(args: argparse.Namespace) -> tuple[Path, Path | None]:
    if args.model != MODEL_TAG or args.ctx != CTX:
        _fail(f"V4 v1 requires --model {MODEL_TAG} --ctx {CTX}")
    if args.budget != BUDGET or args.window != WINDOW:
        _fail(f"V4 v1 requires --budget {BUDGET} --window {WINDOW}")
    raw_arms = parse_csv(args.arms, "--arms")
    requested_candidates = (parse_csv(args.choice_candidates, "--choice-candidates")
                            if args.choice_candidates else [])
    arm_labels, baselines, candidates = resolve_menu(
        args.split, raw_arms, args.choice_diagnostic, requested_candidates)
    too_long = {label: baseline.score_opts["obs"]
                for label, baseline in baselines.items()
                if baseline.score_opts["obs"] > WINDOW}
    if too_long:
        _fail(f"baseline observation windows exceed the frozen window: {too_long}")

    manifest_path = Path(args.manifest).resolve()
    manifest, manifest_file_hash = load_manifest(manifest_path)
    validate_protocol_static(manifest)
    data = LB.load_dataset(args.dataset, authenticate=True)

    config = run_h0.load_cfg(args.config, MODEL_TAG, [])
    if config.get("id") != MODEL_ID:
        _fail(f"models.yaml maps {MODEL_TAG} to {config.get('id')!r}, expected {MODEL_ID}")
    if int(config.get("native_ctx", config["ctx"])) < CTX:
        _fail("model registry native context is shorter than 32768")
    frozen_config = {
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
    }
    observed_config = {
        "dtype": config.get("dtype"),
        "bit_list": list(config.get("bit_list", [])),
        "maxb": int(config.get("maxb", -1)),
        "rot_seed": int(config.get("rot_seed", -1)),
        "norm_correct": config.get("norm_correct"),
        "chunk": int(config.get("chunk", -1)),
    }
    if observed_config != frozen_config:
        _fail(f"model execution config {observed_config} differs from frozen "
              f"{frozen_config}")
    model_revision = _protocol_value(manifest["protocol"], "model.revision")

    from transformers import AutoModelForCausalLM, AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID, revision=model_revision, trust_remote_code=True)
    chat_template_hash = validate_runtime_protocol(manifest["protocol"], tokenizer)
    selected = authenticate_examples(data, manifest, tokenizer, args.split)
    item_ids = [item["_id"] for item, _, _ in selected]

    C.install()
    dtype = getattr(torch, DTYPE_NAME)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID, revision=model_revision, dtype=dtype,
        device_map=config.get("device_map", "auto"),
        attn_implementation=C.IMPL, trust_remote_code=True).eval()
    device = next(model.parameters()).device
    cf = model.config
    n_layers = int(cf.num_hidden_layers)
    head_dim = getattr(cf, "head_dim", None) or cf.hidden_size // cf.num_attention_heads
    rot_seed = ROT_SEED
    rotation = quant.random_rotation(head_dim, device, torch.float32, seed=rot_seed)
    norm_correct = NORM_CORRECT
    bit_list = list(BIT_LIST)
    maxb = MAXB
    if not router.is_width(BUDGET, maxb, bit_list):
        _fail(f"uniform B={BUDGET} is absent from model bit list {bit_list}")
    eos = R8.eos_ids(model, tokenizer)
    chunk = CHUNK
    wo = BL.wo_gram(model) if any(baseline.needs_wo for baseline in baselines.values()) else None
    want, routers, need_err = R8.p2_wants(arm_labels, False, "")
    if routers or need_err:
        _fail("V4 fixed policies must not activate routes or head-error oracles")
    plan = [("fp", 0)] + [(arm, BUDGET) for arm in arm_labels if arm != "fp"]
    prefix_tokens: list[int] = []
    branch_ids: dict[str, int] = {}
    if args.choice_diagnostic:
        prefix_tokens, branch_ids = LB.choice_logit_contract(tokenizer)
        validate_choice_token_contract(prefix_tokens, branch_ids)

    print(f"V4 LongBench-v2 {args.split}: {len(selected)} items, "
          f"arms={arm_labels}, B={BUDGET}, window={WINDOW}, max_new={MAX_NEW}",
          flush=True)
    accuracy_rows: list[dict[str, Any]] = []
    choice_rows: list[dict[str, Any]] = []
    start_all = time.time()
    for item_index, (item, entry, prompt_ids) in enumerate(selected):
        ids = torch.tensor([prompt_ids], dtype=torch.long, device=device)
        t0 = time.time()
        past, _ = R8.prefill(model, ids, WINDOW, chunk, h2o=False)
        L0 = C.cache_len(past)
        t_prefill = time.time() - t0
        if L0 != len(prompt_ids) - 1:
            _fail(f"{item['_id']}: prefill boundary {L0} != prompt length - 1")
        if L0 - C.STATE.ctx_len != WINDOW:
            _fail(f"{item['_id']}: observed {L0 - C.STATE.ctx_len} prompt queries, "
                  f"expected {WINDOW}")

        t0 = time.time()
        bits, errors, route_log, answer_mass = R8.precompute(
            past, L0, want, [], [BUDGET], rotation, norm_correct,
            maxb, bit_list, n_layers, cascade_bits=CASCADE_BITS,
            need_err=False, routes={}, theta=1.0, ans_mask=None,
            bls=baselines, wo=wo)
        t_precompute = time.time() - t0
        if errors or route_log or answer_mass:
            _fail(f"{item['_id']}: fixed-policy precompute produced oracle data")
        expected_bit_keys = {(arm, BUDGET) for arm in arm_labels if arm != "fp"}
        if set(bits) != expected_bit_keys:
            _fail(f"{item['_id']}: allocation keys {set(bits)} != {expected_bit_keys}")
        allocation_ids = {("fp", 0): R8.allocation_id(None)}
        allocation_ids.update({key: R8.allocation_id(value) for key, value in bits.items()})
        common = _common_row(
            item, entry, split=args.split,
            manifest_content_hash=manifest["content_sha256"],
            manifest_file_hash=manifest_file_hash, prompt_ids=prompt_ids,
            protocol=manifest["protocol"])

        fp_greedy_parsed_answer = None
        fp_greedy_valid = False
        for arm, budget in plan:
            t0 = time.time()
            policy_bits = None if arm == "fp" else bits[(arm, budget)]
            generated, past = decode_complete_policy(
                model, past, ids, policy_bits, rotation, norm_correct, eos, L0)
            elapsed = time.time() - t0
            response = tokenizer.decode(generated, skip_special_tokens=True)
            scored = LB.score_response(response, item["answer"])
            audit = ({"bits_per_token": 16.0, "evict_frac": 0.0}
                     if arm == "fp" else C.bits_audit())
            if arm != "fp" and float(audit["bits_per_token"]) > BUDGET + 1e-7:
                _fail(f"{item['_id']} {arm} spent {audit['bits_per_token']} > {BUDGET}")
            if arm == "fp":
                fp_greedy_parsed_answer = scored["parsed_answer"]
                fp_greedy_valid = bool(scored["valid"])
            accuracy_rows.append({
                **common,
                "arm": arm,
                "B": budget,
                "gold_answer": item["answer"],
                "response": response,
                "parsed_answer": scored["parsed_answer"],
                "valid": bool(scored["valid"]),
                "score": float(scored["score"]),
                "gen_len": len(generated),
                "reached_max_new": len(generated) == MAX_NEW,
                "bits_per_token": float(audit["bits_per_token"]),
                "evict_frac": float(audit["evict_frac"]),
                "allocation_id": allocation_ids[(arm, budget)],
                "ctx_len": int(C.STATE.ctx_len),
                "observed_queries": int(L0 - C.STATE.ctx_len),
                "maxb": maxb,
                "rot_seed": rot_seed,
                "norm_correct": norm_correct,
                "t_prefill": t_prefill,
                "t_precompute": t_precompute,
                "t_arm": elapsed,
            })

        if args.choice_diagnostic:
            fp_choice = choice_branch_logits(
                model, past, prompt_ids[-1], prefix_tokens, branch_ids,
                None, rotation, norm_correct, L0, device)
            metrics_by_candidate: dict[str, dict[str, float | int]] = {}
            block_rows = []
            for candidate_order, candidate in enumerate(candidates):
                t0 = time.time()
                candidate_choice = choice_branch_logits(
                    model, past, prompt_ids[-1], prefix_tokens, branch_ids,
                    bits[(candidate, BUDGET)], rotation, norm_correct, L0, device)
                metrics = PD.choice_divergence_metrics(fp_choice, candidate_choice)
                elapsed = time.time() - t0
                metrics_by_candidate[candidate] = metrics
                block_rows.append({
                    **common,
                    "B": BUDGET,
                    "candidate": candidate,
                    "candidate_order": candidate_order,
                    **metrics,
                    "fp_canonical_choice": "ABCD"[
                        int(metrics["fp_choice_index"])],
                    "candidate_canonical_choice": "ABCD"[
                        int(metrics["candidate_choice_index"])],
                    "fp_greedy_parsed_answer": fp_greedy_parsed_answer,
                    "fp_greedy_valid": fp_greedy_valid,
                    "fp_canonical_agrees_with_greedy": bool(
                        fp_greedy_valid and
                        "ABCD"[int(metrics["fp_choice_index"])] ==
                        fp_greedy_parsed_answer),
                    "choice_rule_version": PD.CHOICE_RULE_VERSION,
                    "choice_logit_version": LB.CHOICE_LOGIT_VERSION,
                    "choice_prefix_token_hash": PD.token_hash(prefix_tokens),
                    "choice_branch_ids_hash": PD.token_hash(
                        [branch_ids[choice] for choice in "ABCD"]),
                    "allocation_id": allocation_ids[(candidate, BUDGET)],
                    "t_choice": elapsed,
                })
                del candidate_choice
            selected_policy = PD.select_min_choice_kl(
                metrics_by_candidate, candidates)
            for row in block_rows:
                row["selected_policy"] = selected_policy
            choice_rows.extend(block_rows)
            del fp_choice

        print(f"  {item_index + 1:3d}/{len(selected)} {item['_id']} "
              f"n={len(prompt_ids):,} prefill={t_prefill:.1f}s", flush=True)
        del past, bits
        if device.type == "cuda":
            torch.cuda.empty_cache()

    elapsed_all = time.time() - start_all
    validate_accuracy_rows(accuracy_rows, item_ids, arm_labels)
    if args.choice_diagnostic:
        validate_choice_rows(choice_rows, item_ids, candidates)
    elif choice_rows:
        _fail("choice rows were produced without --choice-diagnostic")

    output_dir = Path(args.out_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"longbench_v2_{args.split}_{MODEL_TAG}_{CTX}"
    accuracy_path = output_dir / f"{stem}.parquet"
    accuracy_df = pd.DataFrame(accuracy_rows)
    accuracy_df.to_parquet(accuracy_path, index=False)
    choice_path: Path | None = None
    choice_df: pd.DataFrame | None = None
    if args.choice_diagnostic:
        choice_path = output_dir / f"longbench_v2_choice_{args.split}_{MODEL_TAG}_{CTX}.parquet"
        choice_df = pd.DataFrame(choice_rows)
        choice_df.to_parquet(choice_path, index=False)

    base_sidecar = _sidecar_base(
        args=args, manifest=manifest, manifest_path=manifest_path,
        manifest_file_hash=manifest_file_hash,
        chat_template_hash=chat_template_hash, item_ids=item_ids,
        raw_arms=raw_arms, arm_labels=arm_labels, baselines=baselines,
        elapsed_s=elapsed_all)
    accuracy_sidecar = {
        **base_sidecar,
        "artifact": "end_task_accuracy",
        "parquet": accuracy_path.name,
        "parquet_sha256": LB.sha256_file(accuracy_path),
        "rows": len(accuracy_df),
        "expected_rows": len(item_ids) * len(arm_labels),
        "row_key": ["item_id", "arm"],
        "official_invalid_scores_zero": True,
        "choice_diagnostic": bool(args.choice_diagnostic),
    }
    if choice_path is not None:
        accuracy_sidecar.update(
            choice_parquet=choice_path.name,
            choice_sha256=LB.sha256_file(choice_path),
            choice_rows=len(choice_rows),
        )
    _write_json(accuracy_path.with_suffix(".json"), accuracy_sidecar)

    if choice_path is not None:
        assert choice_df is not None
        choice_sidecar = {
            **base_sidecar,
            "artifact": "choice_logit_diagnostic",
            "parquet": choice_path.name,
            "parquet_sha256": LB.sha256_file(choice_path),
            "rows": len(choice_df),
            "expected_rows": len(item_ids) * len(candidates),
            "row_key": ["item_id", "candidate"],
            "candidates": candidates,
            "selector": "minimum_choice_kl_exact_ties_declared_order",
            "choice_rule_version": PD.CHOICE_RULE_VERSION,
            "canonical_responses": list(LB.CANONICAL_RESPONSES),
            "choice_prefix_token_hash": PD.token_hash(prefix_tokens),
            "choice_branch_ids": branch_ids,
            "accuracy_parquet": accuracy_path.name,
            "accuracy_sha256": LB.sha256_file(accuracy_path),
            "accuracy_rows": len(accuracy_rows),
            "no_raw_logits": True,
        }
        _write_json(choice_path.with_suffix(".json"), choice_sidecar)

    print(f"wrote {accuracy_path} ({len(accuracy_rows)} rows)")
    if choice_path is not None:
        print(f"wrote {choice_path} ({len(choice_rows)} rows)")
    return accuracy_path, choice_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--dataset", required=True,
                        help="pinned LongBench-v2 data.json")
    parser.add_argument(
        "--manifest",
        default=str(HERE / "bugs/9_sota_eviction_baselines/longbench_v2_manifest.json"))
    parser.add_argument("--split", required=True, choices=SPLITS)
    parser.add_argument("--config", default=str(HERE / "models.yaml"))
    parser.add_argument("--model", default=MODEL_TAG)
    parser.add_argument("--ctx", type=int, default=CTX)
    parser.add_argument("--arms", required=True,
                        help="ordered raw arm specifications")
    parser.add_argument("--budget", type=int, default=BUDGET)
    parser.add_argument("--window", type=int, default=WINDOW)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--choice-diagnostic", action="store_true")
    parser.add_argument("--choice-candidates", default="",
                        help="ordered resolved candidate labels")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        run(args)
    except (LongBenchRunnerError, ValueError, OSError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
