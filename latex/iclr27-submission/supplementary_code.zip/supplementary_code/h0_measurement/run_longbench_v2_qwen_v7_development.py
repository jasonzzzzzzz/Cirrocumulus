#!/usr/bin/env python3
"""Run the lock-authorized V7 structured-query development study.

This is the only model-execution entry point for the frozen 52-row V7
LongBench-v2 development split.  It authenticates the advancing qualification
lock, its source ledger, and its artifacts before any tokenizer/model load and
again before writing output.  The emitted artifact contains scalar forced-choice
summaries only: no benchmark label, proxy, raw probability vector, or logit.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from h0_measurement import audit_longbench_v2_qwen_v7 as QA  # noqa: E402
from h0_measurement import run_longbench_v2_qwen_v7_qualification as QUAL  # noqa: E402
from sievelib import compress as C  # noqa: E402
from sievelib import forced_choice as FC  # noqa: E402
from sievelib import policy_diagnostic as PD  # noqa: E402
from sievelib import quant, router  # noqa: E402
from sievelib import structured_policy as SP  # noqa: E402
from sievelib import tasks_longbench_v2 as LB  # noqa: E402
import run_h0  # noqa: E402
import run_r8 as R8  # noqa: E402


PROTOCOL_VERSION = "longbench_v2_sieve_v7_qwen131072_development_v1"
RUNNER_VERSION = "longbench_v2_qwen_v7_development_runner_v1"
TASK_VERSION = QUAL.TASK_VERSION
ENDPOINT_VERSION = QUAL.ENDPOINT_VERSION
QUALIFICATION_LOCK_VERSION = "longbench_v2_sieve_v7_qwen131072_qualification_lock_v1"
QUALIFICATION_READER_VERSION = "longbench_v2_qwen_v7_qualification_reader_v1"
SOURCE_LEDGER_VERSION = "longbench_v2_sieve_v7_development_source_ledger_v1"
DEFAULT_SOURCE_LEDGER = (
    HERE / "bugs/9_sota_eviction_baselines/longbench_v2_qwen_v7_development_source_ledger.json"
)
SPLIT = "development"

MODEL_TAG = QA.MODEL_TAG
MODEL_ID = QA.MODEL_ID
MODEL_REVISION = QA.MODEL_REVISION
TOKENIZER_REVISION = QA.TOKENIZER_REVISION
CTX = QA.CONTEXT_WINDOW
MAX_PROMPT_TOKENS = CTX - len(QA.SCAFFOLD_TOKEN_IDS)
WINDOW = 32
BUDGET = 2
DTYPE_NAME = "bfloat16"
BIT_LIST = (1, 2, 3, 4, 5, 6, 8)
MAXB = 8
ROT_SEED = 0
NORM_CORRECT = True
CHUNK = 4096
N_LAYERS = 48
N_ATTENTION_HEADS = 32
N_KV_HEADS = 4
HEAD_DIM = 128
NUMPY_VERSION = QUAL.NUMPY_VERSION
PANDAS_VERSION = QUAL.PANDAS_VERSION
PYARROW_VERSION = QUAL.PYARROW_VERSION
FASTPARQUET_VERSION = QUAL.FASTPARQUET_VERSION
TORCH_VERSION = QUAL.TORCH_VERSION
TRANSFORMERS_VERSION = QUAL.TRANSFORMERS_VERSION
TOKENIZERS_VERSION = QUAL.TOKENIZERS_VERSION
PARQUET_ENGINE = QUAL.PARQUET_ENGINE
if (
    np.__version__ != NUMPY_VERSION
    or pd.__version__ != PANDAS_VERSION
    or torch.__version__ != TORCH_VERSION
    or PARQUET_ENGINE != "fastparquet"
    or FASTPARQUET_VERSION == "not_installed"
):
    raise RuntimeError("the frozen V7 development dependency contract drifted")

ARMS = (
    "fp", "uniform", "tail_evict", "tail_interior",
    "structured_evict", "structured_interior",
)
CANDIDATES = ARMS[1:]
OLD_MENU = ("uniform", "tail_evict", "tail_interior")
STRUCTURED_MENU = ("structured_evict", "structured_interior")
SCORE_QUERY_SOURCES = {
    "fp": "none", "uniform": "none",
    "tail_evict": "tail_32", "tail_interior": "tail_32",
    "structured_evict": "structured_question_choices",
    "structured_interior": "structured_question_choices",
}
EXPECTED_ITEMS = 52
EXPECTED_COMPONENTS = 52
EXPECTED_PREDICTION_ROWS = EXPECTED_ITEMS * len(ARMS)
PREDICTION_BASENAME = "longbench_v2_v7_qwen131072_forced_choice_development"

COMMON_COLUMNS = (
    "item_id", "group_id", "split", "domain", "sub_domain", "difficulty",
    "length", "context_hash", "question_hash", "prompt_token_hash",
    "input_tokens", "n_prompt_tokens", "truncated", "dataset_sha256",
    "manifest_content_sha256", "manifest_file_sha256", "task_version",
    "endpoint_version", "model", "model_id", "model_revision",
    "tokenizer_revision", "ctx", "window",
)
PREDICTION_COLUMNS = COMMON_COLUMNS + (
    "B", "arm", "arm_order", "forced_choice", "choice_index",
    "choice_entropy", "choice_margin", "choice_max_probability",
    "scaffold_token_hash", "choice_branch_ids_hash", "bits_per_token",
    "evict_frac", "allocation_id", "ctx_len", "score_query_source",
    "score_query_count", "maxb",
    "rot_seed", "norm_correct",
)
FORBIDDEN_RESULT_COLUMNS = {
    "answer", "gold", "gold_answer", "label", "correct", "correctness",
    "score", "response", "parsed_answer", "logit", "logits", "raw_logits",
    "probability", "probabilities", "probs", "choice_logits", "choice_probs",
}

QUALIFICATION_THRESHOLDS = {
    "bootstrap_draws": 10000,
    "bootstrap_seed": 0,
    "bootstrap_rng": "numpy.Generator(PCG64)",
    "bootstrap_quantile": 0.05,
    "bootstrap_quantile_method": "linear",
    "chance": 0.25,
    "qualification_fp_accuracy_min": 0.50,
    "qualification_fp_q05_strictly_above": 0.25,
    "qualification_uniform_accuracy_interval": [0.30, 0.80],
    "qualification_uniform_q05_strictly_above": 0.25,
    "development_fp_accuracy_min": 0.50,
    "development_fp_q05_strictly_above": 0.25,
    "development_F_star_accuracy_interval": [0.30, 0.80],
    "development_F_star_q05_strictly_above": 0.25,
    "development_H_min": 0.10,
    "development_H_q05_strictly_above": 0.0,
    "development_H_each_half_min": 0.05,
    "development_S_min": 0.05,
}


class QwenV7DevelopmentRunnerError(RuntimeError):
    """The frozen V7 development execution contract was violated."""


def _fail(message: str) -> None:
    raise QwenV7DevelopmentRunnerError(message)


def _same(expected: Any, actual: Any, description: str) -> None:
    if expected != actual:
        _fail(f"{description}: expected {expected!r}, got {actual!r}")


def _regular(path: str | os.PathLike[str], label: str) -> Path:
    candidate = Path(path).expanduser()
    if candidate.is_symlink() or not candidate.is_file():
        _fail(f"{label} must be an existing regular non-symlink file: {candidate}")
    return candidate.resolve()


def _load_object(path: str | os.PathLike[str], label: str) -> dict[str, Any]:
    candidate = _regular(path, label)
    try:
        value = json.loads(candidate.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _fail(f"cannot read {label} {candidate}: {exc}")
    if not isinstance(value, dict):
        _fail(f"{label} must contain one JSON object")
    return value


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")


def _content_sha256(value: Mapping[str, Any]) -> str:
    payload = dict(value)
    payload.pop("content_sha256", None)
    return hashlib.sha256(_canonical_json(payload)).hexdigest()


def _relative_source(path: str | os.PathLike[str]) -> str:
    resolved = Path(path).resolve()
    try:
        return str(resolved.relative_to(ROOT.resolve()))
    except ValueError as exc:
        raise QwenV7DevelopmentRunnerError(
            f"executed source {resolved} is outside repository root"
        ) from exc


def sealed_source_paths(config_path: str | Path) -> tuple[Path, ...]:
    """Reviewed full local import closure plus executed/config entry points."""
    return (
        Path(__file__), Path(QA.__file__), Path(QUAL.__file__),
        *(ROOT / relative for relative in QUAL.SEALED_SIEVELIB_RELATIVE_PATHS),
        Path(run_h0.__file__), Path(R8.__file__), Path(config_path),
        HERE / "bugs/9_sota_eviction_baselines/read_longbench_v2_qwen_v7_development.py",
        HERE / "submit_longbench_v2_qwen_v7_development.slurm",
    )


def sealed_source_hashes(config_path: str | Path) -> dict[str, str]:
    hashes: dict[str, str] = {}
    for path in sealed_source_paths(config_path):
        source = _regular(path, "executed V7 development source")
        relative = _relative_source(source)
        if relative in hashes:
            _fail(f"duplicate source seal path {relative}")
        hashes[relative] = LB.sha256_file(source)
    return hashes


def source_ledger_content_sha256(value: Mapping[str, Any]) -> str:
    return _content_sha256(value)


def source_ledger_object(config_path: str | Path) -> dict[str, Any]:
    ledger: dict[str, Any] = {
        "ledger_version": SOURCE_LEDGER_VERSION,
        "source_sha256": sealed_source_hashes(config_path),
    }
    ledger["content_sha256"] = source_ledger_content_sha256(ledger)
    return ledger


def executed_source_hashes(
    config_path: str | Path, source_ledger_path: str | Path
) -> dict[str, str]:
    hashes = sealed_source_hashes(config_path)
    ledger = _regular(source_ledger_path, "V7 development source ledger")
    relative = _relative_source(ledger)
    if relative in hashes:
        _fail(f"source ledger collides with a sealed source path: {relative}")
    hashes[relative] = LB.sha256_file(ledger)
    return hashes


def verify_source_ledger(
    source_ledger_path: str | Path, source_hashes: Mapping[str, str]
) -> dict[str, Any]:
    path = _regular(source_ledger_path, "V7 development source ledger")
    ledger = _load_object(path, "V7 development source ledger")
    _same(
        {"ledger_version", "source_sha256", "content_sha256"}, set(ledger),
        "development source ledger schema",
    )
    _same(SOURCE_LEDGER_VERSION, ledger["ledger_version"], "development source ledger version")
    _same(source_ledger_content_sha256(ledger), ledger["content_sha256"], "development source ledger content hash")
    expected = dict(source_hashes)
    relative = _relative_source(path)
    file_hash = expected.pop(relative, None)
    if file_hash is None:
        _fail("executed source hashes omit the development source ledger")
    _same(expected, ledger["source_sha256"], "development source ledger mapping")
    _same(LB.sha256_file(path), file_hash, "development source ledger file hash")
    return {
        "path": str(path),
        "relative_path": relative,
        "ledger_version": SOURCE_LEDGER_VERSION,
        "content_sha256": str(ledger["content_sha256"]),
        "file_sha256": file_hash,
    }


def _partition_record(
    manifest: Mapping[str, Any], *, split: str, first_half: int | None = None
) -> dict[str, Any]:
    entries = [row for row in manifest["examples"] if row["split"] == split]
    base = dict(manifest["split_counts"][split])
    if first_half is None:
        return base
    ordered = QA.partition_order(entries)
    halves = (ordered[:first_half], ordered[first_half:])
    if len(ordered) != QA.SPLIT_ROWS[split] or any(not half for half in halves):
        _fail(f"invalid frozen {split} partition")
    def digest(values: Sequence[str]) -> str:
        return hashlib.sha256(
            "".join(f"{item_id}\n" for item_id in values).encode("ascii")
        ).hexdigest()
    return {
        **base,
        "half_order": "sha256(selection_namespace_plus_item_id_ascii)_ascending_v1",
        "half_row_counts": [len(half) for half in halves],
        "half_component_counts": [len(half) for half in halves],
        "half_ordered_id_sha256": [digest(half) for half in halves],
    }


def _expected_execution() -> dict[str, Any]:
    """Exact execution object written by the frozen qualification reader."""
    return {
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "tokenizer_revision": TOKENIZER_REVISION,
        "chat_template_sha256": QA.CHAT_TEMPLATE_SHA256,
        "enable_thinking": QA.ENABLE_THINKING,
        "ctx": CTX,
        "window": WINDOW,
        "budget": BUDGET,
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
        "n_layers": N_LAYERS,
        "n_attention_heads": N_ATTENTION_HEADS,
        "n_kv_heads": N_KV_HEADS,
        "head_dim": HEAD_DIM,
        "uniform_allocation_contract": "48_layers_x_4_kv_x_ctx_len_all_uint8_2",
        "qualification_attn_impl": C.IMPL,
        "development_attn_impl": SP.IMPL,
        "structured_policy_impl": SP.IMPL,
        "structured_capture_version": SP.CAPTURE_VERSION,
        "structured_policy_source": _relative_source(SP.__file__),
        "structured_policy_source_sha256": LB.sha256_file(SP.__file__),
        "qualification_arms": ["fp", "uniform"],
        "development_arms": list(ARMS),
        "development_candidates": list(CANDIDATES),
        "old_menu": list(OLD_MENU),
        "structured_menu": list(STRUCTURED_MENU),
        "endpoint_version": ENDPOINT_VERSION,
        "scaffold_token_ids": list(QA.SCAFFOLD_TOKEN_IDS),
        "choice_branch_ids": dict(QA.CHOICE_BRANCH_IDS),
        "numpy_version": NUMPY_VERSION,
        "pandas_version": PANDAS_VERSION,
        "pyarrow_version": PYARROW_VERSION,
        "fastparquet_version": FASTPARQUET_VERSION,
        "parquet_engine": PARQUET_ENGINE,
    }


def development_execution() -> dict[str, Any]:
    """Exact V7 development mechanism contract for artifact/lock provenance."""
    return {
        "model": MODEL_TAG, "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "tokenizer_revision": TOKENIZER_REVISION,
        "chat_template_sha256": QA.CHAT_TEMPLATE_SHA256,
        "enable_thinking": QA.ENABLE_THINKING,
        "ctx": CTX, "window": WINDOW, "budget": BUDGET,
        "dtype": DTYPE_NAME, "bit_list": list(BIT_LIST), "maxb": MAXB,
        "rot_seed": ROT_SEED, "norm_correct": NORM_CORRECT, "chunk": CHUNK,
        "n_layers": N_LAYERS, "n_attention_heads": N_ATTENTION_HEADS,
        "n_kv_heads": N_KV_HEADS, "head_dim": HEAD_DIM,
        "attn_impl": SP.IMPL, "underlying_attn_impl": C.IMPL,
        "structured_capture_version": SP.CAPTURE_VERSION,
        "structured_query_groups": list(QA.CONTENT_GROUPS),
        "structured_max_tokens_per_group": QA.MAX_CONTENT_TOKENS_PER_GROUP,
        "structured_group_weight": 1.0 / len(QA.CONTENT_GROUPS),
        "uniform_allocation_contract": "48_layers_x_4_kv_x_ctx_len_all_uint8_2",
        "development_arms": list(ARMS),
        "development_candidates": list(CANDIDATES),
        "old_menu": list(OLD_MENU), "structured_menu": list(STRUCTURED_MENU),
        "endpoint_version": ENDPOINT_VERSION,
        "scaffold_token_ids": list(QA.SCAFFOLD_TOKEN_IDS),
        "choice_branch_ids": dict(QA.CHOICE_BRANCH_IDS),
        "one_full_precision_prefill_per_item": True,
        "layer_context_builds_per_layer": 1,
        "no_proxy": True,
        "numpy_version": NUMPY_VERSION, "pandas_version": PANDAS_VERSION,
        "pyarrow_version": PYARROW_VERSION,
        "fastparquet_version": FASTPARQUET_VERSION,
        "parquet_engine": PARQUET_ENGINE,
    }


def _validate_qualification_summary(summary: Mapping[str, Any]) -> None:
    expected = {
        "protocol_version", "split", "n_items", "n_components",
        "prediction_rows", "fp_correct", "fp_accuracy", "fp_bootstrap_q05",
        "uniform_correct", "uniform_accuracy", "uniform_bootstrap_q05",
        "fp_point_gate", "fp_bootstrap_gate", "uniform_point_gate",
        "uniform_bootstrap_gate", "decision",
    }
    _same(expected, set(summary), "qualification summary schema")
    _same("advance_v7_development", summary["decision"], "qualification decision")
    _same(QUAL.PROTOCOL_VERSION, summary["protocol_version"], "qualification protocol")
    _same("qualification", summary["split"], "qualification split")
    _same(20, int(summary["n_items"]), "qualification item count")
    _same(20, int(summary["n_components"]), "qualification component count")
    _same(40, int(summary["prediction_rows"]), "qualification prediction rows")
    fp, fp_q05 = float(summary["fp_accuracy"]), float(summary["fp_bootstrap_q05"])
    uni, uni_q05 = float(summary["uniform_accuracy"]), float(summary["uniform_bootstrap_q05"])
    if not (fp >= .50 and fp_q05 > .25 and .30 <= uni <= .80 and uni_q05 > .25):
        _fail("qualification summary does not satisfy the frozen V7 advance gates")
    for key in ("fp_point_gate", "fp_bootstrap_gate", "uniform_point_gate", "uniform_bootstrap_gate"):
        _same(True, summary[key], f"qualification {key}")
    _same(int(summary["fp_correct"]) / 20.0, fp, "qualification FP count/accuracy")
    _same(int(summary["uniform_correct"]) / 20.0, uni, "qualification uniform count/accuracy")


def _authenticate_recorded_sources(source_hashes: Mapping[str, Any], label: str) -> None:
    if not isinstance(source_hashes, Mapping) or not source_hashes:
        _fail(f"{label} source mapping is absent")
    for relative, expected in source_hashes.items():
        path = ROOT / str(relative)
        try:
            path.resolve().relative_to(ROOT.resolve())
        except ValueError:
            _fail(f"{label} source path escapes repository: {relative}")
        source = _regular(path, f"{label} source {relative}")
        _same(str(expected), LB.sha256_file(source), f"{label} source hash {relative}")


def authenticate_qualification_lock(
    path: str | os.PathLike[str], *, dataset_path: str | os.PathLike[str],
    legacy_manifest_path: str | os.PathLike[str], manifest_path: str | os.PathLike[str],
    config_path: str | os.PathLike[str], model_source: str | os.PathLike[str],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Authenticate the exact advancing lock and its inputs without model load."""
    lock_path = _regular(path, "V7 qualification lock")
    lock = _load_object(lock_path, "V7 qualification lock")
    expected_top = {
        "lock_version", "protocol_version", "runner_version", "reader_version",
        "task_version", "endpoint_version", "decision", "qualification",
        "provenance", "partitions", "execution", "thresholds", "content_sha256",
    }
    _same(expected_top, set(lock), "V7 qualification lock schema")
    _same(_content_sha256(lock), lock["content_sha256"], "V7 qualification lock content hash")
    _same(QUALIFICATION_LOCK_VERSION, lock["lock_version"], "V7 qualification lock version")
    _same("advance_v7_development", lock["decision"], "V7 qualification lock decision")
    _same(QUAL.PROTOCOL_VERSION, lock["protocol_version"], "V7 qualification protocol")
    _same(QUAL.RUNNER_VERSION, lock["runner_version"], "V7 qualification runner version")
    _same(QUALIFICATION_READER_VERSION, lock["reader_version"], "V7 qualification reader version")
    _same(TASK_VERSION, lock["task_version"], "V7 task version")
    _same(ENDPOINT_VERSION, lock["endpoint_version"], "V7 endpoint version")
    _same(_expected_execution(), lock["execution"], "locked V7 execution")
    _same(QUALIFICATION_THRESHOLDS, lock["thresholds"], "locked V7 thresholds")

    dataset = _regular(dataset_path, "LongBench-v2 dataset")
    legacy = _regular(legacy_manifest_path, "legacy V6 manifest")
    manifest_path = _regular(manifest_path, "V7 Qwen manifest")
    config = _regular(config_path, "model config")
    if dataset.stat().st_size != LB.DATASET_BYTES or LB.sha256_file(dataset) != LB.DATASET_SHA256:
        _fail("dataset bytes or SHA-256 differ from frozen LongBench-v2")
    _same(QA.LEGACY_MANIFEST_FILE_SHA256, LB.sha256_file(legacy), "legacy manifest file hash")
    _same(QA.FROZEN_MANIFEST_FILE_SHA256, LB.sha256_file(manifest_path), "V7 manifest file hash")
    manifest = _load_object(manifest_path, "V7 Qwen manifest")
    _same(QA.FROZEN_MANIFEST_CONTENT_SHA256, manifest.get("content_sha256"), "V7 manifest content hash")
    _same(QA.manifest_content_sha256(manifest), manifest.get("content_sha256"), "recomputed V7 manifest content hash")
    _same(
        {
            "qualification": _partition_record(manifest, split="qualification"),
            "development": _partition_record(manifest, split="development", first_half=26),
            "confirmation": _partition_record(manifest, split="confirmation", first_half=22),
            "within_split_order": "sha256(selection_namespace_plus_item_id_ascii)_ascending_v1",
        },
        lock["partitions"],
        "locked V7 partitions",
    )

    qualification = lock["qualification"]
    _same({"predictions", "predictions_sha256", "sidecar", "sidecar_sha256", "summary"}, set(qualification), "qualification artifact schema")
    predictions = _regular(qualification["predictions"], "qualification predictions")
    q_sidecar_path = _regular(qualification["sidecar"], "qualification sidecar")
    _same(qualification["predictions_sha256"], LB.sha256_file(predictions), "qualification predictions hash")
    _same(qualification["sidecar_sha256"], LB.sha256_file(q_sidecar_path), "qualification sidecar hash")
    q_sidecar = _load_object(q_sidecar_path, "qualification sidecar")
    _same(predictions.name, q_sidecar.get("parquet"), "qualification sidecar parquet")
    _same(qualification["predictions_sha256"], q_sidecar.get("parquet_sha256"), "qualification sidecar parquet hash")
    _same(QUAL.PROTOCOL_VERSION, q_sidecar.get("protocol_version"), "qualification sidecar protocol")
    _same(QUAL.RUNNER_VERSION, q_sidecar.get("runner_version"), "qualification sidecar runner")
    _validate_qualification_summary(qualification["summary"])

    provenance = lock["provenance"]
    expected_provenance = {
        "dataset_repo", "dataset_revision", "dataset_sha256", "dataset_bytes",
        "official_prompt_sha256", "legacy_manifest", "legacy_manifest_version",
        "legacy_manifest_content_sha256", "legacy_manifest_file_sha256",
        "qwen_manifest", "qwen_manifest_version", "qwen_manifest_content_sha256",
        "qwen_manifest_file_sha256", "source_ledger", "source_ledger_version",
        "source_ledger_content_sha256", "source_ledger_file_sha256",
        "executed_source_sha256", "runner_source", "runner_source_sha256",
        "reader_source", "reader_source_sha256", "config", "config_sha256",
        "model_snapshot_attestation_scope", "model_snapshot_inventory_revision",
        "model_snapshot_symlink_file_count",
        "model_snapshot_symlink_inventory_sha256",
        "model_snapshot_pinned_metadata_sha256",
    }
    _same(expected_provenance, set(provenance), "qualification provenance schema")
    static = {
        "dataset_repo": LB.DATASET_REPO,
        "dataset_revision": LB.DATASET_REVISION,
        "dataset_sha256": LB.DATASET_SHA256,
        "dataset_bytes": LB.DATASET_BYTES,
        "official_prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
        "legacy_manifest": QA.LEGACY_MANIFEST_ID,
        "legacy_manifest_version": QA.LEGACY_MANIFEST_VERSION,
        "legacy_manifest_content_sha256": QA.LEGACY_MANIFEST_CONTENT_SHA256,
        "legacy_manifest_file_sha256": QA.LEGACY_MANIFEST_FILE_SHA256,
        "qwen_manifest_version": QA.MANIFEST_VERSION,
        "qwen_manifest_content_sha256": QA.FROZEN_MANIFEST_CONTENT_SHA256,
        "qwen_manifest_file_sha256": QA.FROZEN_MANIFEST_FILE_SHA256,
        "config_sha256": LB.sha256_file(config),
        "model_snapshot_attestation_scope": QUAL.MODEL_SNAPSHOT_ATTESTATION_SCOPE,
        "model_snapshot_inventory_revision": MODEL_REVISION,
        "model_snapshot_symlink_file_count": QA.SNAPSHOT_FILE_COUNT,
        "model_snapshot_symlink_inventory_sha256": QA.SNAPSHOT_INVENTORY_SHA256,
        "model_snapshot_pinned_metadata_sha256": dict(QA.SNAPSHOT_METADATA_SHA256),
    }
    for key, expected in static.items():
        _same(expected, provenance.get(key), f"qualification provenance {key}")
    _same(_relative_source(config), provenance["config"], "qualification config path")
    _same(manifest_path, Path(provenance["qwen_manifest"]).resolve(), "qualification manifest path")
    recorded_sources = provenance["executed_source_sha256"]
    _authenticate_recorded_sources(recorded_sources, "qualification")
    _same(recorded_sources, q_sidecar.get("executed_source_sha256"), "qualification sidecar source seal")
    q_ledger_path = _regular(q_sidecar.get("source_ledger", ""), "qualification source ledger")
    _same(QUAL.DEFAULT_SOURCE_LEDGER.resolve(), q_ledger_path, "canonical qualification source ledger path")
    _same(str(q_ledger_path), provenance["source_ledger"], "qualification provenance source ledger path")
    _same(q_sidecar["source_ledger_version"], provenance["source_ledger_version"], "qualification provenance source ledger version")
    _same(q_sidecar["source_ledger_content_sha256"], provenance["source_ledger_content_sha256"], "qualification provenance source ledger content hash")
    _same(q_sidecar["source_ledger_file_sha256"], provenance["source_ledger_file_sha256"], "qualification provenance source ledger file hash")
    current_q_sources = QUAL.executed_source_hashes(config, q_ledger_path)
    _same(current_q_sources, recorded_sources, "current qualification source seal")
    q_ledger = QUAL.verify_source_ledger(q_ledger_path, current_q_sources)
    _same(q_ledger["content_sha256"], q_sidecar.get("source_ledger_content_sha256"), "qualification source-ledger content hash")
    _same(q_ledger["file_sha256"], q_sidecar.get("source_ledger_file_sha256"), "qualification source-ledger file hash")
    runner_key = _relative_source(QUAL.__file__)
    reader_key = str(provenance["reader_source"])
    _same(runner_key, provenance["runner_source"], "qualification runner path")
    _same(recorded_sources[runner_key], provenance["runner_source_sha256"], "qualification runner hash")
    _same(recorded_sources[reader_key], provenance["reader_source_sha256"], "qualification reader hash")

    snapshot = QA.authenticate_snapshot(model_source)
    _same(
        {
            "revision": provenance["model_snapshot_inventory_revision"],
            "file_count": provenance["model_snapshot_symlink_file_count"],
            "inventory_sha256": provenance["model_snapshot_symlink_inventory_sha256"],
            "metadata_sha256": provenance["model_snapshot_pinned_metadata_sha256"],
        }, snapshot, "qualification snapshot attestation",
    )
    return lock, {
        "lock_path": str(lock_path),
        "lock_file_sha256": LB.sha256_file(lock_path),
        "lock_content_sha256": str(lock["content_sha256"]),
        "qualification_predictions_sha256": str(qualification["predictions_sha256"]),
        "qualification_sidecar_sha256": str(qualification["sidecar_sha256"]),
        "qualification_source_ledger_file_sha256": q_ledger["file_sha256"],
        "qualification_source_ledger_content_sha256": q_ledger["content_sha256"],
        "snapshot": snapshot,
    }


def validate_cuda_placement(model: Any) -> list[str]:
    try:
        return QUAL.validate_cuda_placement(model)
    except QUAL.QwenQualificationRunnerError as exc:
        _fail(str(exc))


def _validate_config(path: str | Path) -> dict[str, Any]:
    try:
        return QUAL._validate_config(path)
    except QUAL.QwenQualificationRunnerError as exc:
        _fail(str(exc))


def _model_source(value: str) -> tuple[str, dict[str, Any]]:
    try:
        return QUAL._model_source(value)
    except QUAL.QwenQualificationRunnerError as exc:
        _fail(str(exc))


def canonical_entries(manifest: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    entries = [row for row in manifest["examples"] if row["split"] == SPLIT]
    by_id = {str(row["id"]): row for row in entries}
    order = QA.partition_order(entries)
    if len(entries) != EXPECTED_ITEMS or len(by_id) != EXPECTED_ITEMS or set(order) != set(by_id):
        _fail("development split does not contain the exact 52 unique frozen IDs")
    ordered = [by_id[item_id] for item_id in order]
    _same(EXPECTED_COMPONENTS, len({str(row["group_id"]) for row in ordered}), "development singleton component count")
    return ordered


def query_groups(entry: Mapping[str, Any], prompt_length: int) -> tuple[tuple[int, ...], ...]:
    raw = entry.get("content_token_positions")
    if not isinstance(raw, Mapping) or set(raw) != set(QA.CONTENT_GROUPS):
        _fail(f"{entry.get('id')}: structured content groups drifted")
    groups = tuple(tuple(int(value) for value in raw[group]) for group in QA.CONTENT_GROUPS)
    try:
        plan = SP.validate_absolute_query_groups(groups, prompt_length=prompt_length)
    except ValueError as exc:
        _fail(f"{entry.get('id')}: invalid structured query groups: {exc}")
    return plan.groups


def build_allocations(
    past: Any, *, cache_length: int, rotation: torch.Tensor,
    structured_score_h: Mapping[int, torch.Tensor],
    structured_score_kv: Mapping[int, torch.Tensor],
) -> dict[str, dict[int, torch.Tensor]]:
    """Build every compressed arm with one LayerCtx construction per layer."""
    C.crop_to(past, int(cache_length))
    _same(N_LAYERS, len(structured_score_h), "structured query-head score layers")
    _same(N_LAYERS, len(structured_score_kv), "structured KV-head score layers")
    output: dict[str, dict[int, torch.Tensor]] = {arm: {} for arm in CANDIDATES}
    for layer in range(N_LAYERS):
        ctx = router.build_layer_ctx(
            layer, past, rotation, list(BIT_LIST), NORM_CORRECT,
            cascade_bits=None, want_h2o=False, need_noise=True, wo_gram=None,
        )
        score_h = structured_score_h[layer]
        score_kv = structured_score_kv[layer]
        expected_h = (N_ATTENTION_HEADS, int(C.STATE.ctx_len))
        expected_kv = (N_KV_HEADS, int(C.STATE.ctx_len))
        _same(expected_h, tuple(score_h.shape), f"layer {layer} structured query-head score shape")
        _same(expected_kv, tuple(score_kv.shape), f"layer {layer} structured KV-head score shape")
        folded = score_h.reshape(N_KV_HEADS, ctx.n_rep, C.STATE.ctx_len).sum(dim=1)
        if not torch.allclose(folded.float(), score_kv.float(), rtol=1e-5, atol=1e-6):
            _fail(f"layer {layer} structured query/KV score aggregation drifted")
        layer_bits = {
            "uniform": router.base_bits("uniform", BUDGET, ctx, MAXB),
            "tail_evict": router.base_bits("evict", BUDGET, ctx, MAXB),
            "tail_interior": router.base_bits("interior", BUDGET, ctx, MAXB),
            "structured_evict": SP.allocate_structured_evict(score_kv, BUDGET, MAXB),
            "structured_interior": SP.allocate_structured_interior(ctx, score_h, BUDGET, MAXB),
        }
        for arm, bits in layer_bits.items():
            output[arm][layer] = bits.to(torch.uint8)
        del ctx, layer_bits
    return output


def validate_allocation(
    by_layer: Mapping[int, torch.Tensor], *, ctx_len: int, arm: str
) -> tuple[str, dict[str, float]]:
    _same(set(range(N_LAYERS)), set(by_layer), f"{arm} allocation layer set")
    allowed = {0, *BIT_LIST}
    total = evicted = count = 0
    for layer in range(N_LAYERS):
        bits = by_layer[layer]
        _same((N_KV_HEADS, int(ctx_len)), tuple(bits.shape), f"{arm} layer {layer} shape")
        _same(torch.uint8, bits.dtype, f"{arm} layer {layer} dtype")
        values = {int(value) for value in torch.unique(bits).detach().cpu().tolist()}
        if values - allowed:
            _fail(f"{arm} layer {layer} contains unsupported widths {sorted(values)}")
        total += int(bits.to(torch.int64).sum().item())
        evicted += int((bits == 0).sum().item())
        count += bits.numel()
    audit = {"bits_per_token": total / count, "evict_frac": evicted / count}
    if audit["bits_per_token"] > BUDGET + 1e-7 or audit["bits_per_token"] < 0:
        _fail(f"{arm} allocation spends {audit['bits_per_token']}, outside [0,{BUDGET}]")
    if arm == "uniform":
        if total != BUDGET * count or evicted:
            _fail("uniform allocation is not exact all-2 storage")
        expected = QUAL.expected_uniform_allocation_id(ctx_len)
        _same(expected, R8.allocation_id(by_layer), "uniform deterministic allocation ID")
    return R8.allocation_id(by_layer), {key: float(value) for key, value in audit.items()}


def _common_row(
    item: Mapping[str, Any], entry: Mapping[str, Any], *,
    manifest: Mapping[str, Any], manifest_file_hash: str,
    prompt_ids: Sequence[int],
) -> dict[str, Any]:
    metadata = entry["metadata"]
    return {
        "item_id": str(item["_id"]), "group_id": str(entry["group_id"]),
        "split": SPLIT, "domain": str(metadata["domain"]),
        "sub_domain": str(metadata["sub_domain"]),
        "difficulty": str(metadata["difficulty"]), "length": str(metadata["length"]),
        "context_hash": str(entry["context_hash"]),
        "question_hash": str(entry["question_hash"]),
        "prompt_token_hash": PD.token_hash(prompt_ids),
        "input_tokens": len(prompt_ids), "n_prompt_tokens": len(prompt_ids),
        "truncated": False, "dataset_sha256": LB.DATASET_SHA256,
        "manifest_content_sha256": str(manifest["content_sha256"]),
        "manifest_file_sha256": manifest_file_hash,
        "task_version": TASK_VERSION, "endpoint_version": ENDPOINT_VERSION,
        "model": MODEL_TAG, "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION, "tokenizer_revision": TOKENIZER_REVISION,
        "ctx": CTX, "window": WINDOW,
    }


def validate_output_rows(rows: Sequence[Mapping[str, Any]], item_ids: Sequence[str]) -> None:
    expected_keys = {(item_id, arm) for item_id in item_ids for arm in ARMS}
    observed: list[tuple[str, str]] = []
    for row in rows:
        _same(PREDICTION_COLUMNS, tuple(row), "prediction row schema/order")
        item_id, arm = str(row["item_id"]), str(row["arm"])
        observed.append((item_id, arm))
        if arm not in ARMS:
            _fail(f"unknown V7 development arm {arm!r}")
        _same(ARMS.index(arm), int(row["arm_order"]), f"{item_id}/{arm} arm order")
        _same(0 if arm == "fp" else BUDGET, int(row["B"]), f"{item_id}/{arm} budget")
        choice = str(row["forced_choice"])
        if choice not in "ABCD" or int(row["choice_index"]) != "ABCD".index(choice):
            _fail(f"invalid forced choice for {item_id}/{arm}")
        for field in ("choice_entropy", "choice_margin", "choice_max_probability"):
            if not math.isfinite(float(row[field])):
                _fail(f"non-finite {field} for {item_id}/{arm}")
        if not 0 <= float(row["choice_margin"]) <= 1:
            _fail(f"choice margin outside [0,1] for {item_id}/{arm}")
        if not .25 <= float(row["choice_max_probability"]) <= 1:
            _fail(f"choice max probability outside [.25,1] for {item_id}/{arm}")
        if bool(row["truncated"]) or int(row["input_tokens"]) > MAX_PROMPT_TOKENS:
            _fail(f"invalid truncation/context bound for {item_id}/{arm}")
        bits, evict = float(row["bits_per_token"]), float(row["evict_frac"])
        if arm == "fp":
            if bits != 16.0 or evict != 0.0 or row["allocation_id"] != R8.allocation_id(None):
                _fail(f"FP storage audit drifted for {item_id}")
        elif not (0 <= bits <= BUDGET + 1e-7 and 0 <= evict <= 1):
            _fail(f"compressed storage audit drifted for {item_id}/{arm}")
        if arm == "uniform" and (bits != float(BUDGET) or evict != 0.0):
            _fail(f"uniform storage audit drifted for {item_id}")
        _same(SCORE_QUERY_SOURCES[arm], str(row["score_query_source"]), f"{item_id}/{arm} score query source")
        query_count = int(row["score_query_count"])
        if arm in {"fp", "uniform"}:
            _same(0, query_count, f"{item_id}/{arm} score query count")
        elif arm.startswith("tail_"):
            _same(WINDOW, query_count, f"{item_id}/{arm} score query count")
        elif not 5 <= query_count <= len(QA.CONTENT_GROUPS) * QA.MAX_CONTENT_TOKENS_PER_GROUP:
            _fail(f"{item_id}/{arm} structured score query count is outside [5,40]")
    if len(observed) != EXPECTED_PREDICTION_ROWS or len(set(observed)) != len(observed) or set(observed) != expected_keys:
        _fail("prediction keys differ from exact development IDs x arms")
    if {column.lower() for column in PREDICTION_COLUMNS} & FORBIDDEN_RESULT_COLUMNS:
        _fail("prediction schema contains a forbidden outcome/raw-vector column")


def _sidecar(
    *, manifest: Mapping[str, Any], manifest_path: Path, manifest_file_hash: str,
    legacy_manifest_path: Path, frame: pd.DataFrame, parquet_path: Path,
    entries: Sequence[Mapping[str, Any]], elapsed_seconds: float,
    device_placements: Sequence[str], source_hashes: Mapping[str, str],
    source_ledger: Mapping[str, Any], snapshot: Mapping[str, Any],
    lock_attestation: Mapping[str, Any], allocation_summary: Mapping[str, Any],
) -> dict[str, Any]:
    runner_key = _relative_source(__file__)
    return {
        "artifact": "qwen_forced_choice_v7_development",
        "runner_version": RUNNER_VERSION, "protocol_version": PROTOCOL_VERSION,
        "task_version": TASK_VERSION, "endpoint_version": ENDPOINT_VERSION,
        "dataset_repo": LB.DATASET_REPO, "dataset_revision": LB.DATASET_REVISION,
        "dataset_sha256": LB.DATASET_SHA256, "dataset_bytes": LB.DATASET_BYTES,
        "official_code_repo": LB.OFFICIAL_CODE_REPO,
        "official_code_revision": LB.OFFICIAL_CODE_REVISION,
        "official_prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
        "legacy_manifest": QA.LEGACY_MANIFEST_ID,
        "legacy_manifest_version": QA.LEGACY_MANIFEST_VERSION,
        "legacy_manifest_content_sha256": QA.LEGACY_MANIFEST_CONTENT_SHA256,
        "legacy_manifest_file_sha256": LB.sha256_file(legacy_manifest_path),
        "manifest": str(manifest_path), "manifest_version": QA.MANIFEST_VERSION,
        "manifest_content_sha256": str(manifest["content_sha256"]),
        "manifest_file_sha256": manifest_file_hash, "split": SPLIT,
        "split_count": EXPECTED_ITEMS, "split_components": EXPECTED_COMPONENTS,
        "split_ids_sha256": str(manifest["split_counts"][SPLIT]["id_sha256"]),
        "split_id_token_sha256": str(manifest["split_counts"][SPLIT]["id_token_sha256"]),
        "split_id_prompt_sha256": str(manifest["split_counts"][SPLIT]["id_prompt_sha256"]),
        "split_id_positions_sha256": str(manifest["split_counts"][SPLIT]["id_positions_sha256"]),
        "split_ordered_id_sha256": str(manifest["split_counts"][SPLIT]["ordered_id_sha256"]),
        "within_split_order": "sha256(selection_namespace_plus_item_id_ascii)_ascending_v1",
        "model": MODEL_TAG, "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION, "tokenizer_revision": TOKENIZER_REVISION,
        "chat_template_sha256": QA.CHAT_TEMPLATE_SHA256,
        "add_generation_prompt": True, "enable_thinking": QA.ENABLE_THINKING,
        "transformers_version": TRANSFORMERS_VERSION,
        "tokenizers_version": TOKENIZERS_VERSION, "torch_version": TORCH_VERSION,
        "numpy_version": NUMPY_VERSION, "pandas_version": PANDAS_VERSION,
        "pyarrow_version": PYARROW_VERSION,
        "fastparquet_version": FASTPARQUET_VERSION,
        "parquet_engine": PARQUET_ENGINE,
        "model_snapshot_attestation_scope": QUAL.MODEL_SNAPSHOT_ATTESTATION_SCOPE,
        "model_snapshot_inventory_revision": snapshot["revision"],
        "model_snapshot_symlink_file_count": snapshot["file_count"],
        "model_snapshot_symlink_inventory_sha256": snapshot["inventory_sha256"],
        "model_snapshot_pinned_metadata_sha256": dict(snapshot["metadata_sha256"]),
        "snapshot_seal_timing": "before_tokenizer_and_rechecked_before_artifact_write",
        "qualification_lock": lock_attestation["lock_path"],
        "qualification_lock_version": QUALIFICATION_LOCK_VERSION,
        "qualification_lock_file_sha256": lock_attestation["lock_file_sha256"],
        "qualification_lock_content_sha256": lock_attestation["lock_content_sha256"],
        "qualification_predictions_sha256": lock_attestation["qualification_predictions_sha256"],
        "qualification_sidecar_sha256": lock_attestation["qualification_sidecar_sha256"],
        "qualification_source_ledger_file_sha256": lock_attestation["qualification_source_ledger_file_sha256"],
        "qualification_source_ledger_content_sha256": lock_attestation["qualification_source_ledger_content_sha256"],
        "ctx": CTX, "max_prompt_tokens": MAX_PROMPT_TOKENS, "window": WINDOW,
        "budget": float(BUDGET), "dtype": DTYPE_NAME, "bit_list": list(BIT_LIST),
        "maxb": MAXB, "rot_seed": ROT_SEED, "norm_correct": NORM_CORRECT,
        "chunk": CHUNK, "n_layers": N_LAYERS,
        "n_attention_heads": N_ATTENTION_HEADS, "n_kv_heads": N_KV_HEADS,
        "head_dim": HEAD_DIM,
        "uniform_allocation_contract": "48_layers_x_4_kv_x_ctx_len_all_uint8_2",
        "attn_impl": SP.IMPL, "underlying_attn_impl": C.IMPL,
        "structured_capture_version": SP.CAPTURE_VERSION,
        "structured_query_groups": list(QA.CONTENT_GROUPS),
        "structured_max_tokens_per_group": QA.MAX_CONTENT_TOKENS_PER_GROUP,
        "structured_group_weight": 1.0 / len(QA.CONTENT_GROUPS),
        "score_query_sources": dict(SCORE_QUERY_SOURCES),
        "tail_score_query_count": WINDOW,
        "structured_score_query_count_rule": "sum_manifest_question_A_B_C_D_group_lengths",
        "structured_interior_noise_query_source": "existing_last_prompt_query_sig2",
        "structured_capture_before_single_prefill": True,
        "layer_context_builds_per_layer": 1,
        "device_placements": list(device_placements),
        "decode": "forced_choice_teacher_forced_argmax", "temperature": 1.0,
        "compress_at": "official_chat_prompt_end", "arms": list(ARMS),
        "candidates": list(CANDIDATES), "old_menu": list(OLD_MENU),
        "structured_menu": list(STRUCTURED_MENU),
        "allocation_id_algorithm": R8.ALLOCATION_ID_ALGORITHM,
        "allocation_summary": dict(allocation_summary),
        "scaffold_token_ids": list(QA.SCAFFOLD_TOKEN_IDS),
        "scaffold_token_hash": PD.token_hash(QA.SCAFFOLD_TOKEN_IDS),
        "choice_branch_ids": dict(QA.CHOICE_BRANCH_IDS),
        "choice_branch_ids_hash": PD.token_hash([QA.CHOICE_BRANCH_IDS[c] for c in "ABCD"]),
        "choice_position": len(QA.SCAFFOLD_TOKEN_IDS),
        "no_truncation": True, "no_free_generation": True, "no_raw_logits": True,
        "no_proxy": True, "no_labels": True,
        "gold_unused_for_prompt_allocation_execution_and_output": True,
        "source_ledger": source_ledger["path"],
        "source_ledger_version": source_ledger["ledger_version"],
        "source_ledger_content_sha256": source_ledger["content_sha256"],
        "source_ledger_file_sha256": source_ledger["file_sha256"],
        "executed_source_sha256": dict(source_hashes),
        "runner_source": runner_key, "runner_source_sha256": source_hashes[runner_key],
        "source_seal_timing": "before_model_load_and_rechecked_before_artifact_write",
        "parquet": parquet_path.name, "parquet_sha256": LB.sha256_file(parquet_path),
        "rows": len(frame), "expected_rows": EXPECTED_PREDICTION_ROWS,
        "row_key": ["item_id", "arm"], "item_ids_sha256": QA.id_sha256(entries),
        "elapsed_seconds": float(elapsed_seconds),
    }


def run(args: argparse.Namespace) -> Path:
    config_path = _regular(args.config, "model config")
    lock, lock_attestation = authenticate_qualification_lock(
        args.qualification_lock, dataset_path=args.dataset,
        legacy_manifest_path=args.legacy_manifest, manifest_path=args.manifest,
        config_path=config_path, model_source=args.model_source,
    )
    del lock
    source_ledger_path = _regular(args.source_ledger, "V7 development source ledger")
    if source_ledger_path != DEFAULT_SOURCE_LEDGER.resolve():
        _fail(
            f"source ledger must be the canonical path {DEFAULT_SOURCE_LEDGER.resolve()}"
        )
    config = _validate_config(config_path)
    source_hashes = executed_source_hashes(config_path, source_ledger_path)
    source_ledger = verify_source_ledger(source_ledger_path, source_hashes)
    model_source, model_kwargs = _model_source(args.model_source)
    snapshot = QA.authenticate_snapshot(model_source)

    # All authorization and development source seals above precede these loads.
    tokenizer = QA.load_tokenizer(model_source)
    manifest_path = _regular(args.manifest, "V7 Qwen manifest")
    legacy_manifest_path = _regular(args.legacy_manifest, "legacy V6 manifest")
    manifest, manifest_file_hash = QA.authenticate_manifest(
        manifest_path, dataset_path=args.dataset,
        legacy_manifest_path=legacy_manifest_path, tokenizer=tokenizer,
    )
    entries = canonical_entries(manifest)
    data = LB.load_dataset(args.dataset, authenticate=True)
    by_id = LB.index_by_id(data)

    from transformers import AutoModelForCausalLM
    SP.install()
    model = AutoModelForCausalLM.from_pretrained(
        model_source, dtype=getattr(torch, DTYPE_NAME),
        device_map=config.get("device_map", "auto"),
        attn_implementation=SP.IMPL, trust_remote_code=True, **model_kwargs,
    ).eval()
    placements = validate_cuda_placement(model)
    device = next(model.parameters()).device
    cf = model.config
    architecture = {
        "n_layers": int(cf.num_hidden_layers),
        "n_attention_heads": int(cf.num_attention_heads),
        "n_kv_heads": int(cf.num_key_value_heads),
        "head_dim": int(getattr(cf, "head_dim", None) or cf.hidden_size // cf.num_attention_heads),
    }
    _same(
        {"n_layers": N_LAYERS, "n_attention_heads": N_ATTENTION_HEADS,
         "n_kv_heads": N_KV_HEADS, "head_dim": HEAD_DIM},
        architecture, "Qwen attention architecture",
    )
    rotation = quant.random_rotation(HEAD_DIM, device, torch.float32, seed=ROT_SEED)
    if not router.is_width(BUDGET, MAXB, list(BIT_LIST)):
        _fail("frozen B=2 is absent from the quantizer bit list")
    prefix_tokens, branch_ids = FC.canonical_choice_contract(
        tokenizer, expected_prefix=QA.SCAFFOLD_TOKEN_IDS,
        expected_branches=QA.CHOICE_BRANCH_IDS,
    )

    rows: list[dict[str, Any]] = []
    allocation_ids_by_arm: dict[str, set[str]] = {arm: set() for arm in ARMS}
    allocation_bits_by_arm: dict[str, list[float]] = {arm: [] for arm in ARMS}
    allocation_evict_by_arm: dict[str, list[float]] = {arm: [] for arm in ARMS}
    start = time.time()
    print(
        f"V7 Qwen development: items={EXPECTED_ITEMS} components={EXPECTED_COMPONENTS} "
        f"arms={list(ARMS)} B={BUDGET} ctx={CTX} W={WINDOW}; "
        "one structured full-precision prefill/item; labels absent from artifact",
        flush=True,
    )
    for item_index, entry in enumerate(entries):
        item_id = str(entry["id"])
        item = by_id[item_id]
        prompt_ids = QA.qwen_input_ids(tokenizer, item)
        _same(int(entry["input_tokens"]), len(prompt_ids), f"{item_id} prompt token count")
        _same(str(entry["prompt_token_hash"]), PD.token_hash(prompt_ids), f"{item_id} prompt hash")
        if len(prompt_ids) > MAX_PROMPT_TOKENS:
            _fail(f"{item_id}: prompt plus scaffold exceeds CTX={CTX}")
        prompt_length = len(prompt_ids) - 1
        ctx_len = prompt_length - WINDOW
        groups = query_groups(entry, prompt_length)
        SP.begin_capture(groups, prompt_length=prompt_length, ctx_len=ctx_len)
        ids = torch.tensor([prompt_ids], dtype=torch.long, device=device)
        t0 = time.time()
        try:
            past, _ = R8.prefill(model, ids, WINDOW, CHUNK, h2o=False)
            cache_length = C.cache_len(past)
            score_h, score_kv = SP.end_capture(tuple(range(N_LAYERS)))
        except Exception:
            SP.STATE.reset_prompt()
            raise
        prefill_seconds = time.time() - t0
        _same(prompt_length, cache_length, f"{item_id} prefill boundary")
        _same(WINDOW, cache_length - C.STATE.ctx_len, f"{item_id} protected tail")
        _same(ctx_len, C.STATE.ctx_len, f"{item_id} context length")
        allocations = build_allocations(
            past, cache_length=cache_length, rotation=rotation,
            structured_score_h=score_h, structured_score_kv=score_kv,
        )
        allocation_ids = {"fp": R8.allocation_id(None)}
        allocation_audits = {"fp": {"bits_per_token": 16.0, "evict_frac": 0.0}}
        for arm in CANDIDATES:
            allocation_ids[arm], allocation_audits[arm] = validate_allocation(
                allocations[arm], ctx_len=ctx_len, arm=arm
            )
        common = _common_row(
            item, entry, manifest=manifest, manifest_file_hash=manifest_file_hash,
            prompt_ids=prompt_ids,
        )
        for arm_order, arm in enumerate(ARMS):
            bits = None if arm == "fp" else allocations[arm]
            endpoint, applied = FC.policy_choice_logits(
                model, past, last_prompt_token=prompt_ids[-1],
                prefix_tokens=prefix_tokens, branch_ids=branch_ids,
                bits_by_layer=bits, rotation=rotation,
                norm_correct=NORM_CORRECT, cache_length=cache_length, device=device,
            )
            for field in ("bits_per_token", "evict_frac"):
                if not math.isclose(
                    float(applied[field]), float(allocation_audits[arm][field]),
                    rel_tol=0.0, abs_tol=1e-12,
                ):
                    _fail(f"{item_id}/{arm}: applied {field} differs from allocation")
            summary = FC.choice_summary(endpoint)
            row = {
                **common, "B": 0 if arm == "fp" else BUDGET,
                "arm": arm, "arm_order": arm_order, **summary,
                "scaffold_token_hash": PD.token_hash(prefix_tokens),
                "choice_branch_ids_hash": PD.token_hash([branch_ids[c] for c in "ABCD"]),
                **applied, "allocation_id": allocation_ids[arm],
                "ctx_len": ctx_len,
                "score_query_source": SCORE_QUERY_SOURCES[arm],
                "score_query_count": (
                    0 if arm in {"fp", "uniform"} else
                    WINDOW if arm.startswith("tail_") else
                    sum(len(group) for group in groups)
                ),
                "maxb": MAXB, "rot_seed": ROT_SEED,
                "norm_correct": NORM_CORRECT,
            }
            rows.append(row)
            allocation_ids_by_arm[arm].add(allocation_ids[arm])
            allocation_bits_by_arm[arm].append(float(applied["bits_per_token"]))
            allocation_evict_by_arm[arm].append(float(applied["evict_frac"]))
            del endpoint
        print(
            f"  {item_index + 1:2d}/{EXPECTED_ITEMS} {item_id} "
            f"n={len(prompt_ids):,} prefill={prefill_seconds:.1f}s",
            flush=True,
        )
        SP.STATE.reset_prompt()
        del past, allocations, score_h, score_kv
        if device.type == "cuda":
            torch.cuda.empty_cache()

    elapsed = time.time() - start
    item_ids = [str(entry["id"]) for entry in entries]
    validate_output_rows(rows, item_ids)
    _same(EXPECTED_PREDICTION_ROWS, len(rows), "V7 development row count")

    final_sources = executed_source_hashes(config_path, source_ledger_path)
    _same(source_hashes, final_sources, "development executed-source seal")
    _same(source_ledger, verify_source_ledger(source_ledger_path, final_sources), "development source-ledger seal")
    _same(snapshot, QA.authenticate_snapshot(model_source), "development model snapshot seal")
    _, final_lock = authenticate_qualification_lock(
        args.qualification_lock, dataset_path=args.dataset,
        legacy_manifest_path=args.legacy_manifest, manifest_path=args.manifest,
        config_path=config_path, model_source=model_source,
    )
    _same(lock_attestation, final_lock, "qualification authorization seal")

    output_dir = Path(args.out_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    parquet_path = output_dir / f"{PREDICTION_BASENAME}.parquet"
    sidecar_path = output_dir / f"{PREDICTION_BASENAME}.json"
    if parquet_path.exists() or parquet_path.is_symlink() or sidecar_path.exists() or sidecar_path.is_symlink():
        _fail(f"refusing to overwrite existing V7 development artifact in {output_dir}")
    frame = pd.DataFrame(rows, columns=PREDICTION_COLUMNS)
    frame.to_parquet(parquet_path, index=False, engine=PARQUET_ENGINE)
    allocation_summary = {
        arm: {
            "unique_allocation_ids": len(allocation_ids_by_arm[arm]),
            "mean_bits_per_token": sum(allocation_bits_by_arm[arm]) / EXPECTED_ITEMS,
            "mean_evict_frac": sum(allocation_evict_by_arm[arm]) / EXPECTED_ITEMS,
        }
        for arm in ARMS
    }
    sidecar = _sidecar(
        manifest=manifest, manifest_path=manifest_path,
        manifest_file_hash=manifest_file_hash,
        legacy_manifest_path=legacy_manifest_path, frame=frame,
        parquet_path=parquet_path, entries=entries, elapsed_seconds=elapsed,
        device_placements=placements, source_hashes=source_hashes,
        source_ledger=source_ledger, snapshot=snapshot,
        lock_attestation=lock_attestation, allocation_summary=allocation_summary,
    )
    sidecar_path.write_text(
        json.dumps(sidecar, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"wrote {parquet_path} ({len(frame)} rows)")
    return parquet_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--legacy-manifest", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--config", default=str(HERE / "models.yaml"))
    parser.add_argument("--model-source", required=True)
    parser.add_argument("--qualification-lock", required=True)
    parser.add_argument("--source-ledger", default=str(DEFAULT_SOURCE_LEDGER))
    parser.add_argument("--out-dir", required=True)
    return parser


def main() -> None:
    parser = build_parser()
    try:
        run(parser.parse_args())
    except (QwenV7DevelopmentRunnerError, QA.V7ManifestError, OSError, ValueError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
