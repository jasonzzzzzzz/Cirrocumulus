#!/usr/bin/env python3
"""Build and authenticate the gold-free V6 Qwen LongBench-v2 manifest.

The source item/component partition is the frozen V4 manifest.  This audit only
changes model-specific chat rendering: it applies the pinned Qwen tokenizer
with ``enable_thinking=False`` and records token counts and prompt-token hashes.
It never copies benchmark answers into the emitted manifest.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sievelib import forced_choice as FC  # noqa: E402
from sievelib import policy_diagnostic as PD  # noqa: E402
from sievelib import tasks_longbench_v2 as LB  # noqa: E402
from h0_measurement import audit_longbench_v2 as SOURCE_AUDIT  # noqa: E402


MANIFEST_VERSION = "longbench_v2_sieve_v6_qwen30_manifest_v1"
MODEL_TAG = "qwen3-30b-a3b-2507"
MODEL_ID = "Qwen/Qwen3-30B-A3B-Instruct-2507"
MODEL_REVISION = "0d7cf23991f47feeb3a57ecb4c9cee8ea4a17bfe"
TOKENIZER_REVISION = MODEL_REVISION
TRANSFORMERS_VERSION = "5.16.1"
TOKENIZERS_VERSION = "0.23.1"
CHAT_TEMPLATE_SHA256 = (
    "64f85b198065d0fba2a81f37e10ed68161ce2c19a754c7100e67e0ca2ee9c326"
)
CONTEXT_WINDOW = 40_960
ENABLE_THINKING = False
SCAFFOLD_TOKEN_IDS = (785, 4396, 4226, 374, 320)
CHOICE_BRANCH_IDS = {"A": 32, "B": 33, "C": 34, "D": 35}
SNAPSHOT_FILE_COUNT = 24
SNAPSHOT_INVENTORY_SHA256 = (
    "4ac169930fba4989c196232eae1528dfea473cc695a439061741aa61df3510c2"
)
SNAPSHOT_METADATA_SHA256 = {
    "config.json": "a1ee086a68d0cbfc87316da00ba4b8507bd1292978108e2496201a30a450f438",
    "generation_config.json": "19d306dd769db12a9d710b44cf7f83b635efbe5166b84fb4358a08fb7d88bb53",
    "merges.txt": "599bab54075088774b1733fde865d5bd747cbcc7a547c5bc12610e874e26f5e3",
    "model.safetensors.index.json": "8dde190b862c7c80ec7403c6495de00c60bbaf246ed479cee4506284989c584c",
    "tokenizer.json": "aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4",
    "tokenizer_config.json": "a62ff0a2472a0fa1b8eaabcb57c59b58afa42a22831dc141400b6e0cf2b65ce3",
    "vocab.json": "ca10d7e9fb3ed18575dd1e277a2579c16d108e32f27439684afa0e10b1440910",
}
SOURCE_MANIFEST_VERSION = LB.MANIFEST_VERSION
SOURCE_MANIFEST_CONTENT_SHA256 = (
    "ee951a2c7b2c256125e73de4fba6f7e14485a566bbf6096c14c6e4f23e6407ff"
)
SOURCE_MANIFEST_FILE_SHA256 = (
    "bd7b358a91081fd5657a2aa822a4c814ebfeb85f410d55cee25aa9f54223798e"
)
SOURCE_MANIFEST_ID = (
    "h0_measurement/bugs/9_sota_eviction_baselines/longbench_v2_manifest.json"
)

SPLITS = ("qualification", "development", "confirmation")
EXPECTED_SPLITS = {
    "qualification": {
        "rows": 20,
        "components": 19,
        "id_sha256": "e1a2b0a72f6e783369af4cb743d91a4725c373e5baa9a8db24b232fa45a3ca38",
        "id_token_sha256": "bb453f5c5a27694cf2c9214d9752f4af0670f0a33a24ed2881caf78d0f5c2d51",
        "input_tokens_min": 10_150,
        "input_tokens_max": 30_588,
    },
    "development": {
        "rows": 52,
        "components": 44,
        "id_sha256": "98bf6531b62e474a05b66f488b298d51b7c1ecb53e4e0e97c23495e8dacace35",
        "id_token_sha256": "0e2db1d967d93da4a2f937423f9f330031753f989740252f90b32c68cd691cf8",
        "input_tokens_min": 10_873,
        "input_tokens_max": 31_848,
    },
    "confirmation": {
        "rows": 45,
        "components": 45,
        "id_sha256": "31c9cd599df77ba9bada01ce601f1b04fa1e5c0316dd3198e1b20ba147231abe",
        "id_token_sha256": "3b24f41058ae272268b465f2d4ce7847ed3c38e07684f5fa2322c406eb1344e6",
        "input_tokens_min": 12_677,
        "input_tokens_max": 33_438,
    },
}

# Filled after the deterministic CPU manifest is generated.  Keeping these as
# constants lets runners/readers reject a locally regenerated or edited file.
FROZEN_MANIFEST_CONTENT_SHA256 = "c6a951bb5433dd5c918ca6c8c964eb2ed4a4c26f9a079f53fb9111e9a3279f5b"
FROZEN_MANIFEST_FILE_SHA256 = "a85b94fe636ce00ccddbc4ffa0f371f4d666aa0aa02750841444a811250a1946"

EXAMPLE_KEYS = {
    "id", "group_id", "context_hash", "question_hash", "metadata", "split",
    "input_tokens", "prompt_token_hash",
}


class QwenManifestError(ValueError):
    """A source, tokenizer, or Qwen manifest violates the frozen contract."""


def _fail(message: str) -> None:
    raise QwenManifestError(message)


def sha256_file(path: str | Path) -> str:
    return LB.sha256_file(path)


def sha256_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")


def manifest_content_sha256(manifest: Mapping[str, Any]) -> str:
    payload = dict(manifest)
    payload.pop("content_sha256", None)
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def id_sha256(rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(
        f"{item_id}\n" for item_id in sorted(str(row["id"]) for row in rows)
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def id_token_sha256(rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(
        f"{item_id}\t{tokens}\n"
        for item_id, tokens in sorted(
            (str(row["id"]), int(row["input_tokens"])) for row in rows
        )
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def id_prompt_sha256(rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(
        f"{item_id}\t{prompt_hash}\n"
        for item_id, prompt_hash in sorted(
            (str(row["id"]), str(row["prompt_token_hash"])) for row in rows
        )
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def _load_object(path: str | Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _fail(f"cannot read {label} {path}: {exc}")
    if not isinstance(value, dict):
        _fail(f"{label} must contain one JSON object")
    return value


def authenticate_source_manifest(
    path: str | Path,
) -> tuple[dict[str, Any], str]:
    source = _load_object(path, "source manifest")
    file_hash = sha256_file(path)
    if file_hash != SOURCE_MANIFEST_FILE_SHA256:
        _fail(
            f"source manifest file SHA-256 is {file_hash}, expected "
            f"{SOURCE_MANIFEST_FILE_SHA256}"
        )
    try:
        SOURCE_AUDIT.verify_manifest_content_hash(source)
    except (KeyError, TypeError, ValueError) as exc:
        _fail(f"source manifest content authentication failed: {exc}")
    if source.get("manifest_version") != SOURCE_MANIFEST_VERSION:
        _fail("source manifest version drifted")
    if source.get("content_sha256") != SOURCE_MANIFEST_CONTENT_SHA256:
        _fail("source manifest content SHA-256 drifted")
    examples = source.get("examples")
    if not isinstance(examples, list) or len(examples) != 117:
        _fail("source manifest must contain the frozen 117 examples")
    if any("answer" in row for row in examples if isinstance(row, dict)):
        _fail("source manifest contains an answer field")
    return source, file_hash


def authenticate_snapshot(path: str | Path) -> dict[str, Any]:
    """Authenticate the exact local snapshot inventory without hashing 61 GB weights."""
    candidate = Path(path).expanduser()
    if candidate.is_symlink():
        _fail(f"snapshot root must not be a symlink: {candidate}")
    root = candidate.resolve()
    if not root.is_dir() or MODEL_REVISION not in root.parts:
        _fail(f"snapshot must be a directory for pinned revision {MODEL_REVISION}")
    rows: list[str] = []
    files: list[Path] = []
    for entry in sorted(root.rglob("*")):
        if entry.is_dir():
            continue
        relative = entry.relative_to(root).as_posix()
        if not entry.is_symlink():
            _fail(f"snapshot entry must be a frozen symlink: {relative}")
        target = os.readlink(entry)
        rows.append(f"L\t{relative}\t{target}\n")
        resolved_target = entry.resolve()
        if not resolved_target.is_file():
            _fail(f"snapshot target is absent for {relative}")
        try:
            resolved_target.relative_to(root.parent.parent.resolve())
        except ValueError:
            _fail(f"snapshot target escapes its model cache for {relative}")
        files.append(entry)
    inventory_hash = hashlib.sha256("".join(rows).encode("utf-8")).hexdigest()
    _same(SNAPSHOT_FILE_COUNT, len(files), "snapshot file count")
    _same(SNAPSHOT_INVENTORY_SHA256, inventory_hash, "snapshot inventory SHA-256")
    metadata: dict[str, str] = {}
    for name, expected in SNAPSHOT_METADATA_SHA256.items():
        file_path = root / name
        if file_path not in files:
            _fail(f"snapshot metadata file is absent: {name}")
        got = sha256_file(file_path)
        _same(expected, got, f"snapshot metadata SHA-256 {name}")
        metadata[name] = got
    return {
        "revision": MODEL_REVISION,
        "file_count": len(files),
        "inventory_sha256": inventory_hash,
        "metadata_sha256": metadata,
    }


def load_tokenizer(model_or_snapshot: str) -> Any:
    from transformers import AutoTokenizer

    candidate = Path(str(model_or_snapshot)).expanduser()
    authenticate_snapshot(candidate)
    resolved = candidate.resolve()
    tokenizer = AutoTokenizer.from_pretrained(
        str(resolved), local_files_only=True, trust_remote_code=True
    )
    validate_tokenizer(tokenizer)
    return tokenizer


def validate_tokenizer(tokenizer: Any) -> None:
    template = getattr(tokenizer, "chat_template", None)
    if not isinstance(template, str) or not template:
        _fail("pinned Qwen tokenizer has no string chat_template")
    got = sha256_text(template)
    if got != CHAT_TEMPLATE_SHA256:
        _fail(f"Qwen chat-template SHA-256 is {got}, expected {CHAT_TEMPLATE_SHA256}")
    try:
        FC.canonical_choice_contract(
            tokenizer,
            expected_prefix=SCAFFOLD_TOKEN_IDS,
            expected_branches=CHOICE_BRANCH_IDS,
        )
    except ValueError as exc:
        _fail(f"Qwen forced-choice token contract failed: {exc}")


def qwen_input_ids(tokenizer: Any, item: Mapping[str, Any]) -> list[int]:
    prompt = LB.render_prompt(dict(item))
    try:
        return FC.render_user_prompt(
            tokenizer, prompt, enable_thinking=ENABLE_THINKING
        )
    except (TypeError, ValueError) as exc:
        _fail(f"Qwen chat rendering failed for {item.get('_id')}: {exc}")


def _source_rows(
    data: Sequence[Mapping[str, Any]], source: Mapping[str, Any]
) -> tuple[list[Mapping[str, Any]], dict[str, Mapping[str, Any]]]:
    by_id = {str(item["_id"]): item for item in data}
    rows = source["examples"]
    ids = [str(row.get("id", "")) for row in rows]
    if len(ids) != len(set(ids)) or set(ids) - set(by_id):
        _fail("source manifest IDs are duplicate or absent from the pinned dataset")
    for row in rows:
        item = by_id[str(row["id"])]
        if LB.context_hash(item) != row.get("context_hash"):
            _fail(f"source context hash drifted for {row['id']}")
        metadata = {
            key: item[key] for key in ("domain", "sub_domain", "difficulty", "length")
        }
        if row.get("metadata") != metadata:
            _fail(f"source metadata drifted for {row['id']}")
    return list(rows), by_id


def build_manifest(
    *,
    dataset_path: str | Path,
    source_manifest_path: str | Path,
    tokenizer: Any,
) -> dict[str, Any]:
    source, source_file_hash = authenticate_source_manifest(source_manifest_path)
    data = LB.load_dataset(dataset_path, authenticate=True)
    source_rows, by_id = _source_rows(data, source)
    validate_tokenizer(tokenizer)

    examples: list[dict[str, Any]] = []
    for source_row in source_rows:
        item_id = str(source_row["id"])
        item = by_id[item_id]
        prompt_ids = qwen_input_ids(tokenizer, item)
        if len(prompt_ids) + len(SCAFFOLD_TOKEN_IDS) > CONTEXT_WINDOW:
            _fail(
                f"{item_id} has {len(prompt_ids)} Qwen input tokens plus "
                f"{len(SCAFFOLD_TOKEN_IDS)} scaffold positions, exceeding the "
                f"frozen {CONTEXT_WINDOW} window"
            )
        examples.append(
            {
                "id": item_id,
                "group_id": str(source_row["group_id"]),
                "context_hash": str(source_row["context_hash"]),
                "question_hash": sha256_text(item["question"].strip()),
                "metadata": dict(source_row["metadata"]),
                "split": str(source_row["split"]),
                "input_tokens": len(prompt_ids),
                "prompt_token_hash": PD.token_hash(prompt_ids),
            }
        )
    examples.sort(key=lambda row: str(row["id"]))

    split_counts: dict[str, Any] = {}
    for split in SPLITS:
        rows = [row for row in examples if row["split"] == split]
        split_counts[split] = {
            "rows": len(rows),
            "components": len({str(row["group_id"]) for row in rows}),
            "id_sha256": id_sha256(rows),
            "id_token_sha256": id_token_sha256(rows),
            "id_prompt_sha256": id_prompt_sha256(rows),
            "input_tokens_min": min(int(row["input_tokens"]) for row in rows),
            "input_tokens_max": max(int(row["input_tokens"]) for row in rows),
        }

    manifest: dict[str, Any] = {
        "manifest_version": MANIFEST_VERSION,
        "protocol": {
            "dataset": {
                "repo": LB.DATASET_REPO,
                "revision": LB.DATASET_REVISION,
                "sha256": LB.DATASET_SHA256,
                "bytes": LB.DATASET_BYTES,
            },
            "official_prompt": {
                "code_repo": LB.OFFICIAL_CODE_REPO,
                "code_revision": LB.OFFICIAL_CODE_REVISION,
                "prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
            },
            "source_partition": {
                "manifest_version": SOURCE_MANIFEST_VERSION,
                "manifest_content_sha256": SOURCE_MANIFEST_CONTENT_SHA256,
                "manifest_file_sha256": source_file_hash,
                "split_version": LB.SPLIT_VERSION,
                "split_namespace_utf8": LB.SPLIT_NAMESPACE.decode("utf-8"),
                "context_hash_version": LB.CONTEXT_HASH_VERSION,
                "question_hash_version": LB.QUESTION_HASH_VERSION,
            },
            "model": {
                "tag": MODEL_TAG,
                "id": MODEL_ID,
                "revision": MODEL_REVISION,
                "tokenizer_revision": TOKENIZER_REVISION,
                "transformers_version": TRANSFORMERS_VERSION,
                "tokenizers_version": TOKENIZERS_VERSION,
                "chat_template_sha256": CHAT_TEMPLATE_SHA256,
                "add_generation_prompt": True,
                "enable_thinking": ENABLE_THINKING,
            },
            "forced_choice": {
                "scaffold_token_ids": list(SCAFFOLD_TOKEN_IDS),
                "choice_branch_ids": dict(CHOICE_BRANCH_IDS),
                "temperature": 1.0,
            },
            "execution": {
                "context_window": CONTEXT_WINDOW,
                "selection_rule": "reuse_exact_v4_partition_no_row_filtering",
                "no_truncation": True,
                "no_labels": True,
            },
        },
        "source_manifest": SOURCE_MANIFEST_ID,
        "source_manifest_content_sha256": SOURCE_MANIFEST_CONTENT_SHA256,
        "source_manifest_file_sha256": source_file_hash,
        "examples": examples,
        "split_counts": split_counts,
    }
    manifest["content_sha256"] = manifest_content_sha256(manifest)
    validate_manifest_object(
        manifest,
        data=data,
        source=source,
        tokenizer=tokenizer,
    )
    return manifest


def _same(expected: Any, actual: Any, description: str) -> None:
    if expected != actual:
        _fail(f"{description}: expected {expected!r}, got {actual!r}")


def validate_manifest_object(
    manifest: Mapping[str, Any],
    *,
    data: Sequence[Mapping[str, Any]],
    source: Mapping[str, Any],
    tokenizer: Any,
) -> None:
    _same(MANIFEST_VERSION, manifest.get("manifest_version"), "manifest version")
    _same(
        manifest_content_sha256(manifest),
        manifest.get("content_sha256"),
        "manifest content SHA-256",
    )
    if FROZEN_MANIFEST_CONTENT_SHA256:
        _same(
            FROZEN_MANIFEST_CONTENT_SHA256,
            manifest.get("content_sha256"),
            "frozen Qwen manifest content SHA-256",
        )
    if set(manifest) != {
        "manifest_version", "protocol", "source_manifest",
        "source_manifest_content_sha256", "source_manifest_file_sha256",
        "examples", "split_counts", "content_sha256",
    }:
        _fail("Qwen manifest top-level schema drifted")
    protocol = manifest.get("protocol")
    if not isinstance(protocol, dict):
        _fail("Qwen manifest protocol is absent")
    expected_protocol = {
        "dataset": {
            "repo": LB.DATASET_REPO, "revision": LB.DATASET_REVISION,
            "sha256": LB.DATASET_SHA256, "bytes": LB.DATASET_BYTES,
        },
        "official_prompt": {
            "code_repo": LB.OFFICIAL_CODE_REPO,
            "code_revision": LB.OFFICIAL_CODE_REVISION,
            "prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
        },
        "source_partition": {
            "manifest_version": SOURCE_MANIFEST_VERSION,
            "manifest_content_sha256": SOURCE_MANIFEST_CONTENT_SHA256,
            "manifest_file_sha256": SOURCE_MANIFEST_FILE_SHA256,
            "split_version": LB.SPLIT_VERSION,
            "split_namespace_utf8": LB.SPLIT_NAMESPACE.decode("utf-8"),
            "context_hash_version": LB.CONTEXT_HASH_VERSION,
            "question_hash_version": LB.QUESTION_HASH_VERSION,
        },
        "model": {
            "tag": MODEL_TAG, "id": MODEL_ID, "revision": MODEL_REVISION,
            "tokenizer_revision": TOKENIZER_REVISION,
            "transformers_version": TRANSFORMERS_VERSION,
            "tokenizers_version": TOKENIZERS_VERSION,
            "chat_template_sha256": CHAT_TEMPLATE_SHA256,
            "add_generation_prompt": True,
            "enable_thinking": ENABLE_THINKING,
        },
        "forced_choice": {
            "scaffold_token_ids": list(SCAFFOLD_TOKEN_IDS),
            "choice_branch_ids": dict(CHOICE_BRANCH_IDS),
            "temperature": 1.0,
        },
        "execution": {
            "context_window": CONTEXT_WINDOW,
            "selection_rule": "reuse_exact_v4_partition_no_row_filtering",
            "no_truncation": True,
            "no_labels": True,
        },
    }
    _same(expected_protocol, protocol, "Qwen manifest protocol")
    _same(SOURCE_MANIFEST_ID, manifest.get("source_manifest"), "source manifest ID")
    _same(
        SOURCE_MANIFEST_CONTENT_SHA256,
        manifest.get("source_manifest_content_sha256"),
        "source manifest content hash",
    )
    _same(
        SOURCE_MANIFEST_FILE_SHA256,
        manifest.get("source_manifest_file_sha256"),
        "source manifest file hash",
    )
    validate_tokenizer(tokenizer)

    examples = manifest.get("examples")
    if not isinstance(examples, list) or len(examples) != 117:
        _fail("Qwen manifest must contain exactly 117 preselected rows")
    if any(not isinstance(row, dict) or set(row) != EXAMPLE_KEYS for row in examples):
        _fail("Qwen manifest example schema drifted")
    ids = [str(row["id"]) for row in examples]
    if ids != sorted(ids) or len(ids) != len(set(ids)):
        _fail("Qwen manifest IDs must be unique and sorted")

    by_id = {str(item["_id"]): item for item in data}
    source_by_id = {str(row["id"]): row for row in source["examples"]}
    if set(ids) != set(source_by_id):
        _fail("Qwen manifest does not preserve the exact source ID set")
    for row in examples:
        item_id = str(row["id"])
        item = by_id.get(item_id)
        if item is None:
            _fail(f"Qwen manifest item {item_id} is absent from the dataset")
        source_row = source_by_id[item_id]
        for field in ("group_id", "context_hash", "metadata", "split"):
            _same(source_row[field], row[field], f"{item_id} source {field}")
        _same(
            sha256_text(item["question"].strip()), row["question_hash"],
            f"{item_id} question hash",
        )
        prompt_ids = qwen_input_ids(tokenizer, item)
        _same(len(prompt_ids), row["input_tokens"], f"{item_id} token count")
        _same(
            PD.token_hash(prompt_ids), row["prompt_token_hash"],
            f"{item_id} prompt token hash",
        )
        if int(row["input_tokens"]) + len(SCAFFOLD_TOKEN_IDS) > CONTEXT_WINDOW:
            _fail(f"{item_id} plus its scaffold exceeds the Qwen experiment window")

    split_counts = manifest.get("split_counts")
    if not isinstance(split_counts, dict) or set(split_counts) != set(SPLITS):
        _fail("Qwen split summaries are absent or unexpected")
    for split, frozen in EXPECTED_SPLITS.items():
        rows = [row for row in examples if row["split"] == split]
        observed = {
            "rows": len(rows),
            "components": len({str(row["group_id"]) for row in rows}),
            "id_sha256": id_sha256(rows),
            "id_token_sha256": id_token_sha256(rows),
            "id_prompt_sha256": id_prompt_sha256(rows),
            "input_tokens_min": min(int(row["input_tokens"]) for row in rows),
            "input_tokens_max": max(int(row["input_tokens"]) for row in rows),
        }
        _same(observed, split_counts[split], f"{split} split summary")
        for field, expected in frozen.items():
            _same(expected, observed[field], f"{split} {field}")


def authenticate_manifest(
    manifest_path: str | Path,
    *,
    dataset_path: str | Path,
    source_manifest_path: str | Path,
    tokenizer: Any,
) -> tuple[dict[str, Any], str]:
    source, _ = authenticate_source_manifest(source_manifest_path)
    data = LB.load_dataset(dataset_path, authenticate=True)
    manifest = _load_object(manifest_path, "Qwen manifest")
    file_hash = sha256_file(manifest_path)
    if FROZEN_MANIFEST_FILE_SHA256:
        _same(
            FROZEN_MANIFEST_FILE_SHA256, file_hash,
            "frozen Qwen manifest file SHA-256",
        )
    validate_manifest_object(
        manifest, data=data, source=source, tokenizer=tokenizer
    )
    return manifest, file_hash


def write_manifest(path: str | Path, manifest: Mapping[str, Any]) -> None:
    """Atomically write once; accept only an identical existing regular file."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = (
        json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    if target.is_symlink():
        _fail(f"refusing symlink manifest target {target}")
    if target.exists():
        if not target.is_file():
            _fail(f"manifest target is not a regular file: {target}")
        if target.read_bytes() == payload:
            return
        _fail(f"refusing to replace different existing manifest {target}")
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{target.name}.", suffix=".tmp", dir=target.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, help="pinned LongBench-v2 JSON")
    parser.add_argument("--source-manifest", required=True)
    parser.add_argument(
        "--tokenizer", required=True,
        help="local pinned snapshot path ending in the pinned revision",
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out", help="build and write the deterministic manifest")
    group.add_argument("--manifest", help="audit an existing Qwen manifest")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        tokenizer = load_tokenizer(args.tokenizer)
        if args.out:
            manifest = build_manifest(
                dataset_path=args.data,
                source_manifest_path=args.source_manifest,
                tokenizer=tokenizer,
            )
            write_manifest(args.out, manifest)
            authenticate_manifest(
                args.out,
                dataset_path=args.data,
                source_manifest_path=args.source_manifest,
                tokenizer=tokenizer,
            )
            print(f"wrote {Path(args.out).resolve()}")
        else:
            authenticate_manifest(
                args.manifest,
                dataset_path=args.data,
                source_manifest_path=args.source_manifest,
                tokenizer=tokenizer,
            )
            print(f"PASS {Path(args.manifest).resolve()}")
    except (QwenManifestError, OSError, ValueError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
