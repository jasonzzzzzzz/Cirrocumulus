# Supplementary code (anonymized)

Code for "When Does Joint Key-Cache Allocation Pay? Output-Distortion Regimes
and Their Limits on End Tasks".

## Layout
- `sievelib/` - quantizers (TurboQuant-MSE, KIVI, KVQuant-style), the output-distortion
  allocator, eviction baselines (SnapKV, H2O, Ada-KV, DropKV, OBCache, LaProx),
  the compressed-cache attention path, and RULER-style task builders.
- `h0_measurement/run_h0.py` - attention-output (regime-map) measurements.
- `h0_measurement/run_r8.py` - end-task evaluation under a compressed cache.
- `h0_measurement/submit_*.slurm` - job scripts; overrides are passed as `NAME=value` arguments.
- `h0_measurement/bugs/<N>_*/` - one folder per experiment: `plan.md` (design and decision
  rules, written before the run), `script.sh` (exact submissions), and the reader that
  produces the reported numbers.
- `latex/figures/` - scripts and cell-level CSVs that generate every figure and appendix table.
- `tests/` - unit tests; each GPU job runs the relevant `--fast` suites before model loading.

## Reproducing
1. Python 3.11, torch 2.13, transformers 5.16; models from Hugging Face
   (Llama-3.1-8B-Instruct, Qwen3-8B, Mistral-7B-Instruct-v0.3, ...).
2. Stage the PG-19 haystack: `python h0_measurement/prefetch_corpus.py --out .h0_corpus/pg19`.
3. Run the tests: `python tests/test_r8.py --fast`, `python tests/test_baselines.py --fast`,
   `python tests/test_kv_quant_baselines.py --fast`.
4. Submit an experiment with its `script.sh`, then run its reader on the result parquets.

Placeholders such as `<PROJECT_ROOT>`, `<ACCOUNT>` and `<gpu-login-node>` replace
site-specific paths and names; set them for your cluster.
