#!/usr/bin/env python3
"""Build the frozen, gold-free LongBench-v2 V4 eligibility manifest.

This is a CPU-only preflight. It authenticates the exact upstream JSON, renders
its official zero-shot prompt through the pinned Llama tokenizer, rejects every
example that would require truncation at the 32K operating point, and freezes
connected qualification/development/confirmation components without reading a
model outcome. Gold choices never enter the emitted manifest.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sievelib import tasks_longbench_v2 as LB  # noqa: E402


SPLIT_NAMES = ("qualification", "development", "confirmation")
GROUPING_MODE = "connected_components_of_stripped_context_or_question_sha256"
CONTENT_HASH_ALGORITHM = (
    "sha256(canonical_json(manifest_without_content_sha256))"
)
ELIGIBLE_LIST_ALGORITHM = (
    "sha256(utf8(concat(sorted_by_id(id + '\\t' + input_tokens + '\\n'))))"
)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def question_hash(item: Mapping[str, Any]) -> str:
    return sha256_text(str(item["question"]).strip())


def eligible_list_bytes(examples: Iterable[Mapping[str, Any]]) -> bytes:
    rows = sorted((str(row["id"]), int(row["input_tokens"])) for row in examples)
    return "".join(f"{item_id}\t{n_tokens}\n" for item_id, n_tokens in rows).encode(
        "utf-8"
    )


def eligible_list_sha256(examples: Iterable[Mapping[str, Any]]) -> str:
    return hashlib.sha256(eligible_list_bytes(examples)).hexdigest()


def id_list_sha256(examples: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(f"{item_id}\n" for item_id in sorted(
        str(row["id"]) for row in examples
    )).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def collect_eligible(
    data: Sequence[dict[str, str]],
    tokenizer: Any,
    *,
    max_input_tokens: int = LB.MAX_INPUT_TOKENS,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    """Return gold-free examples selected only by released metadata and length."""
    examples: list[dict[str, Any]] = []
    counts = {
        "dataset_rows": len(data),
        "official_short_rows": 0,
        "short_rows_over_token_cap": 0,
    }
    for item in data:
        LB.validate_record(item)
        if item["length"] != "short":
            continue
        counts["official_short_rows"] += 1
        n_tokens = len(LB.model_input_ids(tokenizer, item))
        if n_tokens > max_input_tokens:
            counts["short_rows_over_token_cap"] += 1
            continue
        examples.append(
            {
                "id": item["_id"],
                "context_hash": LB.context_hash(item),
                "question_hash": question_hash(item),
                "input_tokens": n_tokens,
                "metadata": {
                    "domain": item["domain"],
                    "sub_domain": item["sub_domain"],
                    "difficulty": item["difficulty"],
                    "length": item["length"],
                },
            }
        )
    examples.sort(key=lambda row: row["id"])
    counts["eligible_rows"] = len(examples)
    counts["eligible_context_groups"] = len(
        {row["context_hash"] for row in examples}
    )
    return examples, counts


class _UnionFind:
    def __init__(self, keys: Iterable[str]):
        self.parent = {key: key for key in keys}

    def find(self, key: str) -> str:
        parent = self.parent[key]
        if parent != key:
            self.parent[key] = self.find(parent)
        return self.parent[key]

    def union(self, left: str, right: str) -> None:
        a, b = self.find(left), self.find(right)
        if a == b:
            return
        # The lexical root makes component construction independent of row order.
        if b < a:
            a, b = b, a
        self.parent[b] = a


def connected_component_ids(
    examples: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, str], dict[str, list[str]]]:
    """Connect rows sharing either stripped context or stripped question text."""
    ids = [str(row["id"]) for row in examples]
    if len(ids) != len(set(ids)):
        raise ValueError("eligible LongBench-v2 example IDs are not unique")
    uf = _UnionFind(ids)
    first_context: dict[str, str] = {}
    first_question: dict[str, str] = {}
    for row in examples:
        item_id = str(row["id"])
        for value, seen in (
            (str(row["context_hash"]), first_context),
            (str(row["question_hash"]), first_question),
        ):
            prior = seen.setdefault(value, item_id)
            uf.union(prior, item_id)

    members_by_root: dict[str, list[str]] = collections.defaultdict(list)
    for item_id in ids:
        members_by_root[uf.find(item_id)].append(item_id)

    component_by_id: dict[str, str] = {}
    members_by_component: dict[str, list[str]] = {}
    for members in members_by_root.values():
        ordered = sorted(members)
        payload = "".join(f"{item_id}\n" for item_id in ordered).encode("ascii")
        component_id = hashlib.sha256(LB.COMPONENT_ID_NAMESPACE + payload).hexdigest()
        if component_id in members_by_component:
            raise RuntimeError("connected-component SHA-256 collision")
        members_by_component[component_id] = ordered
        for item_id in ordered:
            component_by_id[item_id] = component_id
    return component_by_id, members_by_component


def _component_sort_key(
    members: Sequence[str], by_id: Mapping[str, Mapping[str, Any]]
) -> bytes:
    """Frozen order: min SHA256(SALT + each member context-hash ASCII)."""
    return min(
        hashlib.sha256(
            LB.SPLIT_NAMESPACE + str(by_id[item_id]["context_hash"]).encode("ascii")
        ).digest()
        for item_id in members
    )


def assign_splits(
    examples: Sequence[Mapping[str, Any]],
    *,
    component_by_id: Mapping[str, str] | None = None,
    members_by_component: Mapping[str, Sequence[str]] | None = None,
    qualification_stop: int = LB.QUALIFICATION_GROUP_STOP,
    development_stop: int = LB.DEVELOPMENT_GROUP_STOP,
) -> tuple[list[dict[str, Any]], list[str]]:
    """Assign connected components to the three frozen component slices.

    Explicit component maps make the split mechanism pluggable and testable.
    Production calls use :func:`connected_component_ids`.
    """
    by_id = {str(row["id"]): row for row in examples}
    if len(by_id) != len(examples):
        raise ValueError("eligible LongBench-v2 example IDs are not unique")
    if component_by_id is None or members_by_component is None:
        component_by_id, members_by_component = connected_component_ids(examples)
    if set(component_by_id) != set(by_id):
        raise ValueError("component map does not cover the eligible ID set exactly")
    flattened = [item for members in members_by_component.values() for item in members]
    if len(flattened) != len(set(flattened)) or set(flattened) != set(by_id):
        raise ValueError("component membership is not an exact partition of eligible IDs")

    ordered_components = sorted(
        members_by_component,
        key=lambda component: (
            _component_sort_key(members_by_component[component], by_id), component
        ),
    )
    if not 0 <= qualification_stop <= development_stop <= len(ordered_components):
        raise ValueError(
            "invalid component slice boundaries: "
            f"0:{qualification_stop}:{development_stop}:{len(ordered_components)}"
        )
    component_split: dict[str, str] = {}
    for rank, component in enumerate(ordered_components):
        if rank < qualification_stop:
            split = "qualification"
        elif rank < development_stop:
            split = "development"
        else:
            split = "confirmation"
        component_split[component] = split

    emitted: list[dict[str, Any]] = []
    for item_id in sorted(by_id):
        row = by_id[item_id]
        component = component_by_id[item_id]
        emitted.append(
            {
                "id": item_id,
                "group_id": component,
                "context_hash": str(row["context_hash"]),
                "input_tokens": int(row["input_tokens"]),
                "metadata": dict(row["metadata"]),
                "split": component_split[component],
            }
        )
    return emitted, ordered_components


def _counter(rows: Sequence[Mapping[str, Any]], field: str) -> dict[str, int]:
    values = collections.Counter(str(row["metadata"][field]) for row in rows)
    return dict(sorted(values.items()))


def split_statistics(
    examples: Sequence[Mapping[str, Any]], ordered_components: Sequence[str]
) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for split in SPLIT_NAMES:
        rows = [row for row in examples if row["split"] == split]
        groups = {row["group_id"] for row in rows}
        tokens = [int(row["input_tokens"]) for row in rows]
        out[split] = {
            "rows": len(rows),
            "groups": len(groups),
            "id_sha256": id_list_sha256(rows),
            "id_token_sha256": eligible_list_sha256(rows),
            "input_tokens_min": min(tokens) if tokens else None,
            "input_tokens_max": max(tokens) if tokens else None,
            "domains": _counter(rows, "domain"),
            "sub_domains": _counter(rows, "sub_domain"),
            "difficulties": _counter(rows, "difficulty"),
            "lengths": _counter(rows, "length"),
        }
    if sum(value["groups"] for value in out.values()) != len(ordered_components):
        raise RuntimeError("split component counts do not sum to all components")
    return out


def canonical_manifest_bytes(manifest: Mapping[str, Any]) -> bytes:
    body = dict(manifest)
    body.pop("content_sha256", None)
    return json.dumps(
        body, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def seal_manifest(manifest: Mapping[str, Any]) -> dict[str, Any]:
    out = dict(manifest)
    out.pop("content_sha256", None)
    out["content_sha256"] = hashlib.sha256(canonical_manifest_bytes(out)).hexdigest()
    return out


def verify_manifest_content_hash(manifest: Mapping[str, Any]) -> None:
    expected = manifest.get("content_sha256")
    got = hashlib.sha256(canonical_manifest_bytes(manifest)).hexdigest()
    if expected != got:
        raise ValueError(f"manifest content SHA-256 is {expected!r}, expected {got}")


def build_manifest(
    data: Sequence[dict[str, str]],
    tokenizer: Any,
    *,
    transformers_version: str,
    tokenizers_version: str,
    strict_reference: bool = True,
    qualification_stop: int = LB.QUALIFICATION_GROUP_STOP,
    development_stop: int = LB.DEVELOPMENT_GROUP_STOP,
) -> dict[str, Any]:
    examples, counts = collect_eligible(data, tokenizer)
    list_sha = eligible_list_sha256(examples)
    component_by_id, members_by_component = connected_component_ids(examples)
    emitted, component_order = assign_splits(
        examples,
        component_by_id=component_by_id,
        members_by_component=members_by_component,
        qualification_stop=qualification_stop,
        development_stop=development_stop,
    )
    counts["eligible_split_components"] = len(component_order)
    counts["eligible_question_groups"] = len(
        {row["question_hash"] for row in examples}
    )
    counts["input_tokens_min"] = min(row["input_tokens"] for row in examples)
    counts["input_tokens_max"] = max(row["input_tokens"] for row in examples)

    if strict_reference:
        failures = []
        expected = {
            "dataset_rows": 503,
            "official_short_rows": 180,
            "eligible_rows": LB.EXPECTED_ELIGIBLE_ROWS,
            "eligible_context_groups": LB.EXPECTED_CONTEXT_GROUPS,
            "eligible_split_components": LB.EXPECTED_SPLIT_COMPONENTS,
        }
        for key, value in expected.items():
            if counts.get(key) != value:
                failures.append(f"{key}={counts.get(key)} expected {value}")
        if list_sha != LB.EXPECTED_ELIGIBLE_LIST_SHA256:
            failures.append(
                f"eligible_list_sha256={list_sha} expected "
                f"{LB.EXPECTED_ELIGIBLE_LIST_SHA256}"
            )
        if transformers_version != LB.TRANSFORMERS_VERSION:
            failures.append(
                f"transformers={transformers_version} expected {LB.TRANSFORMERS_VERSION}"
            )
        if tokenizers_version != LB.TOKENIZERS_VERSION:
            failures.append(
                f"tokenizers={tokenizers_version} expected {LB.TOKENIZERS_VERSION}"
            )
        if failures:
            raise RuntimeError("LongBench-v2 audit contract failed: " + "; ".join(failures))

    split_counts = split_statistics(emitted, component_order)
    if strict_reference:
        split_failures = []
        for name, expected in LB.EXPECTED_SPLITS.items():
            for field, value in expected.items():
                if split_counts[name].get(field) != value:
                    split_failures.append(
                        f"{name}.{field}={split_counts[name].get(field)} expected {value}"
                    )
        if split_failures:
            raise RuntimeError(
                "LongBench-v2 split contract failed: " + "; ".join(split_failures)
            )

    context_sets = {
        name: {row["context_hash"] for row in emitted if row["split"] == name}
        for name in SPLIT_NAMES
    }
    if any(
        context_sets[left] & context_sets[right]
        for i, left in enumerate(SPLIT_NAMES)
        for right in SPLIT_NAMES[i + 1 :]
    ):
        raise RuntimeError("stripped context hash crosses manifest splits")
    id_sets = {
        name: {row["id"] for row in emitted if row["split"] == name}
        for name in SPLIT_NAMES
    }
    split_by_id = {row["id"]: row["split"] for row in emitted}
    question_sets = {
        name: {
            row["question_hash"]
            for row in examples
            if split_by_id[row["id"]] == name
        }
        for name in SPLIT_NAMES
    }
    group_sets = {
        name: {row["group_id"] for row in emitted if row["split"] == name}
        for name in SPLIT_NAMES
    }
    if any(
        group_sets[left] & group_sets[right]
        for i, left in enumerate(SPLIT_NAMES)
        for right in SPLIT_NAMES[i + 1 :]
    ):
        raise RuntimeError("connected component crosses manifest splits")
    for label, sets in (
        ("ID", id_sets),
        ("stripped context hash", context_sets),
        ("stripped question hash", question_sets),
    ):
        if any(
            sets[left] & sets[right]
            for i, left in enumerate(SPLIT_NAMES)
            for right in SPLIT_NAMES[i + 1 :]
        ):
            raise RuntimeError(f"{label} crosses manifest splits")

    manifest: dict[str, Any] = {
        "manifest_version": LB.MANIFEST_VERSION,
        "protocol": {
            "dataset": {
                "repo": LB.DATASET_REPO,
                "revision": LB.DATASET_REVISION,
                "data_file": "data.json",
                "sha256": LB.DATASET_SHA256,
                "bytes": LB.DATASET_BYTES,
            },
            "official_evaluation": {
                "code_repo": LB.OFFICIAL_CODE_REPO,
                "code_revision": LB.OFFICIAL_CODE_REVISION,
                "prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
                "task_version": LB.TASK_VERSION,
                "parser_version": LB.PARSER_VERSION,
            },
            "model": {
                "id": LB.MODEL_ID,
                "revision": LB.MODEL_REVISION,
                "transformers_version": transformers_version,
                "tokenizers_version": tokenizers_version,
                "chat_template_sha256": LB.CHAT_TEMPLATE_SHA256,
            },
            "eligibility": {
                "released_length_label": "short",
                "context_window": LB.CONTEXT_WINDOW,
                "reserved_output_tokens": LB.RESERVED_OUTPUT_TOKENS,
                "max_rendered_input_tokens": LB.MAX_INPUT_TOKENS,
                "rule": "length == 'short' and rendered_chat_input_tokens <= 32640",
                "eligible_list_algorithm": ELIGIBLE_LIST_ALGORITHM,
            },
            "grouping": {
                "mode": GROUPING_MODE,
                "context_hash_version": LB.CONTEXT_HASH_VERSION,
                "question_hash_version": LB.QUESTION_HASH_VERSION,
                "component_id": (
                    "sha256(component_id_namespace + sorted_member_ids_each_newline)"
                ),
                "component_id_namespace_utf8": LB.COMPONENT_ID_NAMESPACE.decode("utf-8"),
                "split_version": LB.SPLIT_VERSION,
                "split_namespace_utf8": LB.SPLIT_NAMESPACE.decode("utf-8"),
                "component_sort": (
                    "min(sha256(split_namespace + member_context_hash_ascii))"
                ),
                "component_slices": {
                    "qualification": [0, qualification_stop],
                    "development": [qualification_stop, development_stop],
                    "confirmation": [development_stop, len(component_order)],
                },
            },
            "content_hash_algorithm": CONTENT_HASH_ALGORITHM,
        },
        "counts": counts,
        "eligible_list_sha256": list_sha,
        "split_counts": split_counts,
        "split_validation": {
            "pairwise_id_intersection_count": 0,
            "pairwise_context_hash_intersection_count": 0,
            "pairwise_question_hash_intersection_count": 0,
        },
        "examples": emitted,
    }
    manifest = seal_manifest(manifest)
    verify_manifest_content_hash(manifest)
    return manifest


def validate_tokenizer(tokenizer: Any) -> None:
    template = getattr(tokenizer, "chat_template", None)
    if not isinstance(template, str) or not template:
        raise RuntimeError("pinned tokenizer has no string chat_template")
    got = sha256_text(template)
    if got != LB.CHAT_TEMPLATE_SHA256:
        raise RuntimeError(
            f"chat template SHA-256 is {got}, expected {LB.CHAT_TEMPLATE_SHA256}"
        )


def load_pinned_tokenizer(model_id: str) -> tuple[Any, str, str]:
    import tokenizers
    import transformers
    from transformers import AutoTokenizer

    if transformers.__version__ != LB.TRANSFORMERS_VERSION:
        raise RuntimeError(
            f"transformers is {transformers.__version__}, expected {LB.TRANSFORMERS_VERSION}"
        )
    if tokenizers.__version__ != LB.TOKENIZERS_VERSION:
        raise RuntimeError(
            f"tokenizers is {tokenizers.__version__}, expected {LB.TOKENIZERS_VERSION}"
        )
    local = Path(model_id).expanduser()
    if local.exists():
        resolved = local.resolve()
        if LB.MODEL_REVISION not in resolved.parts:
            raise RuntimeError(
                "local --model-id must point inside the pinned snapshot "
                f"{LB.MODEL_REVISION}, got {resolved}"
            )
        tokenizer = AutoTokenizer.from_pretrained(resolved, local_files_only=True)
    else:
        if model_id != LB.MODEL_ID:
            raise RuntimeError(
                f"--model-id must be {LB.MODEL_ID!r} or its pinned snapshot path"
            )
        tokenizer = AutoTokenizer.from_pretrained(
            model_id,
            revision=LB.MODEL_REVISION,
            local_files_only=True,
        )
    validate_tokenizer(tokenizer)
    return tokenizer, transformers.__version__, tokenizers.__version__


def encoded_manifest(manifest: Mapping[str, Any]) -> bytes:
    verify_manifest_content_hash(manifest)
    return (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode(
        "utf-8"
    )


def write_manifest(
    path: str | Path, manifest: Mapping[str, Any], *, force: bool = False
) -> str:
    """Atomically write; identical reruns are no-ops and drift needs --force."""
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_symlink():
        raise FileExistsError(f"refusing to write manifest through symlink: {destination}")
    payload = encoded_manifest(manifest)
    if destination.exists():
        current = destination.read_bytes()
        if current == payload:
            return "unchanged"
        if not force:
            raise FileExistsError(
                f"refusing to overwrite differing manifest {destination}; use --force"
            )
    temporary = destination.with_name(f".{destination.name}.tmp.{os.getpid()}")
    if temporary.exists() or temporary.is_symlink():
        raise FileExistsError(f"temporary manifest path already exists: {temporary}")
    try:
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(temporary, destination)
    finally:
        if temporary.exists():
            temporary.unlink()
    return "written"


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, help="Pinned LongBench-v2 data.json")
    parser.add_argument(
        "--model-id",
        required=True,
        help=(
            f"{LB.MODEL_ID} or local snapshot path ending in {LB.MODEL_REVISION}"
        ),
    )
    parser.add_argument("--out", required=True, help="Output manifest JSON")
    parser.add_argument(
        "--force", action="store_true", help="Atomically replace a differing output"
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    data = LB.load_dataset(args.data, authenticate=True)
    tokenizer, transformers_version, tokenizers_version = load_pinned_tokenizer(
        args.model_id
    )
    manifest = build_manifest(
        data,
        tokenizer,
        transformers_version=transformers_version,
        tokenizers_version=tokenizers_version,
        strict_reference=True,
    )
    action = write_manifest(args.out, manifest, force=args.force)
    print(
        f"{action}: {args.out}\n"
        f"eligible: {manifest['counts']['eligible_rows']} rows / "
        f"{manifest['counts']['eligible_split_components']} components\n"
        f"splits: "
        + ", ".join(
            f"{name}={manifest['split_counts'][name]['rows']} rows/"
            f"{manifest['split_counts'][name]['groups']} groups"
            for name in SPLIT_NAMES
        )
        + f"\neligible_list_sha256: {manifest['eligible_list_sha256']}\n"
        f"content_sha256: {manifest['content_sha256']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
