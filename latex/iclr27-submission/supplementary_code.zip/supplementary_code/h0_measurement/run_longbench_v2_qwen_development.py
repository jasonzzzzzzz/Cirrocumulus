#!/usr/bin/env python3
"""Run the lock-authorized V6 Qwen LongBench-v2 development study.

This runner is deliberately separate from qualification.  It authenticates an
advancing qualification lock, including the qualification artifacts and every
source hash recorded by that lock, before loading a tokenizer or model.  It
then evaluates the frozen nine-arm menu on the frozen development partition.
Artifacts contain constrained A/B/C/D predictions and scalar, branch-blind
scaffold KL values only; benchmark labels and raw logits never enter them.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

import pandas as pd
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from h0_measurement import audit_longbench_v2_qwen as QA  # noqa: E402
from sievelib import baselines as BL  # noqa: E402
from sievelib import compress as C  # noqa: E402
from sievelib import forced_choice as FC  # noqa: E402
from sievelib import policy_diagnostic as PD  # noqa: E402
from sievelib import quant, router  # noqa: E402
from sievelib import tasks_longbench_v2 as LB  # noqa: E402
import run_h0  # noqa: E402
import run_r8 as R8  # noqa: E402
import run_longbench_v2_qwen_qualification as QUAL  # noqa: E402


PROTOCOL_VERSION = "longbench_v2_sieve_v6_qwen_development_v1"
RUNNER_VERSION = "longbench_v2_qwen_development_runner_v1"
TASK_VERSION = QUAL.TASK_VERSION
ENDPOINT_VERSION = QUAL.ENDPOINT_VERSION
PROXY_RULE_VERSION = "branch_blind_scaffold_kl_v1"
QUALIFICATION_LOCK_VERSION = "longbench_v2_sieve_v6_qwen_qualification_lock_v1"
QUALIFICATION_READER_VERSION = "longbench_v2_qwen_qualification_reader_v1"
QUALIFICATION_LOCK_CONTENT_SHA256 = (
    "4ede1d969fc9ad4905587baa9000eae30f670e93752622c9ea516d90ec576491"
)
QUALIFICATION_LOCK_FILE_SHA256 = (
    "1deaad5ceb35f943301262fd81c2dfa58b1e5a0dbff2ceaa0975af8257ecebd9"
)
SPLIT = "development"

MODEL_TAG = QA.MODEL_TAG
MODEL_ID = QA.MODEL_ID
MODEL_REVISION = QA.MODEL_REVISION
TOKENIZER_REVISION = QA.TOKENIZER_REVISION
CTX = QA.CONTEXT_WINDOW
MAX_PROMPT_TOKENS = CTX - len(QA.SCAFFOLD_TOKEN_IDS)
WINDOW = 32
BUDGET = 2
CASCADE_BITS = 4
DTYPE_NAME = "bfloat16"
BIT_LIST = (1, 2, 3, 4, 5, 6, 8)
MAXB = 8
ROT_SEED = 0
NORM_CORRECT = True
CHUNK = 4096
N_LAYERS = 48
N_ATTENTION_HEADS = 32
N_KV_HEADS = 4
HEAD_DIM = 128

RAW_ARMS = (
    "fp", "uniform", "evict", "interior", "interior_pool",
    "interior_cascade", "obcache_k", "obcache_k:alloc=ada@obck_ada",
    "laprox",
)
ARM_LABELS = (
    "fp", "uniform", "evict", "interior", "interior_pool",
    "interior_cascade", "obcache_k", "obck_ada", "laprox",
)
CANDIDATES = ARM_LABELS[1:]
EXPECTED_ITEMS = 52
EXPECTED_COMPONENTS = 44
EXPECTED_PREDICTION_ROWS = EXPECTED_ITEMS * len(ARM_LABELS)
EXPECTED_PROXY_ROWS = EXPECTED_ITEMS * len(CANDIDATES)
PREDICTION_BASENAME = "longbench_v2_v6_qwen_forced_choice_development"
PROXY_BASENAME = "longbench_v2_v6_qwen_scaffold_proxy_development"

COMMON_COLUMNS = (
    "item_id", "group_id", "split", "domain", "sub_domain", "difficulty",
    "length", "context_hash", "question_hash", "prompt_token_hash",
    "input_tokens", "n_prompt_tokens", "truncated", "dataset_sha256",
    "manifest_content_sha256", "manifest_file_sha256", "task_version",
    "endpoint_version", "model", "model_id", "model_revision",
    "tokenizer_revision", "ctx", "window",
)
PREDICTION_COLUMNS = COMMON_COLUMNS + (
    "B", "arm", "arm_order", "forced_choice", "choice_index",
    "choice_entropy", "choice_margin", "choice_max_probability",
    "scaffold_token_hash", "choice_branch_ids_hash", "bits_per_token",
    "evict_frac", "allocation_id", "ctx_len", "observed_queries", "maxb",
    "rot_seed", "norm_correct",
)
PROXY_COLUMNS = COMMON_COLUMNS + (
    "B", "candidate", "candidate_order",
    "scaffold_kl_pos0", "scaffold_kl_pos1", "scaffold_kl_pos2",
    "scaffold_kl_pos3", "scaffold_kl_pos4", "scaffold_mean_kl",
    "proxy_rule_version", "scaffold_token_hash", "choice_branch_ids_hash",
    "allocation_id", "selected_policy", "fp_canonical_choice",
    "candidate_canonical_choice",
)
FORBIDDEN_FRAGMENTS = (
    "answer", "gold", "label", "correct", "score", "response", "logit",
    "probabilities", "probs",
)

QUALIFICATION_THRESHOLDS = {
    "bootstrap_draws": 10000,
    "bootstrap_quantile": 0.05,
    "bootstrap_quantile_method": "linear",
    "bootstrap_rng": "numpy.Generator(PCG64)",
    "bootstrap_seed": 0,
    "chance": 0.25,
    "qualification_fp_accuracy_min": 0.5,
    "qualification_fp_q05_strictly_above": 0.25,
    "qualification_uniform_accuracy_interval": [0.3, 0.8],
    "qualification_uniform_q05_strictly_above": 0.25,
    "development_fp_accuracy_min": 0.5,
    "development_fp_q05_strictly_above": 0.25,
    "development_fixed_accuracy_interval": [0.3, 0.8],
    "development_fixed_q05_strictly_above": 0.25,
    "development_H_min": 0.1,
    "development_H_q05_strictly_above": 0.0,
    "development_H_each_half_min": 0.05,
    "development_G_min": 0.05,
    "development_G_q05_min": 0.0,
    "development_G_each_half_min": 0.0,
    "development_G_over_H_min": 0.5,
}


class QwenDevelopmentRunnerError(RuntimeError):
    """The frozen V6 development execution contract was violated."""


def _fail(message: str) -> None:
    raise QwenDevelopmentRunnerError(message)


def _same(expected: Any, actual: Any, description: str) -> None:
    if expected != actual:
        _fail(f"{description}: expected {expected!r}, got {actual!r}")


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def _regular(path: str | os.PathLike[str], label: str) -> Path:
    candidate = Path(path).expanduser()
    if candidate.is_symlink() or not candidate.is_file():
        _fail(f"{label} must be an existing regular non-symlink file: {candidate}")
    return candidate.resolve()


def _load_object(path: str | os.PathLike[str], label: str) -> dict[str, Any]:
    candidate = _regular(path, label)
    try:
        value = json.loads(candidate.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _fail(f"cannot read {label} {candidate}: {exc}")
    if not isinstance(value, dict):
        _fail(f"{label} must contain one JSON object")
    return value


def _content_sha256(value: Mapping[str, Any]) -> str:
    payload = dict(value)
    payload.pop("content_sha256", None)
    encoded = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _relative_source(path: str | os.PathLike[str]) -> str:
    resolved = Path(path).resolve()
    try:
        return str(resolved.relative_to(ROOT.resolve()))
    except ValueError as exc:
        raise QwenDevelopmentRunnerError(
            f"executed source {resolved} is outside repository root"
        ) from exc


def _qualification_execution() -> dict[str, Any]:
    return {
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "tokenizer_revision": TOKENIZER_REVISION,
        "chat_template_sha256": QA.CHAT_TEMPLATE_SHA256,
        "enable_thinking": False,
        "ctx": CTX,
        "window": WINDOW,
        "budget": BUDGET,
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "cascade_bits": CASCADE_BITS,
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
        "n_layers": N_LAYERS,
        "n_attention_heads": N_ATTENTION_HEADS,
        "n_kv_heads": N_KV_HEADS,
        "head_dim": HEAD_DIM,
        "uniform_allocation_contract": "48_layers_x_4_kv_x_ctx_len_all_uint8_2",
        "attn_impl": C.IMPL,
        "qualification_arms": ["fp", "uniform"],
        "development_raw_arms": list(RAW_ARMS),
        "development_arms": list(ARM_LABELS),
        "development_candidates": list(CANDIDATES),
        "endpoint_version": ENDPOINT_VERSION,
        "proxy_rule_version": PROXY_RULE_VERSION,
        "scaffold_token_ids": list(QA.SCAFFOLD_TOKEN_IDS),
        "choice_branch_ids": dict(QA.CHOICE_BRANCH_IDS),
    }


def _validate_qualification_summary(summary: Mapping[str, Any]) -> None:
    expected_keys = {
        "decision", "fp_accuracy", "fp_bootstrap_gate", "fp_bootstrap_q05",
        "fp_correct", "fp_point_gate", "n_components", "n_items",
        "prediction_rows", "protocol_version", "split", "uniform_accuracy",
        "uniform_bootstrap_gate", "uniform_bootstrap_q05", "uniform_correct",
        "uniform_point_gate",
    }
    _same(expected_keys, set(summary), "qualification summary schema")
    _same("advance_v6_development", summary["decision"], "qualification decision")
    _same(QUAL.PROTOCOL_VERSION, summary["protocol_version"], "qualification protocol")
    _same("qualification", summary["split"], "qualification split")
    _same(20, int(summary["n_items"]), "qualification items")
    _same(19, int(summary["n_components"]), "qualification components")
    _same(40, int(summary["prediction_rows"]), "qualification prediction rows")
    fp_accuracy = float(summary["fp_accuracy"])
    uniform_accuracy = float(summary["uniform_accuracy"])
    fp_q05 = float(summary["fp_bootstrap_q05"])
    uniform_q05 = float(summary["uniform_bootstrap_q05"])
    if not (
        fp_accuracy >= 0.5
        and fp_q05 > 0.25
        and 0.3 <= uniform_accuracy <= 0.8
        and uniform_q05 > 0.25
    ):
        _fail("qualification summary does not satisfy the frozen advance gates")
    for field in (
        "fp_point_gate", "fp_bootstrap_gate", "uniform_point_gate",
        "uniform_bootstrap_gate",
    ):
        _same(True, summary[field], f"qualification {field}")
    _same(int(summary["fp_correct"]) / 20.0, fp_accuracy, "FP count/accuracy")
    _same(
        int(summary["uniform_correct"]) / 20.0,
        uniform_accuracy,
        "uniform count/accuracy",
    )


def authenticate_qualification_lock(
    path: str | os.PathLike[str],
    *,
    dataset_path: str | os.PathLike[str],
    source_manifest_path: str | os.PathLike[str],
    manifest_path: str | os.PathLike[str],
    config_path: str | os.PathLike[str],
    model_source: str | os.PathLike[str],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Authenticate the advance lock without loading a tokenizer or model."""
    lock_path = _regular(path, "qualification lock")
    lock = _load_object(lock_path, "qualification lock")
    expected_top = {
        "content_sha256", "decision", "endpoint_version", "execution",
        "lock_version", "partitions", "protocol_version", "provenance",
        "proxy_rule_version", "qualification", "reader_version",
        "runner_version", "task_version", "thresholds",
    }
    _same(expected_top, set(lock), "qualification lock schema")
    _same(QUALIFICATION_LOCK_FILE_SHA256, LB.sha256_file(lock_path), "qualification lock file hash")
    _same(QUALIFICATION_LOCK_CONTENT_SHA256, lock.get("content_sha256"), "frozen qualification lock content hash")
    _same(_content_sha256(lock), lock["content_sha256"], "qualification lock content hash")
    _same(QUALIFICATION_LOCK_VERSION, lock["lock_version"], "qualification lock version")
    _same("advance_v6_development", lock["decision"], "qualification lock decision")
    _same(QUAL.PROTOCOL_VERSION, lock["protocol_version"], "qualification protocol")
    _same(QUAL.RUNNER_VERSION, lock["runner_version"], "qualification runner version")
    _same(QUALIFICATION_READER_VERSION, lock["reader_version"], "qualification reader version")
    _same(TASK_VERSION, lock["task_version"], "task version")
    _same(ENDPOINT_VERSION, lock["endpoint_version"], "endpoint version")
    _same(PROXY_RULE_VERSION, lock["proxy_rule_version"], "proxy rule")
    _same(_qualification_execution(), lock["execution"], "locked execution")
    _same(QUALIFICATION_THRESHOLDS, lock["thresholds"], "locked thresholds")

    dataset = _regular(dataset_path, "dataset")
    source_manifest = _regular(source_manifest_path, "source manifest")
    manifest = _regular(manifest_path, "Qwen manifest")
    config = _regular(config_path, "model config")
    if dataset.stat().st_size != LB.DATASET_BYTES or LB.sha256_file(dataset) != LB.DATASET_SHA256:
        _fail("dataset bytes or SHA-256 differ from the frozen LongBench-v2 source")
    _same(QA.SOURCE_MANIFEST_FILE_SHA256, LB.sha256_file(source_manifest), "source manifest file hash")
    _same(QA.FROZEN_MANIFEST_FILE_SHA256, LB.sha256_file(manifest), "Qwen manifest file hash")

    manifest_object = _load_object(manifest, "Qwen manifest")
    _same(QA.FROZEN_MANIFEST_CONTENT_SHA256, manifest_object.get("content_sha256"), "Qwen manifest content hash")
    _same(QA.manifest_content_sha256(manifest_object), manifest_object.get("content_sha256"), "recomputed Qwen manifest content hash")
    partitions = lock["partitions"]
    _same(
        {
            "qualification", "development", "confirmation", "component_order"
        },
        set(partitions),
        "locked partition schema",
    )
    _same(
        "min_sha256_split_namespace_context_hash_then_component_id_v1",
        partitions["component_order"],
        "component order",
    )
    expected_halves = {
        "development": {
            "half_component_counts": [22, 22],
            "half_row_counts": [28, 24],
            "half_id_sha256": [
                "b006a353c33488d661b87932cf1c4abf8ce1e7aff63e688810a74b13a85184b8",
                "6adf6c4b4e378a4f4605a4a959df0766fad7329f384bf27c8734abaae1296a1b",
            ],
        },
        "confirmation": {
            "half_component_counts": [22, 23],
            "half_row_counts": [22, 23],
            "half_id_sha256": [
                "b0e905a214648f35d9c38a615c5e0d6811a07f69d9558209e224e023efaa8e08",
                "c95acca30821a88fa4c6a8ff6a885c9a05c867fdbb00c2b9be10659f84753d53",
            ],
        },
    }
    for split in ("qualification", "development", "confirmation"):
        expected = dict(manifest_object["split_counts"][split])
        expected.update(expected_halves.get(split, {}))
        _same(expected, partitions[split], f"locked {split} partition")

    provenance = lock["provenance"]
    expected_provenance_keys = {
        "dataset_repo", "dataset_revision", "dataset_sha256", "dataset_bytes",
        "official_prompt_sha256", "source_manifest", "source_manifest_version",
        "source_manifest_content_sha256", "source_manifest_file_sha256",
        "qwen_manifest", "qwen_manifest_version",
        "qwen_manifest_content_sha256", "qwen_manifest_file_sha256",
        "executed_source_sha256", "runner_source", "runner_source_sha256",
        "reader_source", "reader_source_sha256", "config", "config_sha256",
        "snapshot_revision", "snapshot_file_count",
        "snapshot_inventory_sha256", "snapshot_metadata_sha256",
    }
    _same(expected_provenance_keys, set(provenance), "qualification provenance schema")
    static_provenance = {
        "dataset_repo": LB.DATASET_REPO,
        "dataset_revision": LB.DATASET_REVISION,
        "dataset_sha256": LB.DATASET_SHA256,
        "dataset_bytes": LB.DATASET_BYTES,
        "official_prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
        "source_manifest": QA.SOURCE_MANIFEST_ID,
        "source_manifest_version": QA.SOURCE_MANIFEST_VERSION,
        "source_manifest_content_sha256": QA.SOURCE_MANIFEST_CONTENT_SHA256,
        "source_manifest_file_sha256": QA.SOURCE_MANIFEST_FILE_SHA256,
        "qwen_manifest_version": QA.MANIFEST_VERSION,
        "qwen_manifest_content_sha256": QA.FROZEN_MANIFEST_CONTENT_SHA256,
        "qwen_manifest_file_sha256": QA.FROZEN_MANIFEST_FILE_SHA256,
        "config_sha256": LB.sha256_file(config),
        "snapshot_revision": MODEL_REVISION,
        "snapshot_file_count": QA.SNAPSHOT_FILE_COUNT,
        "snapshot_inventory_sha256": QA.SNAPSHOT_INVENTORY_SHA256,
        "snapshot_metadata_sha256": dict(QA.SNAPSHOT_METADATA_SHA256),
    }
    for key, expected in static_provenance.items():
        _same(expected, provenance.get(key), f"qualification provenance {key}")
    _same(_relative_source(config), provenance.get("config"), "qualification config path")
    _same(manifest, Path(provenance["qwen_manifest"]).resolve(), "qualification manifest path")

    current_qualification_sources = QUAL.executed_source_hashes(config)
    _same(
        current_qualification_sources,
        provenance.get("executed_source_sha256"),
        "qualification executed-source seal",
    )
    runner_key = _relative_source(QUAL.__file__)
    reader_key = "h0_measurement/bugs/9_sota_eviction_baselines/read_longbench_v2_qwen_qualification.py"
    _same(runner_key, provenance.get("runner_source"), "qualification runner source")
    _same(current_qualification_sources[runner_key], provenance.get("runner_source_sha256"), "qualification runner source hash")
    _same(reader_key, provenance.get("reader_source"), "qualification reader source")
    _same(current_qualification_sources[reader_key], provenance.get("reader_source_sha256"), "qualification reader source hash")

    qualification = lock["qualification"]
    _same({"predictions", "predictions_sha256", "sidecar", "sidecar_sha256", "summary"}, set(qualification), "qualification artifact schema")
    predictions = _regular(qualification["predictions"], "qualification predictions")
    sidecar_path = _regular(qualification["sidecar"], "qualification sidecar")
    _same(qualification["predictions_sha256"], LB.sha256_file(predictions), "qualification prediction hash")
    _same(qualification["sidecar_sha256"], LB.sha256_file(sidecar_path), "qualification sidecar hash")
    sidecar = _load_object(sidecar_path, "qualification sidecar")
    _same(predictions.name, sidecar.get("parquet"), "qualification sidecar parquet")
    _same(qualification["predictions_sha256"], sidecar.get("parquet_sha256"), "qualification sidecar parquet hash")
    _same(QUAL.PROTOCOL_VERSION, sidecar.get("protocol_version"), "qualification sidecar protocol")
    _same(QUAL.RUNNER_VERSION, sidecar.get("runner_version"), "qualification sidecar runner")
    _validate_qualification_summary(qualification["summary"])

    snapshot = QA.authenticate_snapshot(model_source)
    _same(
        {
            "revision": provenance["snapshot_revision"],
            "file_count": provenance["snapshot_file_count"],
            "inventory_sha256": provenance["snapshot_inventory_sha256"],
            "metadata_sha256": provenance["snapshot_metadata_sha256"],
        },
        snapshot,
        "qualification snapshot attestation",
    )
    attestation = {
        "lock_path": str(lock_path),
        "lock_file_sha256": LB.sha256_file(lock_path),
        "lock_content_sha256": str(lock["content_sha256"]),
        "qualification_predictions_sha256": str(qualification["predictions_sha256"]),
        "qualification_sidecar_sha256": str(qualification["sidecar_sha256"]),
        "snapshot": snapshot,
    }
    return lock, attestation


def executed_source_hashes(config_path: str | Path) -> dict[str, str]:
    files = (
        Path(__file__), Path(QA.__file__), Path(QUAL.__file__), Path(FC.__file__),
        Path(LB.__file__), Path(PD.__file__), Path(C.__file__), Path(BL.__file__),
        Path(quant.__file__), Path(router.__file__), ROOT / "sievelib/probe.py",
        Path(run_h0.__file__), Path(R8.__file__), Path(config_path),
        HERE / "bugs/9_sota_eviction_baselines/read_longbench_v2_qwen_development.py",
        HERE / "submit_longbench_v2_qwen_development.slurm",
    )
    hashes: dict[str, str] = {}
    for path in files:
        source = _regular(path, "executed development source")
        hashes[_relative_source(source)] = LB.sha256_file(source)
    return hashes


def _validate_config(path: str | Path) -> dict[str, Any]:
    config = run_h0.load_cfg(path, MODEL_TAG, [])
    expected = {
        "id": MODEL_ID,
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
    }
    observed = {
        "id": config.get("id"),
        "dtype": config.get("dtype"),
        "bit_list": list(config.get("bit_list", [])),
        "maxb": int(config.get("maxb", -1)),
        "rot_seed": int(config.get("rot_seed", -1)),
        "norm_correct": config.get("norm_correct"),
        "chunk": int(config.get("chunk", -1)),
    }
    _same(expected, observed, "model execution config")
    if int(config.get("native_ctx", 0)) < CTX:
        _fail(f"model registry native context is shorter than frozen {CTX}")
    return config


def _model_source(value: str) -> tuple[str, dict[str, Any]]:
    candidate = Path(str(value)).expanduser()
    QA.authenticate_snapshot(candidate)
    return str(candidate.resolve()), {"local_files_only": True}


def resolve_menu() -> dict[str, BL.Baseline]:
    try:
        labels, baselines = BL.resolve_arms(list(RAW_ARMS))
    except ValueError as exc:
        _fail(f"invalid frozen arm menu: {exc}")
    _same(ARM_LABELS, tuple(labels), "resolved arm menu")
    too_long = {
        label: baseline.score_opts["obs"]
        for label, baseline in baselines.items()
        if baseline.score_opts["obs"] > WINDOW
    }
    if too_long:
        _fail(f"baseline observation windows exceed W={WINDOW}: {too_long}")
    return baselines


def validate_cuda_placement(model: Any) -> list[str]:
    raw_map = getattr(model, "hf_device_map", None)
    placements = sorted({str(value) for value in raw_map.values()}) if isinstance(raw_map, dict) else []
    bad_map = [value for value in placements if value.lower().startswith(("cpu", "disk"))]
    parameter_devices = sorted({str(parameter.device) for parameter in model.parameters()})
    bad_parameters = [value for value in parameter_devices if not (value == "cuda" or value.startswith("cuda:"))]
    if bad_map or bad_parameters:
        _fail(
            "Qwen model is not wholly resident on CUDA: "
            f"hf_device_map={placements}, parameter_devices={parameter_devices}"
        )
    observed = placements or parameter_devices
    if not observed:
        _fail("Qwen model exposes no device placement")
    print(
        f"model placement: hf_device_map={placements or 'absent'} "
        f"parameter_devices={parameter_devices}",
        flush=True,
    )
    return observed


def validate_allocation(
    by_layer: Mapping[int, torch.Tensor], *, ctx_len: int, arm: str
) -> tuple[str, dict[str, float]]:
    expected_layers = set(range(N_LAYERS))
    if set(by_layer) != expected_layers:
        _fail(f"{arm} allocation layers differ from 0..{N_LAYERS - 1}")
    expected_shape = (N_KV_HEADS, int(ctx_len))
    total = 0
    evicted = 0
    count = 0
    allowed = {0, *BIT_LIST}
    for layer in range(N_LAYERS):
        bits = by_layer[layer]
        if not isinstance(bits, torch.Tensor) or tuple(bits.shape) != expected_shape:
            _fail(f"{arm} layer {layer} shape differs from {expected_shape}")
        if bits.dtype != torch.uint8:
            _fail(f"{arm} layer {layer} dtype is {bits.dtype}, expected uint8")
        values = {int(value) for value in torch.unique(bits).detach().cpu().tolist()}
        if values - allowed:
            _fail(f"{arm} layer {layer} contains unsupported bit widths {sorted(values)}")
        total += int(bits.to(torch.int64).sum().item())
        evicted += int((bits == 0).sum().item())
        count += bits.numel()
    audit = {
        "bits_per_token": float(total / count),
        "evict_frac": float(evicted / count),
    }
    if not 0.0 <= audit["bits_per_token"] <= BUDGET + 1e-7:
        _fail(f"{arm} allocation spends {audit['bits_per_token']}, outside feasible [0,{BUDGET}]")
    if arm == "uniform":
        if evicted or total != BUDGET * count:
            _fail("uniform allocation is not exact all-2 storage")
        expected_id = QUAL.expected_uniform_allocation_id(ctx_len)
    else:
        expected_id = None
    observed_id = R8.allocation_id(by_layer)
    if expected_id is not None and observed_id != expected_id:
        _fail(f"uniform allocation ID {observed_id} differs from deterministic {expected_id}")
    return observed_id, audit


def policy_forward(
    model: Any,
    past: Any,
    *,
    last_prompt_token: int,
    prefix_tokens: Sequence[int],
    branch_ids: Mapping[str, int],
    bits_by_layer: Mapping[int, torch.Tensor] | None,
    rotation: torch.Tensor,
    norm_correct: bool,
    cache_length: int,
    device: torch.device | str,
) -> tuple[torch.Tensor, torch.Tensor, dict[str, float]]:
    """Return transient scaffold logits, endpoint logits, and applied-bit audit."""
    prefix = [int(token) for token in prefix_tokens]
    _same(list(QA.SCAFFOLD_TOKEN_IDS), prefix, "canonical scaffold tokens")
    branches = {choice: int(branch_ids[choice]) for choice in FC.CHOICES}
    _same(dict(QA.CHOICE_BRANCH_IDS), branches, "canonical choice branches")
    C.crop_to(past, int(cache_length))
    C.STATE.reset_arm()
    if C.STATE.capture or C.STATE.capture_q:
        _fail("development execution requires cache capture to be disabled")
    try:
        if bits_by_layer is not None:
            C.apply_bits(
                past,
                {int(layer): bits.long() for layer, bits in bits_by_layer.items()},
                rotation,
                bool(norm_correct),
            )
        tokens = [int(last_prompt_token), *prefix]
        input_ids = torch.tensor([tokens], dtype=torch.long, device=device)
        with torch.no_grad():
            output = model(input_ids, past_key_values=past, use_cache=True)
        logits = output.logits
        if not isinstance(logits, torch.Tensor) or logits.ndim != 3:
            _fail("model output logits must have shape [1,6,vocab]")
        if tuple(logits.shape[:2]) != (1, len(tokens)):
            _fail(f"model output logits have shape {tuple(logits.shape)}, expected [1,{len(tokens)},vocab]")
        ordered_ids = [branches[choice] for choice in FC.CHOICES]
        if min(ordered_ids) < 0 or max(ordered_ids) >= logits.shape[-1]:
            _fail("choice branch token lies outside model vocabulary")
        scaffold = logits[0, : len(prefix), :].detach().to(torch.float32)
        endpoint = logits[0, len(prefix), ordered_ids].detach().to(torch.float32)
        audit = (
            {"bits_per_token": 16.0, "evict_frac": 0.0}
            if bits_by_layer is None
            else {key: float(value) for key, value in C.bits_audit().items()}
        )
        return scaffold, endpoint, audit
    finally:
        C.STATE.enabled = False


def scaffold_metrics(
    fp_scaffold: torch.Tensor,
    candidate_scaffold: torch.Tensor,
    prefix_tokens: Sequence[int],
) -> dict[str, float]:
    if (
        not isinstance(fp_scaffold, torch.Tensor)
        or not isinstance(candidate_scaffold, torch.Tensor)
        or fp_scaffold.ndim != 2
        or candidate_scaffold.shape != fp_scaffold.shape
        or fp_scaffold.shape[0] != len(prefix_tokens)
        or fp_scaffold.device != candidate_scaffold.device
    ):
        raise ValueError("scaffold logits must share shape [5,vocab] and device")
    reference = fp_scaffold.detach().to(torch.float32)
    candidate = candidate_scaffold.detach().to(torch.float32)
    if not bool(torch.isfinite(reference).all()) or not bool(torch.isfinite(candidate).all()):
        raise ValueError("scaffold logits must be finite")
    reference_logp = torch.log_softmax(reference, dim=-1, dtype=torch.float32)
    candidate_logp = torch.log_softmax(candidate, dim=-1, dtype=torch.float32)
    per_position = torch.sum(
        reference_logp.exp() * (reference_logp - candidate_logp),
        dim=-1,
        dtype=torch.float32,
    )
    values = [max(0.0, float(value.item())) for value in per_position]
    output = {f"scaffold_kl_pos{index}": value for index, value in enumerate(values)}
    output["scaffold_mean_kl"] = float(sum(values) / len(values))
    return output


def select_scaffold_policy(
    metrics_by_candidate: Mapping[str, Mapping[str, Any]],
) -> str:
    if set(metrics_by_candidate) != set(CANDIDATES):
        raise ValueError("scaffold selection requires every candidate exactly once")
    values = [float(metrics_by_candidate[name]["scaffold_mean_kl"]) for name in CANDIDATES]
    if any(not math.isfinite(value) or value < 0.0 for value in values):
        raise ValueError("scaffold selection received an invalid KL")
    return CANDIDATES[min(range(len(CANDIDATES)), key=lambda index: values[index])]


def _common_row(
    item: Mapping[str, Any],
    entry: Mapping[str, Any],
    *,
    manifest: Mapping[str, Any],
    manifest_file_hash: str,
    prompt_ids: Sequence[int],
) -> dict[str, Any]:
    metadata = entry["metadata"]
    return {
        "item_id": str(item["_id"]),
        "group_id": str(entry["group_id"]),
        "split": SPLIT,
        "domain": str(metadata["domain"]),
        "sub_domain": str(metadata["sub_domain"]),
        "difficulty": str(metadata["difficulty"]),
        "length": str(metadata["length"]),
        "context_hash": str(entry["context_hash"]),
        "question_hash": str(entry["question_hash"]),
        "prompt_token_hash": PD.token_hash(prompt_ids),
        "input_tokens": len(prompt_ids),
        "n_prompt_tokens": len(prompt_ids),
        "truncated": False,
        "dataset_sha256": LB.DATASET_SHA256,
        "manifest_content_sha256": str(manifest["content_sha256"]),
        "manifest_file_sha256": manifest_file_hash,
        "task_version": TASK_VERSION,
        "endpoint_version": ENDPOINT_VERSION,
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "tokenizer_revision": TOKENIZER_REVISION,
        "ctx": CTX,
        "window": WINDOW,
    }


def _validate_no_forbidden_columns(columns: Sequence[str], label: str) -> None:
    allowed = {
        "forced_choice", "choice_index", "choice_entropy", "choice_margin",
        "choice_max_probability", "endpoint_version", "norm_correct",
        "fp_canonical_choice", "candidate_canonical_choice",
    }
    bad = [
        column for column in columns
        if any(fragment in column.lower() for fragment in FORBIDDEN_FRAGMENTS)
        and column not in allowed
    ]
    if bad:
        _fail(f"{label} contains forbidden columns: {bad}")


def validate_output_rows(
    predictions: Sequence[Mapping[str, Any]],
    proxy: Sequence[Mapping[str, Any]],
    item_ids: Sequence[str],
) -> None:
    expected_predictions = {(item_id, arm) for item_id in item_ids for arm in ARM_LABELS}
    expected_proxy = {(item_id, arm) for item_id in item_ids for arm in CANDIDATES}
    observed_predictions: list[tuple[str, str]] = []
    observed_proxy: list[tuple[str, str]] = []
    prediction_allocations: dict[tuple[str, str], str] = {}
    for row in predictions:
        _same(PREDICTION_COLUMNS, tuple(row), "prediction row schema/order")
        key = (str(row["item_id"]), str(row["arm"]))
        observed_predictions.append(key)
        prediction_allocations[key] = str(row["allocation_id"])
        arm = key[1]
        _same(ARM_LABELS.index(arm), int(row["arm_order"]), f"{key} arm order")
        _same(0 if arm == "fp" else BUDGET, int(row["B"]), f"{key} budget")
        choice = str(row["forced_choice"])
        if choice not in FC.CHOICES or int(row["choice_index"]) != FC.CHOICES.index(choice):
            _fail(f"invalid forced choice for {key}")
        for field in ("choice_entropy", "choice_margin", "choice_max_probability"):
            if not math.isfinite(float(row[field])):
                _fail(f"non-finite {field} for {key}")
        if not 0.0 <= float(row["choice_margin"]) <= 1.0:
            _fail(f"choice margin outside [0,1] for {key}")
        if not 0.25 <= float(row["choice_max_probability"]) <= 1.0:
            _fail(f"choice maximum outside [0.25,1] for {key}")
        if bool(row["truncated"]) or int(row["input_tokens"]) > MAX_PROMPT_TOKENS:
            _fail(f"truncated or overlength development row {key}")
        if int(row["observed_queries"]) != WINDOW:
            _fail(f"observation window drifted for {key}")
        if arm == "fp":
            _same(16.0, float(row["bits_per_token"]), f"{key} FP bits")
            _same(0.0, float(row["evict_frac"]), f"{key} FP eviction")
            _same(R8.allocation_id(None), str(row["allocation_id"]), f"{key} FP allocation")
        elif arm == "uniform":
            if not math.isclose(float(row["bits_per_token"]), BUDGET, rel_tol=0.0, abs_tol=1e-7):
                _fail(f"{key} uniform bit audit differs from exact B={BUDGET}")
            if not math.isclose(float(row["evict_frac"]), 0.0, rel_tol=0.0, abs_tol=1e-12):
                _fail(f"{key} uniform allocation unexpectedly evicts tokens")
        elif not 0.0 <= float(row["bits_per_token"]) <= BUDGET + 1e-7:
            _fail(f"{key} bit audit is outside the feasible budget")
    if (
        len(observed_predictions) != len(expected_predictions)
        or set(observed_predictions) != expected_predictions
        or len(set(observed_predictions)) != len(observed_predictions)
    ):
        _fail("prediction keys differ from exact development IDs x arms")

    for row in proxy:
        _same(PROXY_COLUMNS, tuple(row), "proxy row schema/order")
        key = (str(row["item_id"]), str(row["candidate"]))
        observed_proxy.append(key)
        candidate = key[1]
        _same(CANDIDATES.index(candidate), int(row["candidate_order"]), f"{key} candidate order")
        _same(BUDGET, int(row["B"]), f"{key} proxy budget")
        _same(PROXY_RULE_VERSION, str(row["proxy_rule_version"]), f"{key} proxy rule")
        _same(prediction_allocations[key], str(row["allocation_id"]), f"{key} proxy allocation")
        values = [float(row[f"scaffold_kl_pos{position}"]) for position in range(5)]
        if any(not math.isfinite(value) or value < 0.0 for value in values):
            _fail(f"invalid scaffold KL for {key}")
        if not math.isclose(float(row["scaffold_mean_kl"]), sum(values) / 5.0, rel_tol=1e-6, abs_tol=1e-7):
            _fail(f"scaffold KL mean disagrees with positions for {key}")
    if (
        len(observed_proxy) != len(expected_proxy)
        or set(observed_proxy) != expected_proxy
        or len(set(observed_proxy)) != len(observed_proxy)
    ):
        _fail("proxy keys differ from exact development IDs x candidates")
    for item_id in item_ids:
        block = [row for row in proxy if str(row["item_id"]) == item_id]
        _same(list(CANDIDATES), [str(row["candidate"]) for row in block], f"{item_id} proxy order")
        selected = select_scaffold_policy({
            str(row["candidate"]): {"scaffold_mean_kl": row["scaffold_mean_kl"]}
            for row in block
        })
        _same({selected}, {str(row["selected_policy"]) for row in block}, f"{item_id} selected policy")
    _validate_no_forbidden_columns(PREDICTION_COLUMNS, "prediction artifact")
    _validate_no_forbidden_columns(PROXY_COLUMNS, "proxy artifact")


def _component_fields(entries: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    members: dict[str, list[Mapping[str, Any]]] = {}
    for row in entries:
        members.setdefault(str(row["group_id"]), []).append(row)

    def order_key(group_id: str) -> tuple[bytes, str]:
        salted = min(
            hashlib.sha256(
                LB.SPLIT_NAMESPACE + str(row["context_hash"]).encode("ascii")
            ).digest()
            for row in members[group_id]
        )
        return salted, group_id

    components = sorted(members, key=order_key)
    halves = (components[: len(components) // 2], components[len(components) // 2 :])
    half_rows = [
        [row for row in entries if str(row["group_id"]) in set(groups)]
        for groups in halves
    ]
    return {
        "split_components": len(components),
        "component_order": "min_sha256_split_namespace_context_hash_then_component_id_v1",
        "half_component_counts": [len(groups) for groups in halves],
        "half_row_counts": [len(rows) for rows in half_rows],
        "half_id_sha256": [QA.id_sha256(rows) for rows in half_rows],
    }


def _sidecar_base(
    *,
    manifest: Mapping[str, Any],
    manifest_path: Path,
    manifest_file_hash: str,
    entries: Sequence[Mapping[str, Any]],
    elapsed_seconds: float,
    device_placements: Sequence[str],
    source_hashes: Mapping[str, str],
    snapshot: Mapping[str, Any],
    lock_attestation: Mapping[str, Any],
) -> dict[str, Any]:
    import tokenizers
    import transformers

    runner_key = _relative_source(__file__)
    item_ids = [str(row["id"]) for row in entries]
    return {
        "runner_version": RUNNER_VERSION,
        "protocol_version": PROTOCOL_VERSION,
        "task_version": TASK_VERSION,
        "endpoint_version": ENDPOINT_VERSION,
        "proxy_rule_version": PROXY_RULE_VERSION,
        "dataset_repo": LB.DATASET_REPO,
        "dataset_revision": LB.DATASET_REVISION,
        "dataset_sha256": LB.DATASET_SHA256,
        "dataset_bytes": LB.DATASET_BYTES,
        "official_code_repo": LB.OFFICIAL_CODE_REPO,
        "official_code_revision": LB.OFFICIAL_CODE_REVISION,
        "official_prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
        "source_manifest": QA.SOURCE_MANIFEST_ID,
        "source_manifest_version": QA.SOURCE_MANIFEST_VERSION,
        "source_manifest_content_sha256": QA.SOURCE_MANIFEST_CONTENT_SHA256,
        "source_manifest_file_sha256": QA.SOURCE_MANIFEST_FILE_SHA256,
        "manifest": str(manifest_path),
        "manifest_version": QA.MANIFEST_VERSION,
        "manifest_content_sha256": str(manifest["content_sha256"]),
        "manifest_file_sha256": manifest_file_hash,
        "split": SPLIT,
        "split_count": EXPECTED_ITEMS,
        **_component_fields(entries),
        "split_ids_sha256": QA.EXPECTED_SPLITS[SPLIT]["id_sha256"],
        "split_id_token_sha256": QA.EXPECTED_SPLITS[SPLIT]["id_token_sha256"],
        "split_id_prompt_sha256": str(manifest["split_counts"][SPLIT]["id_prompt_sha256"]),
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "tokenizer_revision": TOKENIZER_REVISION,
        "chat_template_sha256": QA.CHAT_TEMPLATE_SHA256,
        "add_generation_prompt": True,
        "enable_thinking": False,
        "transformers_version": transformers.__version__,
        "tokenizers_version": tokenizers.__version__,
        "torch_version": torch.__version__,
        "snapshot_revision": snapshot["revision"],
        "snapshot_file_count": snapshot["file_count"],
        "snapshot_inventory_sha256": snapshot["inventory_sha256"],
        "snapshot_metadata_sha256": dict(snapshot["metadata_sha256"]),
        "snapshot_seal_timing": "before_tokenizer_and_rechecked_before_artifact_write",
        "qualification_lock": str(lock_attestation["lock_path"]),
        "qualification_lock_version": QUALIFICATION_LOCK_VERSION,
        "qualification_lock_file_sha256": lock_attestation["lock_file_sha256"],
        "qualification_lock_content_sha256": lock_attestation["lock_content_sha256"],
        "qualification_predictions_sha256": lock_attestation["qualification_predictions_sha256"],
        "qualification_sidecar_sha256": lock_attestation["qualification_sidecar_sha256"],
        "ctx": CTX,
        "max_prompt_tokens": MAX_PROMPT_TOKENS,
        "window": WINDOW,
        "budget": float(BUDGET),
        "allocator_budget_rule": "feasible",
        "cascade_bits": CASCADE_BITS,
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
        "n_layers": N_LAYERS,
        "n_attention_heads": N_ATTENTION_HEADS,
        "n_kv_heads": N_KV_HEADS,
        "head_dim": HEAD_DIM,
        "uniform_allocation_contract": "48_layers_x_4_kv_x_ctx_len_all_uint8_2",
        "attn_impl": C.IMPL,
        "device_placements": list(device_placements),
        "decode": "forced_choice_teacher_forced_argmax",
        "temperature": 1.0,
        "compress_at": "official_chat_prompt_end",
        "raw_arms": list(RAW_ARMS),
        "arms": list(ARM_LABELS),
        "candidates": list(CANDIDATES),
        "allocation_id_algorithm": R8.ALLOCATION_ID_ALGORITHM,
        "scaffold_token_ids": list(QA.SCAFFOLD_TOKEN_IDS),
        "scaffold_token_hash": PD.token_hash(QA.SCAFFOLD_TOKEN_IDS),
        "choice_branch_ids": dict(QA.CHOICE_BRANCH_IDS),
        "choice_branch_ids_hash": PD.token_hash([QA.CHOICE_BRANCH_IDS[choice] for choice in FC.CHOICES]),
        "proxy_positions": list(range(len(QA.SCAFFOLD_TOKEN_IDS))),
        "proxy_dtype": "float32",
        "choice_position": len(QA.SCAFFOLD_TOKEN_IDS),
        "no_truncation": True,
        "no_free_generation": True,
        "no_raw_logits": True,
        "no_labels": True,
        "gold_unused_for_prompt_allocation_execution_and_output": True,
        "source_seal_timing": "before_tokenizer_and_rechecked_before_artifact_write",
        "executed_source_sha256": dict(source_hashes),
        "runner_source": runner_key,
        "runner_source_sha256": source_hashes[runner_key],
        "elapsed_seconds": float(elapsed_seconds),
        "item_ids_sha256": QA.id_sha256(entries),
        "item_count": len(item_ids),
    }


def run(args: argparse.Namespace) -> tuple[Path, Path]:
    config_path = _regular(args.config, "model config")
    lock, lock_attestation = authenticate_qualification_lock(
        args.qualification_lock,
        dataset_path=args.dataset,
        source_manifest_path=args.source_manifest,
        manifest_path=args.manifest,
        config_path=config_path,
        model_source=args.model_source,
    )
    del lock  # The authenticated attestation is the only lock material serialized.
    config = _validate_config(config_path)
    model_source, model_kwargs = _model_source(args.model_source)
    captured_sources = executed_source_hashes(config_path)
    snapshot = QA.authenticate_snapshot(model_source)

    # The authorization boundary above intentionally precedes these loads.
    tokenizer = QA.load_tokenizer(model_source)
    manifest_path = _regular(args.manifest, "Qwen manifest")
    source_manifest_path = _regular(args.source_manifest, "source manifest")
    manifest, manifest_file_hash = QA.authenticate_manifest(
        manifest_path,
        dataset_path=args.dataset,
        source_manifest_path=source_manifest_path,
        tokenizer=tokenizer,
    )
    data = LB.load_dataset(args.dataset, authenticate=True)
    by_id = LB.index_by_id(data)
    entries = [row for row in manifest["examples"] if row["split"] == SPLIT]
    _same(EXPECTED_ITEMS, len(entries), "development item count")
    _same(EXPECTED_COMPONENTS, len({str(row["group_id"]) for row in entries}), "development component count")
    _same(QA.EXPECTED_SPLITS[SPLIT]["id_sha256"], QA.id_sha256(entries), "development ID hash")
    _same(QA.EXPECTED_SPLITS[SPLIT]["id_token_sha256"], QA.id_token_sha256(entries), "development ID/token hash")
    baselines = resolve_menu()

    from transformers import AutoModelForCausalLM

    C.install()
    model = AutoModelForCausalLM.from_pretrained(
        model_source,
        dtype=getattr(torch, DTYPE_NAME),
        device_map=config.get("device_map", "auto"),
        attn_implementation=C.IMPL,
        trust_remote_code=True,
        **model_kwargs,
    ).eval()
    device_placements = validate_cuda_placement(model)
    device = next(model.parameters()).device
    cf = model.config
    architecture = {
        "n_layers": int(cf.num_hidden_layers),
        "n_attention_heads": int(cf.num_attention_heads),
        "n_kv_heads": int(cf.num_key_value_heads),
        "head_dim": int(getattr(cf, "head_dim", None) or cf.hidden_size // cf.num_attention_heads),
    }
    expected_architecture = {
        "n_layers": N_LAYERS,
        "n_attention_heads": N_ATTENTION_HEADS,
        "n_kv_heads": N_KV_HEADS,
        "head_dim": HEAD_DIM,
    }
    _same(expected_architecture, architecture, "Qwen attention architecture")
    rotation = quant.random_rotation(HEAD_DIM, device, torch.float32, seed=ROT_SEED)
    if not router.is_width(BUDGET, MAXB, list(BIT_LIST)):
        _fail(f"B={BUDGET} is absent from the frozen bit list")
    prefix_tokens, branch_ids = FC.canonical_choice_contract(
        tokenizer,
        expected_prefix=QA.SCAFFOLD_TOKEN_IDS,
        expected_branches=QA.CHOICE_BRANCH_IDS,
    )
    wo = BL.wo_gram(model) if any(baseline.needs_wo for baseline in baselines.values()) else None
    want, routers, need_err = R8.p2_wants(list(ARM_LABELS), False, "")
    if routers or need_err:
        _fail("fixed development policies must not activate routing or output-error oracles")

    prediction_rows: list[dict[str, Any]] = []
    proxy_rows: list[dict[str, Any]] = []
    start_all = time.time()
    print(
        f"V6 Qwen development: items={len(entries)} components={EXPECTED_COMPONENTS} "
        f"arms={list(ARM_LABELS)} B={BUDGET} ctx={CTX} W={WINDOW}; "
        "gold unused, labels absent from artifacts",
        flush=True,
    )
    for item_index, entry in enumerate(entries):
        item_id = str(entry["id"])
        item = by_id[item_id]
        prompt_ids = QA.qwen_input_ids(tokenizer, item)
        _same(int(entry["input_tokens"]), len(prompt_ids), f"{item_id} prompt token count")
        _same(str(entry["prompt_token_hash"]), PD.token_hash(prompt_ids), f"{item_id} prompt token hash")
        if len(prompt_ids) > MAX_PROMPT_TOKENS:
            _fail(f"{item_id}: prompt plus scaffold exceeds CTX={CTX}")

        ids = torch.tensor([prompt_ids], dtype=torch.long, device=device)
        t0 = time.time()
        past, _ = R8.prefill(model, ids, WINDOW, CHUNK, h2o=False)
        cache_length = C.cache_len(past)
        prefill_seconds = time.time() - t0
        _same(len(prompt_ids) - 1, cache_length, f"{item_id} prefill boundary")
        _same(WINDOW, cache_length - C.STATE.ctx_len, f"{item_id} observation window")

        bits, errors, route_log, answer_mass = R8.precompute(
            past,
            cache_length,
            want,
            [],
            [BUDGET],
            rotation,
            NORM_CORRECT,
            MAXB,
            list(BIT_LIST),
            N_LAYERS,
            cascade_bits=CASCADE_BITS,
            need_err=False,
            routes={},
            theta=1.0,
            ans_mask=None,
            bls=baselines,
            wo=wo,
        )
        if errors or route_log or answer_mass:
            _fail(f"{item_id}: fixed precompute emitted oracle data")
        expected_keys = {(candidate, BUDGET) for candidate in CANDIDATES}
        _same(expected_keys, set(bits), f"{item_id} allocation keys")
        allocation_ids = {"fp": R8.allocation_id(None)}
        allocation_audits: dict[str, dict[str, float]] = {}
        for candidate in CANDIDATES:
            allocation_id, audit = validate_allocation(
                bits[(candidate, BUDGET)], ctx_len=int(C.STATE.ctx_len), arm=candidate
            )
            allocation_ids[candidate] = allocation_id
            allocation_audits[candidate] = audit
        common = _common_row(
            item,
            entry,
            manifest=manifest,
            manifest_file_hash=manifest_file_hash,
            prompt_ids=prompt_ids,
        )

        fp_scaffold, fp_endpoint, fp_audit = policy_forward(
            model,
            past,
            last_prompt_token=prompt_ids[-1],
            prefix_tokens=prefix_tokens,
            branch_ids=branch_ids,
            bits_by_layer=None,
            rotation=rotation,
            norm_correct=NORM_CORRECT,
            cache_length=cache_length,
            device=device,
        )
        fp_summary = FC.choice_summary(fp_endpoint)
        prediction_rows.append({
            **common,
            "B": 0,
            "arm": "fp",
            "arm_order": 0,
            **fp_summary,
            "scaffold_token_hash": PD.token_hash(prefix_tokens),
            "choice_branch_ids_hash": PD.token_hash([branch_ids[choice] for choice in FC.CHOICES]),
            **fp_audit,
            "allocation_id": allocation_ids["fp"],
            "ctx_len": int(C.STATE.ctx_len),
            "observed_queries": int(cache_length - C.STATE.ctx_len),
            "maxb": MAXB,
            "rot_seed": ROT_SEED,
            "norm_correct": NORM_CORRECT,
        })

        metrics_by_candidate: dict[str, dict[str, float]] = {}
        item_proxy_rows: list[dict[str, Any]] = []
        for candidate_order, candidate in enumerate(CANDIDATES):
            candidate_scaffold, candidate_endpoint, applied_audit = policy_forward(
                model,
                past,
                last_prompt_token=prompt_ids[-1],
                prefix_tokens=prefix_tokens,
                branch_ids=branch_ids,
                bits_by_layer=bits[(candidate, BUDGET)],
                rotation=rotation,
                norm_correct=NORM_CORRECT,
                cache_length=cache_length,
                device=device,
            )
            for field in ("bits_per_token", "evict_frac"):
                if not math.isclose(
                    float(applied_audit[field]),
                    float(allocation_audits[candidate][field]),
                    rel_tol=0.0,
                    abs_tol=1e-12,
                ):
                    _fail(f"{item_id}/{candidate}: applied {field} disagrees with allocation")
            summary = FC.choice_summary(candidate_endpoint)
            scaffold = scaffold_metrics(fp_scaffold, candidate_scaffold, prefix_tokens)
            metrics_by_candidate[candidate] = scaffold
            prediction_rows.append({
                **common,
                "B": BUDGET,
                "arm": candidate,
                "arm_order": candidate_order + 1,
                **summary,
                "scaffold_token_hash": PD.token_hash(prefix_tokens),
                "choice_branch_ids_hash": PD.token_hash([branch_ids[choice] for choice in FC.CHOICES]),
                **applied_audit,
                "allocation_id": allocation_ids[candidate],
                "ctx_len": int(C.STATE.ctx_len),
                "observed_queries": int(cache_length - C.STATE.ctx_len),
                "maxb": MAXB,
                "rot_seed": ROT_SEED,
                "norm_correct": NORM_CORRECT,
            })
            item_proxy_rows.append({
                **common,
                "B": BUDGET,
                "candidate": candidate,
                "candidate_order": candidate_order,
                **scaffold,
                "proxy_rule_version": PROXY_RULE_VERSION,
                "scaffold_token_hash": PD.token_hash(prefix_tokens),
                "choice_branch_ids_hash": PD.token_hash([branch_ids[choice] for choice in FC.CHOICES]),
                "allocation_id": allocation_ids[candidate],
                "selected_policy": "",
                "fp_canonical_choice": fp_summary["forced_choice"],
                "candidate_canonical_choice": summary["forced_choice"],
            })
            del candidate_scaffold, candidate_endpoint
        selected_policy = select_scaffold_policy(metrics_by_candidate)
        for row in item_proxy_rows:
            row["selected_policy"] = selected_policy
        proxy_rows.extend(item_proxy_rows)
        print(
            f"  {item_index + 1:2d}/{len(entries)} {item_id} n={len(prompt_ids):,} "
            f"prefill={prefill_seconds:.1f}s proxy={selected_policy}",
            flush=True,
        )
        del past, bits, fp_scaffold, fp_endpoint
        if device.type == "cuda":
            torch.cuda.empty_cache()

    elapsed = time.time() - start_all
    item_ids = [str(entry["id"]) for entry in entries]
    validate_output_rows(prediction_rows, proxy_rows, item_ids)
    _same(EXPECTED_PREDICTION_ROWS, len(prediction_rows), "prediction row count")
    _same(EXPECTED_PROXY_ROWS, len(proxy_rows), "proxy row count")

    final_sources = executed_source_hashes(config_path)
    _same(captured_sources, final_sources, "development executed-source seal")
    final_snapshot = QA.authenticate_snapshot(model_source)
    _same(snapshot, final_snapshot, "development snapshot seal")
    _, final_lock_attestation = authenticate_qualification_lock(
        args.qualification_lock,
        dataset_path=args.dataset,
        source_manifest_path=args.source_manifest,
        manifest_path=args.manifest,
        config_path=config_path,
        model_source=model_source,
    )
    _same(lock_attestation, final_lock_attestation, "qualification lock seal")

    output_dir = Path(args.out_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    prediction_path = output_dir / f"{PREDICTION_BASENAME}.parquet"
    proxy_path = output_dir / f"{PROXY_BASENAME}.parquet"
    sidecar_paths = (prediction_path.with_suffix(".json"), proxy_path.with_suffix(".json"))
    if any(path.exists() or path.is_symlink() for path in (prediction_path, proxy_path, *sidecar_paths)):
        _fail(f"refusing to overwrite existing development artifact in {output_dir}")
    prediction_frame = pd.DataFrame(prediction_rows, columns=PREDICTION_COLUMNS)
    proxy_frame = pd.DataFrame(proxy_rows, columns=PROXY_COLUMNS)
    prediction_frame.to_parquet(prediction_path, index=False)
    proxy_frame.to_parquet(proxy_path, index=False)
    prediction_hash = LB.sha256_file(prediction_path)
    proxy_hash = LB.sha256_file(proxy_path)
    base = _sidecar_base(
        manifest=manifest,
        manifest_path=manifest_path,
        manifest_file_hash=manifest_file_hash,
        entries=entries,
        elapsed_seconds=elapsed,
        device_placements=device_placements,
        source_hashes=captured_sources,
        snapshot=snapshot,
        lock_attestation=lock_attestation,
    )
    prediction_sidecar = {
        **base,
        "artifact": "qwen_forced_choice_development",
        "parquet": prediction_path.name,
        "parquet_sha256": prediction_hash,
        "rows": len(prediction_frame),
        "expected_rows": EXPECTED_PREDICTION_ROWS,
        "row_key": ["item_id", "arm"],
        "paired_artifact": "qwen_scaffold_proxy_development",
        "paired_parquet": proxy_path.name,
        "paired_parquet_sha256": proxy_hash,
        "paired_rows": len(proxy_frame),
    }
    proxy_sidecar = {
        **base,
        "artifact": "qwen_scaffold_proxy_development",
        "parquet": proxy_path.name,
        "parquet_sha256": proxy_hash,
        "rows": len(proxy_frame),
        "expected_rows": EXPECTED_PROXY_ROWS,
        "row_key": ["item_id", "candidate"],
        "paired_artifact": "qwen_forced_choice_development",
        "paired_parquet": prediction_path.name,
        "paired_parquet_sha256": prediction_hash,
        "paired_rows": len(prediction_frame),
    }
    _write_json(sidecar_paths[0], prediction_sidecar)
    _write_json(sidecar_paths[1], proxy_sidecar)
    print(f"wrote {prediction_path} ({len(prediction_frame)} rows)")
    print(f"wrote {proxy_path} ({len(proxy_frame)} rows)")
    return prediction_path, proxy_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--source-manifest", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--config", default=str(HERE / "models.yaml"))
    parser.add_argument("--model-source", required=True)
    parser.add_argument("--qualification-lock", required=True)
    parser.add_argument("--out-dir", required=True)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        run(args)
    except (
        QwenDevelopmentRunnerError,
        QA.QwenManifestError,
        OSError,
        ValueError,
    ) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
