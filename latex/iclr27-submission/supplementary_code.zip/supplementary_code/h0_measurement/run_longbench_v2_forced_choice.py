#!/usr/bin/env python3
"""Run the frozen V5 LongBench-v2 forced-choice policy study.

V5 is deliberately separate from the stopped V4 generative experiment.  It
reuses V4's authenticated dataset/manifest and the tested R8 cache machinery,
but performs no free generation and never reads a gold answer.  The runner
writes label-free predictions and scalar policy diagnostics; the strict reader
joins authenticated labels only after recomputing the frozen selector.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

import pandas as pd
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from sievelib import baselines as BL  # noqa: E402
from sievelib import compress as C  # noqa: E402
from sievelib import policy_diagnostic as PD  # noqa: E402
from sievelib import quant, router  # noqa: E402
from sievelib import tasks_longbench_v2 as LB  # noqa: E402
import run_h0  # noqa: E402
import run_r8 as R8  # noqa: E402
import run_longbench_v2 as V4  # noqa: E402


PROTOCOL_VERSION = "longbench_v2_sieve_v5_forced_choice_v1"
RUNNER_VERSION = "longbench_v2_forced_choice_runner_v1"
ENDPOINT_VERSION = "canonical_abcd_forced_choice_v1"
PROXY_RULE_VERSION = "branch_blind_scaffold_kl_v1"
MODEL_TAG = V4.MODEL_TAG
MODEL_ID = V4.MODEL_ID
CTX = V4.CTX
BUDGET = V4.BUDGET
WINDOW = V4.WINDOW
CASCADE_BITS = V4.CASCADE_BITS
DTYPE_NAME = V4.DTYPE_NAME
BIT_LIST = V4.BIT_LIST
MAXB = V4.MAXB
ROT_SEED = V4.ROT_SEED
NORM_CORRECT = V4.NORM_CORRECT
CHUNK = V4.CHUNK
CHOICE_PREFIX_TOKENS = V4.CHOICE_PREFIX_TOKENS
CHOICE_BRANCH_IDS = V4.CHOICE_BRANCH_IDS
ALLOWED_SPLITS = ("development", "confirmation")
RAW_ARMS = V4.DEVELOPMENT_RAW_ARMS
ARM_LABELS = V4.DEVELOPMENT_LABELS
CANDIDATES = ARM_LABELS[1:]
EXPECTED_ROWS = {
    split: int(LB.EXPECTED_SPLITS[split]["rows"]) for split in ALLOWED_SPLITS
}
BANNED_OUTPUT_FRAGMENTS = (
    "gold", "answer", "score", "response", "logits", "label",
)

COMMON_COLUMNS = (
    "item_id", "group_id", "split", "domain", "sub_domain", "difficulty",
    "length", "context_hash", "question_hash", "prompt_token_hash",
    "input_tokens", "n_prompt_tokens", "truncated", "dataset_sha256",
    "manifest_content_sha256", "manifest_file_sha256", "task_version",
    "endpoint_version", "model", "model_id", "model_revision",
    "tokenizer_revision", "ctx", "window",
)
PREDICTION_COLUMNS = COMMON_COLUMNS + (
    "B", "arm", "arm_order", "forced_choice", "choice_index",
    "choice_entropy", "choice_margin", "choice_max_probability",
    "scaffold_token_hash", "choice_branch_ids_hash", "bits_per_token",
    "evict_frac", "allocation_id", "ctx_len", "observed_queries", "maxb",
    "rot_seed", "norm_correct",
)
PROXY_COLUMNS = COMMON_COLUMNS + (
    "B", "candidate", "candidate_order",
    "scaffold_kl_pos0", "scaffold_kl_pos1", "scaffold_kl_pos2",
    "scaffold_kl_pos3", "scaffold_kl_pos4", "scaffold_mean_kl",
    "proxy_rule_version", "scaffold_token_hash", "choice_branch_ids_hash",
    "allocation_id", "selected_policy", "fp_canonical_choice",
    "candidate_canonical_choice",
)


class ForcedChoiceRunnerError(RuntimeError):
    """The frozen V5 execution contract was violated."""


def _fail(message: str) -> None:
    raise ForcedChoiceRunnerError(message)


def sha256_file(path: str | os.PathLike[str]) -> str:
    return LB.sha256_file(path)


def sha256_text(value: str) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, default=str) + "\n")


def resolve_menu() -> dict[str, BL.Baseline]:
    try:
        labels, baselines = BL.resolve_arms(list(RAW_ARMS))
    except ValueError as exc:
        _fail(f"invalid frozen arm menu: {exc}")
    if tuple(labels) != ARM_LABELS:
        _fail(f"resolved arm order {labels} differs from frozen {ARM_LABELS}")
    too_long = {
        label: baseline.score_opts["obs"]
        for label, baseline in baselines.items()
        if baseline.score_opts["obs"] > WINDOW
    }
    if too_long:
        _fail(f"baseline observation windows exceed W={WINDOW}: {too_long}")
    return baselines


def validate_choice_contract(tokenizer: Any) -> tuple[list[int], dict[str, int]]:
    prefix, branches = LB.choice_logit_contract(tokenizer)
    V4.validate_choice_token_contract(prefix, branches)
    return prefix, branches


def choice_summary(choice_logits: torch.Tensor) -> dict[str, float | int | str]:
    """Return scalar summaries of the restricted A/B/C/D distribution."""
    if not isinstance(choice_logits, torch.Tensor) or choice_logits.shape != (4,):
        raise ValueError(
            f"restricted choice logits must have shape [4], got "
            f"{getattr(choice_logits, 'shape', None)}"
        )
    values = choice_logits.detach().to(dtype=torch.float32)
    if not bool(torch.isfinite(values).all()):
        raise ValueError("restricted choice logits must be finite")
    probabilities = torch.softmax(values, dim=-1, dtype=torch.float32)
    index = int(probabilities.argmax().item())  # torch preserves first exact tie.
    ordered = torch.sort(probabilities, descending=True).values
    logp = torch.log_softmax(values, dim=-1, dtype=torch.float32)
    entropy = -torch.sum(probabilities * logp, dtype=torch.float32)
    return {
        "forced_choice": "ABCD"[index],
        "choice_index": index,
        "choice_entropy": float(entropy.item()),
        "choice_max_probability": float(ordered[0].item()),
        "choice_margin": float((ordered[0] - ordered[1]).item()),
    }


def policy_forward(
    model: Any,
    past: Any,
    *,
    last_prompt_token: int,
    prefix_tokens: Sequence[int],
    branch_ids: Mapping[str, int],
    bits_by_layer: Mapping[int, torch.Tensor] | None,
    rotation: torch.Tensor,
    norm_correct: bool,
    L0: int,
    device: torch.device | str | None = None,
) -> tuple[torch.Tensor, torch.Tensor, dict[str, float]]:
    """Run one restored complete policy and split scaffold from endpoint logits.

    Output positions 0..4 predict the five fixed scaffold tokens.  Position 5
    predicts A/B/C/D and is excluded from the primary proxy by construction.
    Returned logits are transient float32 tensors and are never serialized.
    """
    prefix = [int(token) for token in prefix_tokens]
    if tuple(prefix) != CHOICE_PREFIX_TOKENS:
        raise ValueError("canonical scaffold token sequence drifted")
    branches = {str(key): int(value) for key, value in branch_ids.items()}
    if branches != CHOICE_BRANCH_IDS:
        raise ValueError("canonical A/B/C/D branch IDs drifted")
    C.crop_to(past, int(L0))
    C.STATE.reset_arm()
    if C.STATE.capture or C.STATE.capture_q:
        raise RuntimeError("forced-choice execution requires capture to be disabled")
    try:
        if bits_by_layer is not None:
            C.apply_bits(
                past,
                {int(layer): bits.long() for layer, bits in bits_by_layer.items()},
                rotation,
                bool(norm_correct),
            )
        if device is None:
            device = rotation.device
        tokens = [int(last_prompt_token)] + prefix
        input_ids = torch.tensor([tokens], dtype=torch.long, device=device)
        with torch.no_grad():
            output = model(input_ids, past_key_values=past, use_cache=True)
        logits = output.logits
        expected = (1, len(tokens))
        if not isinstance(logits, torch.Tensor) or logits.ndim != 3:
            raise ValueError("model output logits must have shape [1,6,vocab]")
        if tuple(logits.shape[:2]) != expected:
            raise ValueError(
                f"model output logits have shape {tuple(logits.shape)}, expected "
                f"[1,{len(tokens)},vocab]"
            )
        ordered_ids = [branches[choice] for choice in "ABCD"]
        if min(ordered_ids) < 0 or max(ordered_ids) >= logits.shape[-1]:
            raise ValueError("choice branch token lies outside model vocabulary")
        # Exact boundary pinned by V5: positions [0,5) are proxy-only; position
        # 5 is endpoint-only.  No branch logit can enter scaffold_metrics.
        scaffold_logits = logits[0, : len(prefix), :].detach().to(torch.float32)
        choice_logits = logits[0, len(prefix), ordered_ids].detach().to(torch.float32)
        audit = (
            {"bits_per_token": 16.0, "evict_frac": 0.0}
            if bits_by_layer is None
            else {
                "bits_per_token": float(C.bits_audit()["bits_per_token"]),
                "evict_frac": float(C.bits_audit()["evict_frac"]),
            }
        )
        return scaffold_logits, choice_logits, audit
    finally:
        C.STATE.enabled = False


def scaffold_metrics(
    fp_scaffold: torch.Tensor,
    candidate_scaffold: torch.Tensor,
    prefix_tokens: Sequence[int],
) -> dict[str, float]:
    """Return exactly five scalar full-vocabulary KLs and their mean."""
    if not isinstance(fp_scaffold, torch.Tensor) or not isinstance(
        candidate_scaffold, torch.Tensor
    ):
        raise TypeError("scaffold logits must be tensors")
    expected = (len(prefix_tokens),)
    if (
        fp_scaffold.ndim != 2
        or candidate_scaffold.ndim != 2
        or fp_scaffold.shape != candidate_scaffold.shape
        or fp_scaffold.shape[0] != expected[0]
    ):
        raise ValueError(
            f"scaffold logits must share shape [{expected[0]},vocab], got "
            f"{tuple(fp_scaffold.shape)} and {tuple(candidate_scaffold.shape)}"
        )
    if fp_scaffold.device != candidate_scaffold.device:
        raise ValueError("scaffold logits must share a device")
    ref = fp_scaffold.detach().to(torch.float32)
    cand = candidate_scaffold.detach().to(torch.float32)
    if not bool(torch.isfinite(ref).all()) or not bool(torch.isfinite(cand).all()):
        raise ValueError("scaffold logits must be finite")
    ref_logp = torch.log_softmax(ref, dim=-1, dtype=torch.float32)
    cand_logp = torch.log_softmax(cand, dim=-1, dtype=torch.float32)
    per_position = torch.sum(
        ref_logp.exp() * (ref_logp - cand_logp), dim=-1, dtype=torch.float32
    )
    values = [float(value.item()) for value in per_position]
    out = {f"scaffold_kl_pos{index}": value for index, value in enumerate(values)}
    out["scaffold_mean_kl"] = float(per_position.mean(dtype=torch.float32).item())
    return out


def select_scaffold_policy(
    metrics_by_candidate: Mapping[str, Mapping[str, Any]],
    candidates: Sequence[str] = CANDIDATES,
) -> str:
    names = tuple(str(value) for value in candidates)
    if set(metrics_by_candidate) != set(names) or len(names) != len(set(names)):
        raise ValueError("scaffold selection requires each ordered candidate exactly once")
    values = []
    for name in names:
        value = float(metrics_by_candidate[name]["scaffold_mean_kl"])
        if not math.isfinite(value) or value < -1e-6:
            raise ValueError(f"invalid scaffold KL for {name}: {value}")
        values.append(value)
    return names[min(range(len(names)), key=lambda index: values[index])]


def _common_row(
    item: Mapping[str, str],
    entry: Mapping[str, Any],
    *,
    split: str,
    manifest: Mapping[str, Any],
    manifest_file_hash: str,
    prompt_ids: Sequence[int],
) -> dict[str, Any]:
    return {
        "item_id": item["_id"],
        "group_id": entry["group_id"],
        "split": split,
        "domain": item["domain"],
        "sub_domain": item["sub_domain"],
        "difficulty": item["difficulty"],
        "length": item["length"],
        "context_hash": entry["context_hash"],
        "question_hash": sha256_text(item["question"].strip()),
        "prompt_token_hash": PD.token_hash(prompt_ids),
        "input_tokens": len(prompt_ids),
        "n_prompt_tokens": len(prompt_ids),
        "truncated": False,
        "dataset_sha256": LB.DATASET_SHA256,
        "manifest_content_sha256": manifest["content_sha256"],
        "manifest_file_sha256": manifest_file_hash,
        "task_version": LB.TASK_VERSION,
        "endpoint_version": ENDPOINT_VERSION,
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": LB.MODEL_REVISION,
        "tokenizer_revision": LB.MODEL_REVISION,
        "ctx": CTX,
        "window": WINDOW,
    }


def _reject_forbidden_columns(frame: pd.DataFrame, label: str) -> None:
    bad = [
        column
        for column in frame.columns
        if any(fragment in column.lower() for fragment in BANNED_OUTPUT_FRAGMENTS)
        and column not in {
            "forced_choice",
            "choice_index",
            "choice_entropy",
            "choice_max_probability",
            "choice_margin",
            "endpoint_version",
        }
    ]
    if bad:
        _fail(f"{label} contains forbidden label/raw-output columns: {bad}")


def validate_output_rows(
    predictions: Sequence[Mapping[str, Any]],
    proxy: Sequence[Mapping[str, Any]],
    item_ids: Sequence[str],
) -> None:
    for row in predictions:
        if set(row) != set(PREDICTION_COLUMNS):
            _fail(
                f"prediction schema differs: missing={sorted(set(PREDICTION_COLUMNS) - set(row))}, "
                f"extra={sorted(set(row) - set(PREDICTION_COLUMNS))}"
            )
    for row in proxy:
        if set(row) != set(PROXY_COLUMNS):
            _fail(
                f"proxy schema differs: missing={sorted(set(PROXY_COLUMNS) - set(row))}, "
                f"extra={sorted(set(row) - set(PROXY_COLUMNS))}"
            )
    expected_predictions = {
        (item_id, arm) for item_id in item_ids for arm in ARM_LABELS
    }
    observed_predictions = [
        (str(row["item_id"]), str(row["arm"])) for row in predictions
    ]
    if (
        len(observed_predictions) != len(expected_predictions)
        or set(observed_predictions) != expected_predictions
        or len(set(observed_predictions)) != len(observed_predictions)
    ):
        _fail("prediction row keys differ from exact split x frozen arms")
    expected_proxy = {
        (item_id, candidate) for item_id in item_ids for candidate in CANDIDATES
    }
    observed_proxy = [
        (str(row["item_id"]), str(row["candidate"])) for row in proxy
    ]
    if (
        len(observed_proxy) != len(expected_proxy)
        or set(observed_proxy) != expected_proxy
        or len(set(observed_proxy)) != len(observed_proxy)
    ):
        _fail("proxy row keys differ from exact split x frozen candidates")

    pred_alloc = {
        (str(row["item_id"]), str(row["arm"])): str(row["allocation_id"])
        for row in predictions
    }
    for row in predictions:
        arm = str(row["arm"])
        if row["forced_choice"] not in tuple("ABCD"):
            _fail(f"invalid forced choice in {row['item_id']}/{arm}")
        if int(row["choice_index"]) != "ABCD".index(str(row["forced_choice"])):
            _fail("choice index and letter disagree")
        expected_budget = 0 if arm == "fp" else BUDGET
        if int(row["B"]) != expected_budget:
            _fail(f"{arm} has B={row['B']}, expected {expected_budget}")
        bits = float(row["bits_per_token"])
        if arm == "fp":
            if bits != 16.0:
                _fail("FP bit audit drifted")
        elif bits > BUDGET + 1e-7:
            _fail(f"{arm} exceeds B={BUDGET}: {bits}")
        for field in ("choice_entropy", "choice_max_probability", "choice_margin"):
            if not math.isfinite(float(row[field])):
                _fail(f"{field} is non-finite")
        if not 0.0 <= float(row["choice_max_probability"]) <= 1.0:
            _fail("choice maximum probability lies outside [0,1]")
        if not 0.0 <= float(row["choice_margin"]) <= 1.0:
            _fail("choice margin lies outside [0,1]")

    for item_id in item_ids:
        block = [row for row in proxy if str(row["item_id"]) == item_id]
        if [str(row["candidate"]) for row in block] != list(CANDIDATES):
            _fail(f"proxy candidate order drifted for {item_id}")
        metrics = {
            str(row["candidate"]): {
                "scaffold_mean_kl": float(row["scaffold_mean_kl"])
            }
            for row in block
        }
        selected = select_scaffold_policy(metrics)
        if {str(row["selected_policy"]) for row in block} != {selected}:
            _fail(f"saved scaffold selection is wrong for {item_id}")
        for index, row in enumerate(block):
            candidate = str(row["candidate"])
            if int(row["candidate_order"]) != index:
                _fail(f"proxy candidate order index drifted for {item_id}")
            if int(row["B"]) != BUDGET:
                _fail("proxy budget drifted")
            if str(row["allocation_id"]) != pred_alloc[(item_id, candidate)]:
                _fail(f"prediction/proxy allocation mismatch for {item_id}/{candidate}")
            values = []
            for position in range(len(CHOICE_PREFIX_TOKENS)):
                field = f"scaffold_kl_pos{position}"
                value = float(row[field])
                if not math.isfinite(value) or value < -1e-6:
                    _fail(f"{field} is invalid for {item_id}/{candidate}")
                values.append(value)
            if not math.isfinite(float(row["scaffold_mean_kl"])):
                _fail(f"scaffold mean KL is non-finite for {item_id}/{candidate}")
            expected_mean = sum(values) / len(values)
            if not math.isclose(
                float(row["scaffold_mean_kl"]), expected_mean,
                rel_tol=1e-5, abs_tol=1e-6
            ):
                _fail(f"scaffold mean KL disagrees with positions for {item_id}/{candidate}")

    prediction_frame = pd.DataFrame(predictions)
    proxy_frame = pd.DataFrame(proxy)
    _reject_forbidden_columns(prediction_frame, "prediction artifact")
    _reject_forbidden_columns(proxy_frame, "proxy artifact")


def _component_sidecar_fields(
    manifest: Mapping[str, Any], split: str
) -> dict[str, Any]:
    rows = [row for row in manifest["examples"] if row["split"] == split]
    members: dict[str, list[Mapping[str, Any]]] = {}
    for row in rows:
        members.setdefault(str(row["group_id"]), []).append(row)

    def order_key(group_id: str) -> tuple[bytes, str]:
        salted = min(
            hashlib.sha256(
                LB.SPLIT_NAMESPACE + str(row["context_hash"]).encode("ascii")
            ).digest()
            for row in members[group_id]
        )
        return salted, group_id

    components = sorted(members, key=order_key)
    midpoint = len(components) // 2
    halves = (components[:midpoint], components[midpoint:])
    half_rows = [
        [row for row in rows if str(row["group_id"]) in set(groups)]
        for groups in halves
    ]
    return {
        "split_components": len(components),
        "component_order": (
            "min_sha256_split_namespace_context_hash_then_component_id_v1"
        ),
        "half_component_counts": [len(groups) for groups in halves],
        "half_row_counts": [len(block) for block in half_rows],
        "half_id_sha256": [
            V4.canonical_ids_sha256(str(row["id"]) for row in block)
            for block in half_rows
        ],
    }


def _sidecar_base(
    *,
    split: str,
    manifest: Mapping[str, Any],
    manifest_path: Path,
    manifest_file_hash: str,
    item_ids: Sequence[str],
    chat_template_hash: str,
) -> dict[str, Any]:
    import tokenizers
    import transformers

    return {
        "runner_version": RUNNER_VERSION,
        "protocol_version": PROTOCOL_VERSION,
        "dataset_repo": LB.DATASET_REPO,
        "dataset_revision": LB.DATASET_REVISION,
        "dataset_sha256": LB.DATASET_SHA256,
        "dataset_bytes": LB.DATASET_BYTES,
        "official_code_repo": LB.OFFICIAL_CODE_REPO,
        "official_code_revision": LB.OFFICIAL_CODE_REVISION,
        "official_prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
        "task_version": LB.TASK_VERSION,
        "endpoint_version": ENDPOINT_VERSION,
        "context_hash_version": LB.CONTEXT_HASH_VERSION,
        "question_hash_version": LB.QUESTION_HASH_VERSION,
        "manifest": str(manifest_path),
        "manifest_version": manifest["manifest_version"],
        "manifest_content_sha256": manifest["content_sha256"],
        "manifest_file_sha256": manifest_file_hash,
        "eligible_list_sha256": manifest["eligible_list_sha256"],
        "split": split,
        "split_count": len(item_ids),
        **_component_sidecar_fields(manifest, split),
        "split_ids_sha256": V4.canonical_ids_sha256(item_ids),
        "split_id_token_sha256": LB.EXPECTED_SPLITS[split]["id_token_sha256"],
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": LB.MODEL_REVISION,
        "tokenizer_revision": LB.MODEL_REVISION,
        "ctx": CTX,
        "max_input_tokens": LB.MAX_INPUT_TOKENS,
        "decode": "forced_choice_teacher_forced_argmax",
        "temperature": 1.0,
        "window": WINDOW,
        "budget": float(BUDGET),
        "cascade_bits": CASCADE_BITS,
        "allocator_budget_rule": "feasible",
        "compress_at": "official_chat_prompt_end",
        "raw_arms": list(RAW_ARMS),
        "arms": list(ARM_LABELS),
        "candidates": list(CANDIDATES),
        "allocation_id_algorithm": R8.ALLOCATION_ID_ALGORITHM,
        "chat_template_sha256": chat_template_hash,
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
        "attn_impl": C.IMPL,
        "transformers_version": transformers.__version__,
        "tokenizers_version": tokenizers.__version__,
        "no_truncation": True,
        "no_raw_logits": True,
        "no_labels": True,
        "no_free_generation": True,
        "proxy_dtype": "float32",
        "scaffold_token_ids": list(CHOICE_PREFIX_TOKENS),
        "scaffold_token_hash": PD.token_hash(CHOICE_PREFIX_TOKENS),
        "choice_branch_ids": CHOICE_BRANCH_IDS,
        "choice_branch_ids_hash": PD.token_hash(
            [CHOICE_BRANCH_IDS[choice] for choice in "ABCD"]
        ),
        "proxy_rule_version": PROXY_RULE_VERSION,
        "proxy_positions": list(range(len(CHOICE_PREFIX_TOKENS))),
        "choice_position": len(CHOICE_PREFIX_TOKENS),
    }


def run(args: argparse.Namespace) -> tuple[Path, Path]:
    if args.split not in ALLOWED_SPLITS:
        _fail(f"split must be one of {ALLOWED_SPLITS}")
    if args.split == "confirmation" and not args.development_lock:
        _fail("confirmation requires --development-lock from an advancing strict reader")
    if args.split == "development" and args.development_lock:
        _fail("development must not consume a confirmation lock")
    baselines = resolve_menu()

    manifest_path = Path(args.manifest).resolve()
    manifest, manifest_file_hash = V4.load_manifest(manifest_path)
    V4.validate_protocol_static(manifest)
    data = LB.load_dataset(args.dataset, authenticate=True)

    config = run_h0.load_cfg(args.config, MODEL_TAG, [])
    if config.get("id") != MODEL_ID:
        _fail(f"models.yaml maps {MODEL_TAG} to {config.get('id')!r}")
    frozen_config = {
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
    }
    observed_config = {
        "dtype": config.get("dtype"),
        "bit_list": list(config.get("bit_list", [])),
        "maxb": int(config.get("maxb", -1)),
        "rot_seed": int(config.get("rot_seed", -1)),
        "norm_correct": config.get("norm_correct"),
        "chunk": int(config.get("chunk", -1)),
    }
    if observed_config != frozen_config:
        _fail(f"model execution config {observed_config} differs from {frozen_config}")
    if int(config.get("native_ctx", config["ctx"])) < CTX:
        _fail("model registry native context is shorter than 32768")

    from transformers import AutoModelForCausalLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID, revision=LB.MODEL_REVISION, trust_remote_code=True
    )
    chat_template_hash = V4.validate_runtime_protocol(manifest["protocol"], tokenizer)
    prefix_tokens, branch_ids = validate_choice_contract(tokenizer)
    selected = V4.authenticate_examples(data, manifest, tokenizer, args.split)
    item_ids = [item["_id"] for item, _, _ in selected]
    if len(item_ids) != EXPECTED_ROWS[args.split]:
        _fail(f"{args.split} has {len(item_ids)} rows, expected {EXPECTED_ROWS[args.split]}")

    C.install()
    dtype = getattr(torch, DTYPE_NAME)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID,
        revision=LB.MODEL_REVISION,
        dtype=dtype,
        device_map=config.get("device_map", "auto"),
        attn_implementation=C.IMPL,
        trust_remote_code=True,
    ).eval()
    device = next(model.parameters()).device
    cf = model.config
    n_layers = int(cf.num_hidden_layers)
    head_dim = getattr(cf, "head_dim", None) or cf.hidden_size // cf.num_attention_heads
    rotation = quant.random_rotation(
        head_dim, device, torch.float32, seed=ROT_SEED
    )
    if not router.is_width(BUDGET, MAXB, list(BIT_LIST)):
        _fail(f"uniform B={BUDGET} is absent from bit list {BIT_LIST}")
    wo = (
        BL.wo_gram(model)
        if any(baseline.needs_wo for baseline in baselines.values())
        else None
    )
    want, routers, need_err = R8.p2_wants(list(ARM_LABELS), False, "")
    if routers or need_err:
        _fail("V5 fixed policies must not activate routes or output-error oracles")

    print(
        f"V5 forced-choice {args.split}: {len(selected)} items, "
        f"arms={list(ARM_LABELS)}, B={BUDGET}, W={WINDOW}; no generation",
        flush=True,
    )
    prediction_rows: list[dict[str, Any]] = []
    proxy_rows: list[dict[str, Any]] = []
    start_all = time.time()

    for item_index, (item, entry, prompt_ids) in enumerate(selected):
        ids = torch.tensor([prompt_ids], dtype=torch.long, device=device)
        t0 = time.time()
        past, _ = R8.prefill(model, ids, WINDOW, CHUNK, h2o=False)
        L0 = C.cache_len(past)
        t_prefill = time.time() - t0
        if L0 != len(prompt_ids) - 1:
            _fail(f"{item['_id']}: prefill boundary {L0} != prompt length - 1")
        if L0 - C.STATE.ctx_len != WINDOW:
            _fail(f"{item['_id']}: observed query window drifted")

        t0 = time.time()
        bits, errors, route_log, answer_mass = R8.precompute(
            past,
            L0,
            want,
            [],
            [BUDGET],
            rotation,
            NORM_CORRECT,
            MAXB,
            list(BIT_LIST),
            n_layers,
            cascade_bits=CASCADE_BITS,
            need_err=False,
            routes={},
            theta=1.0,
            ans_mask=None,
            bls=baselines,
            wo=wo,
        )
        t_precompute = time.time() - t0
        if errors or route_log or answer_mass:
            _fail(f"{item['_id']}: fixed precompute produced oracle data")
        expected_keys = {(arm, BUDGET) for arm in CANDIDATES}
        if set(bits) != expected_keys:
            _fail(f"{item['_id']}: allocation keys {set(bits)} != {expected_keys}")
        allocation_ids = {"fp": R8.allocation_id(None)}
        allocation_ids.update(
            {arm: R8.allocation_id(bits[(arm, BUDGET)]) for arm in CANDIDATES}
        )
        common = _common_row(
            item,
            entry,
            split=args.split,
            manifest=manifest,
            manifest_file_hash=manifest_file_hash,
            prompt_ids=prompt_ids,
        )

        t0 = time.time()
        fp_scaffold, fp_choice_logits, fp_audit = policy_forward(
            model,
            past,
            last_prompt_token=prompt_ids[-1],
            prefix_tokens=prefix_tokens,
            branch_ids=branch_ids,
            bits_by_layer=None,
            rotation=rotation,
            norm_correct=NORM_CORRECT,
            L0=L0,
            device=device,
        )
        fp_elapsed = time.time() - t0
        fp_summary = choice_summary(fp_choice_logits)
        prediction_rows.append(
            {
                **common,
                "arm": "fp",
                "arm_order": 0,
                "B": 0,
                **fp_summary,
                "scaffold_token_hash": PD.token_hash(prefix_tokens),
                "choice_branch_ids_hash": PD.token_hash(
                    [branch_ids[choice] for choice in "ABCD"]
                ),
                **fp_audit,
                "allocation_id": allocation_ids["fp"],
                "ctx_len": int(C.STATE.ctx_len),
                "observed_queries": int(L0 - C.STATE.ctx_len),
                "maxb": MAXB,
                "rot_seed": ROT_SEED,
                "norm_correct": NORM_CORRECT,
            }
        )

        metrics_by_candidate: dict[str, dict[str, Any]] = {}
        item_proxy_rows: list[dict[str, Any]] = []
        for candidate_order, candidate in enumerate(CANDIDATES):
            t0 = time.time()
            candidate_scaffold, candidate_choice_logits, audit = policy_forward(
                model,
                past,
                last_prompt_token=prompt_ids[-1],
                prefix_tokens=prefix_tokens,
                branch_ids=branch_ids,
                bits_by_layer=bits[(candidate, BUDGET)],
                rotation=rotation,
                norm_correct=NORM_CORRECT,
                L0=L0,
                device=device,
            )
            elapsed = time.time() - t0
            candidate_summary = choice_summary(candidate_choice_logits)
            scaffold = scaffold_metrics(
                fp_scaffold, candidate_scaffold, prefix_tokens
            )
            metrics_by_candidate[candidate] = scaffold
            prediction_rows.append(
                {
                    **common,
                    "arm": candidate,
                    "arm_order": candidate_order + 1,
                    "B": BUDGET,
                    **candidate_summary,
                    "scaffold_token_hash": PD.token_hash(prefix_tokens),
                    "choice_branch_ids_hash": PD.token_hash(
                        [branch_ids[choice] for choice in "ABCD"]
                    ),
                    **audit,
                    "allocation_id": allocation_ids[candidate],
                    "ctx_len": int(C.STATE.ctx_len),
                    "observed_queries": int(L0 - C.STATE.ctx_len),
                    "maxb": MAXB,
                    "rot_seed": ROT_SEED,
                    "norm_correct": NORM_CORRECT,
                }
            )
            item_proxy_rows.append(
                {
                    **common,
                    "candidate": candidate,
                    "candidate_order": candidate_order,
                    "B": BUDGET,
                    **scaffold,
                    "proxy_rule_version": PROXY_RULE_VERSION,
                    "scaffold_token_hash": PD.token_hash(prefix_tokens),
                    "choice_branch_ids_hash": PD.token_hash(
                        [branch_ids[choice] for choice in "ABCD"]
                    ),
                    "allocation_id": allocation_ids[candidate],
                    "fp_canonical_choice": fp_summary["forced_choice"],
                    "candidate_canonical_choice": candidate_summary["forced_choice"],
                }
            )
            del candidate_scaffold, candidate_choice_logits

        selected_policy = select_scaffold_policy(metrics_by_candidate)
        for row in item_proxy_rows:
            row["selected_policy"] = selected_policy
        proxy_rows.extend(item_proxy_rows)
        print(
            f"  {item_index + 1:3d}/{len(selected)} {item['_id']} "
            f"n={len(prompt_ids):,} prefill={t_prefill:.1f}s "
            f"proxy={selected_policy}",
            flush=True,
        )
        del past, bits, fp_scaffold, fp_choice_logits
        if device.type == "cuda":
            torch.cuda.empty_cache()

    elapsed_all = time.time() - start_all
    validate_output_rows(prediction_rows, proxy_rows, item_ids)

    output_dir = Path(args.out_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    prediction_path = (
        output_dir
        / f"longbench_v2_v5_forced_choice_{args.split}.parquet"
    )
    proxy_path = (
        output_dir
        / f"longbench_v2_v5_scaffold_proxy_{args.split}.parquet"
    )
    prediction_frame = pd.DataFrame(prediction_rows, columns=PREDICTION_COLUMNS)
    proxy_frame = pd.DataFrame(proxy_rows, columns=PROXY_COLUMNS)
    prediction_frame.to_parquet(prediction_path, index=False)
    proxy_frame.to_parquet(proxy_path, index=False)

    base = _sidecar_base(
        split=args.split,
        manifest=manifest,
        manifest_path=manifest_path,
        manifest_file_hash=manifest_file_hash,
        item_ids=item_ids,
        chat_template_hash=chat_template_hash,
    )
    prediction_hash = sha256_file(prediction_path)
    proxy_hash = sha256_file(proxy_path)
    prediction_sidecar = {
        **base,
        "artifact": "forced_choice_predictions",
        "parquet": prediction_path.name,
        "parquet_sha256": prediction_hash,
        "rows": len(prediction_frame),
        "expected_rows": len(item_ids) * len(ARM_LABELS),
        "row_key": ["item_id", "arm"],
        "paired_artifact": "scaffold_proxy",
        "paired_parquet": proxy_path.name,
        "paired_parquet_sha256": proxy_hash,
        "paired_rows": len(proxy_frame),
    }
    proxy_sidecar = {
        **base,
        "artifact": "scaffold_proxy",
        "parquet": proxy_path.name,
        "parquet_sha256": proxy_hash,
        "rows": len(proxy_frame),
        "expected_rows": len(item_ids) * len(CANDIDATES),
        "row_key": ["item_id", "candidate"],
        "paired_artifact": "forced_choice_predictions",
        "paired_parquet": prediction_path.name,
        "paired_parquet_sha256": prediction_hash,
        "paired_rows": len(prediction_frame),
    }
    _write_json(prediction_path.with_suffix(".json"), prediction_sidecar)
    _write_json(proxy_path.with_suffix(".json"), proxy_sidecar)
    print(f"wrote {prediction_path} ({len(prediction_frame)} rows)")
    print(f"wrote {proxy_path} ({len(proxy_frame)} rows)")
    return prediction_path, proxy_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True, help="pinned LongBench-v2 JSON")
    parser.add_argument(
        "--manifest",
        default=str(
            HERE
            / "bugs/9_sota_eviction_baselines/longbench_v2_manifest.json"
        ),
    )
    parser.add_argument("--split", required=True, choices=ALLOWED_SPLITS)
    parser.add_argument("--config", default=str(HERE / "models.yaml"))
    parser.add_argument("--out-dir", required=True)
    parser.add_argument(
        "--development-lock",
        default="",
        help="required confirmation lock; forbidden for development",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        run(args)
    except (ForcedChoiceRunnerError, V4.LongBenchRunnerError, ValueError, OSError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
