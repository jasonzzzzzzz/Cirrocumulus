#!/usr/bin/env python3
"""Run the frozen V6 Qwen LongBench-v2 qualification (FP + uniform B=2)."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

import pandas as pd
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from h0_measurement import audit_longbench_v2_qwen as QA  # noqa: E402
from sievelib import compress as C  # noqa: E402
from sievelib import forced_choice as FC  # noqa: E402
from sievelib import policy_diagnostic as PD  # noqa: E402
from sievelib import quant, router  # noqa: E402
from sievelib import tasks_longbench_v2 as LB  # noqa: E402
import run_h0  # noqa: E402
import run_r8 as R8  # noqa: E402


PROTOCOL_VERSION = "longbench_v2_sieve_v6_qwen_qualification_v1"
RUNNER_VERSION = "longbench_v2_qwen_qualification_runner_v1"
TASK_VERSION = "longbench_v2_0shot_qwen3_2507_no_thinking_v1"
ENDPOINT_VERSION = "canonical_abcd_forced_choice_v1"
SPLIT = "qualification"
MODEL_TAG = QA.MODEL_TAG
MODEL_ID = QA.MODEL_ID
MODEL_REVISION = QA.MODEL_REVISION
TOKENIZER_REVISION = QA.TOKENIZER_REVISION
CTX = QA.CONTEXT_WINDOW
MAX_PROMPT_TOKENS = CTX - len(QA.SCAFFOLD_TOKEN_IDS)
WINDOW = 32
BUDGET = 2
CASCADE_BITS = 4
DTYPE_NAME = "bfloat16"
BIT_LIST = (1, 2, 3, 4, 5, 6, 8)
MAXB = 8
ROT_SEED = 0
NORM_CORRECT = True
CHUNK = 4096
N_LAYERS = 48
N_ATTENTION_HEADS = 32
N_KV_HEADS = 4
HEAD_DIM = 128
ARMS = ("fp", "uniform")
EXPECTED_ITEMS = 20
EXPECTED_COMPONENTS = 19
ARTIFACT_BASENAME = "longbench_v2_v6_qwen_forced_choice_qualification"

COMMON_COLUMNS = (
    "item_id", "group_id", "split", "domain", "sub_domain", "difficulty",
    "length", "context_hash", "question_hash", "prompt_token_hash",
    "input_tokens", "n_prompt_tokens", "truncated", "dataset_sha256",
    "manifest_content_sha256", "manifest_file_sha256", "task_version",
    "endpoint_version", "model", "model_id", "model_revision",
    "tokenizer_revision", "ctx", "window",
)
PREDICTION_COLUMNS = COMMON_COLUMNS + (
    "B", "arm", "arm_order", "forced_choice", "choice_index",
    "choice_entropy", "choice_margin", "choice_max_probability",
    "scaffold_token_hash", "choice_branch_ids_hash", "bits_per_token",
    "evict_frac", "allocation_id", "ctx_len", "observed_queries", "maxb",
    "rot_seed", "norm_correct",
)
FORBIDDEN_FRAGMENTS = (
    "answer", "gold", "label", "correct", "score", "response", "logit",
    "probabilities", "probs",
)


class QwenQualificationRunnerError(RuntimeError):
    """The frozen V6 qualification execution contract was violated."""


def _fail(message: str) -> None:
    raise QwenQualificationRunnerError(message)


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def _relative_source(path: str | os.PathLike[str]) -> str:
    resolved = Path(path).resolve()
    try:
        return str(resolved.relative_to(ROOT.resolve()))
    except ValueError as exc:
        raise QwenQualificationRunnerError(
            f"executed source {resolved} is outside repository root"
        ) from exc


def executed_source_hashes(config_path: str | Path) -> dict[str, str]:
    files = (
        Path(__file__), Path(QA.__file__), Path(FC.__file__), Path(LB.__file__),
        Path(PD.__file__), Path(C.__file__), Path(quant.__file__),
        Path(router.__file__), ROOT / "sievelib/probe.py",
        Path(run_h0.__file__), Path(R8.__file__), Path(config_path),
        HERE / "bugs/9_sota_eviction_baselines/read_longbench_v2_qwen_qualification.py",
        HERE / "submit_longbench_v2_qwen_qualification.slurm",
    )
    return {
        _relative_source(path): LB.sha256_file(path)
        for path in files
    }


def _model_source(value: str) -> tuple[str, dict[str, Any]]:
    candidate = Path(str(value)).expanduser()
    try:
        QA.authenticate_snapshot(candidate)
    except QA.QwenManifestError as exc:
        _fail(f"model source is not the frozen local snapshot: {exc}")
    return str(candidate.resolve()), {"local_files_only": True}


def expected_uniform_allocation_id(ctx_len: int) -> str:
    """Hash the exact 48 x [4,ctx_len] all-2 allocation without large tensors."""
    length = int(ctx_len)
    if length <= 0:
        raise ValueError("uniform allocation context length must be positive")
    digest = hashlib.sha256()
    payload = bytes([BUDGET]) * (N_KV_HEADS * length)
    for layer in range(N_LAYERS):
        digest.update(
            f"layer={layer};shape={N_KV_HEADS},{length};dtype=uint8\n".encode("ascii")
        )
        digest.update(payload)
    return digest.hexdigest()


def validate_uniform_allocation(
    by_layer: Mapping[int, torch.Tensor], *, ctx_len: int
) -> str:
    expected_layers = set(range(N_LAYERS))
    if set(by_layer) != expected_layers:
        _fail(
            f"uniform allocation layers are {sorted(by_layer)}, expected 0..{N_LAYERS - 1}"
        )
    expected_shape = (N_KV_HEADS, int(ctx_len))
    for layer in range(N_LAYERS):
        bits = by_layer[layer]
        if not isinstance(bits, torch.Tensor) or tuple(bits.shape) != expected_shape:
            _fail(
                f"uniform layer {layer} shape is {getattr(bits, 'shape', None)}, "
                f"expected {expected_shape}"
            )
        if bits.dtype != torch.uint8:
            _fail(f"uniform layer {layer} dtype is {bits.dtype}, expected uint8")
        if not bool(torch.all(bits == BUDGET)):
            _fail(f"uniform layer {layer} contains a bit width other than {BUDGET}")
    observed = R8.allocation_id(by_layer)
    expected = expected_uniform_allocation_id(ctx_len)
    if observed != expected:
        _fail(f"uniform allocation ID {observed} differs from deterministic {expected}")
    return observed


def validate_cuda_placement(model: Any) -> list[str]:
    """Reject Accelerate CPU/disk offload before any qualification output."""
    raw_map = getattr(model, "hf_device_map", None)
    placements = sorted({str(value) for value in raw_map.values()}) if isinstance(raw_map, dict) else []
    bad_map = [value for value in placements if value.lower().startswith(("cpu", "disk"))]
    parameter_devices = sorted({str(parameter.device) for parameter in model.parameters()})
    bad_parameters = [
        value for value in parameter_devices
        if not (value == "cuda" or value.startswith("cuda:"))
    ]
    if bad_map or bad_parameters:
        _fail(
            "Qwen model is not wholly resident on CUDA: "
            f"hf_device_map={placements}, parameter_devices={parameter_devices}"
        )
    observed = placements or parameter_devices
    if not observed:
        _fail("Qwen model exposes no device placement")
    print(
        f"model placement: hf_device_map={placements or 'absent'} "
        f"parameter_devices={parameter_devices}",
        flush=True,
    )
    return observed


def _validate_config(path: str | Path) -> dict[str, Any]:
    config = run_h0.load_cfg(path, MODEL_TAG, [])
    expected = {
        "id": MODEL_ID,
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
    }
    observed = {
        "id": config.get("id"),
        "dtype": config.get("dtype"),
        "bit_list": list(config.get("bit_list", [])),
        "maxb": int(config.get("maxb", -1)),
        "rot_seed": int(config.get("rot_seed", -1)),
        "norm_correct": config.get("norm_correct"),
        "chunk": int(config.get("chunk", -1)),
    }
    if observed != expected:
        _fail(f"model execution config {observed} differs from frozen {expected}")
    if int(config.get("native_ctx", 0)) < CTX:
        _fail(f"model registry native context is shorter than frozen {CTX}")
    return config


def _common_row(
    item: Mapping[str, str],
    entry: Mapping[str, Any],
    *,
    manifest: Mapping[str, Any],
    manifest_file_hash: str,
    prompt_ids: Sequence[int],
) -> dict[str, Any]:
    return {
        "item_id": str(item["_id"]),
        "group_id": str(entry["group_id"]),
        "split": SPLIT,
        "domain": str(item["domain"]),
        "sub_domain": str(item["sub_domain"]),
        "difficulty": str(item["difficulty"]),
        "length": str(item["length"]),
        "context_hash": str(entry["context_hash"]),
        "question_hash": str(entry["question_hash"]),
        "prompt_token_hash": PD.token_hash(prompt_ids),
        "input_tokens": len(prompt_ids),
        "n_prompt_tokens": len(prompt_ids),
        "truncated": False,
        "dataset_sha256": LB.DATASET_SHA256,
        "manifest_content_sha256": str(manifest["content_sha256"]),
        "manifest_file_sha256": manifest_file_hash,
        "task_version": TASK_VERSION,
        "endpoint_version": ENDPOINT_VERSION,
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "tokenizer_revision": TOKENIZER_REVISION,
        "ctx": CTX,
        "window": WINDOW,
    }


def validate_output_rows(
    rows: Sequence[Mapping[str, Any]], item_ids: Sequence[str]
) -> None:
    expected_keys = {(item_id, arm) for item_id in item_ids for arm in ARMS}
    observed_keys: list[tuple[str, str]] = []
    for row in rows:
        if tuple(row) != PREDICTION_COLUMNS:
            _fail(
                "prediction row schema/order drifted: "
                f"got={tuple(row)}, expected={PREDICTION_COLUMNS}"
            )
        item_id, arm = str(row["item_id"]), str(row["arm"])
        observed_keys.append((item_id, arm))
        if arm not in ARMS:
            _fail(f"unknown qualification arm {arm!r}")
        expected_order = ARMS.index(arm)
        if int(row["arm_order"]) != expected_order:
            _fail(f"arm order drifted for {item_id}/{arm}")
        expected_budget = 0 if arm == "fp" else BUDGET
        if int(row["B"]) != expected_budget:
            _fail(f"budget drifted for {item_id}/{arm}")
        choice = str(row["forced_choice"])
        if choice not in "ABCD" or int(row["choice_index"]) != "ABCD".index(choice):
            _fail(f"invalid forced choice for {item_id}/{arm}")
        for field in ("choice_entropy", "choice_margin", "choice_max_probability"):
            if not math.isfinite(float(row[field])):
                _fail(f"non-finite {field} for {item_id}/{arm}")
        if not 0.0 <= float(row["choice_margin"]) <= 1.0:
            _fail(f"choice margin outside [0,1] for {item_id}/{arm}")
        if not 0.25 <= float(row["choice_max_probability"]) <= 1.0:
            _fail(f"choice maximum outside [0.25,1] for {item_id}/{arm}")
        if bool(row["truncated"]):
            _fail(f"qualification row {item_id}/{arm} is truncated")
        if int(row["input_tokens"]) > MAX_PROMPT_TOKENS:
            _fail(f"qualification row {item_id}/{arm} exceeds context bound")
        bits = float(row["bits_per_token"])
        evict = float(row["evict_frac"])
        if arm == "fp":
            if bits != 16.0 or evict != 0.0:
                _fail(f"FP audit drifted for {item_id}")
            if str(row["allocation_id"]) != R8.allocation_id(None):
                _fail(f"FP allocation identity drifted for {item_id}")
        else:
            if not math.isclose(bits, float(BUDGET), rel_tol=0.0, abs_tol=1e-7):
                _fail(f"uniform bit audit is {bits}, expected {BUDGET}")
            if not math.isclose(evict, 0.0, rel_tol=0.0, abs_tol=1e-12):
                _fail("uniform qualification unexpectedly evicted tokens")
        if int(row["observed_queries"]) != WINDOW:
            _fail(f"observed query window drifted for {item_id}/{arm}")
    if (
        len(observed_keys) != len(expected_keys)
        or set(observed_keys) != expected_keys
        or len(observed_keys) != len(set(observed_keys))
    ):
        _fail("prediction keys differ from exact qualification IDs x arms")
    for column in PREDICTION_COLUMNS:
        lowered = column.lower()
        if any(fragment in lowered for fragment in FORBIDDEN_FRAGMENTS) and column not in {
            "forced_choice", "choice_index", "choice_entropy", "choice_margin",
            "choice_max_probability", "endpoint_version", "norm_correct",
        }:
            _fail(f"prediction schema contains forbidden column {column!r}")


def _sidecar(
    *,
    manifest: Mapping[str, Any],
    manifest_path: Path,
    manifest_file_hash: str,
    source_manifest_path: Path,
    frame: pd.DataFrame,
    parquet_path: Path,
    elapsed_seconds: float,
    device_placements: Sequence[str],
    config_path: Path,
    source_hashes: Mapping[str, str],
    snapshot_attestation: Mapping[str, Any],
) -> dict[str, Any]:
    import tokenizers
    import transformers

    qualification = [
        row for row in manifest["examples"] if row["split"] == SPLIT
    ]
    source_hashes = dict(source_hashes)
    runner_key = _relative_source(__file__)
    return {
        "artifact": "qwen_forced_choice_qualification",
        "runner_version": RUNNER_VERSION,
        "protocol_version": PROTOCOL_VERSION,
        "task_version": TASK_VERSION,
        "endpoint_version": ENDPOINT_VERSION,
        "dataset_repo": LB.DATASET_REPO,
        "dataset_revision": LB.DATASET_REVISION,
        "dataset_sha256": LB.DATASET_SHA256,
        "dataset_bytes": LB.DATASET_BYTES,
        "official_code_repo": LB.OFFICIAL_CODE_REPO,
        "official_code_revision": LB.OFFICIAL_CODE_REVISION,
        "official_prompt_sha256": LB.OFFICIAL_PROMPT_SHA256,
        "source_manifest": QA.SOURCE_MANIFEST_ID,
        "source_manifest_version": QA.SOURCE_MANIFEST_VERSION,
        "source_manifest_content_sha256": QA.SOURCE_MANIFEST_CONTENT_SHA256,
        "source_manifest_file_sha256": QA.SOURCE_MANIFEST_FILE_SHA256,
        "manifest": str(manifest_path),
        "manifest_version": QA.MANIFEST_VERSION,
        "manifest_content_sha256": str(manifest["content_sha256"]),
        "manifest_file_sha256": manifest_file_hash,
        "split": SPLIT,
        "split_count": EXPECTED_ITEMS,
        "split_components": EXPECTED_COMPONENTS,
        "split_ids_sha256": QA.EXPECTED_SPLITS[SPLIT]["id_sha256"],
        "split_id_token_sha256": QA.EXPECTED_SPLITS[SPLIT]["id_token_sha256"],
        "split_id_prompt_sha256": str(manifest["split_counts"][SPLIT]["id_prompt_sha256"]),
        "component_sampling": "uniform_components_with_replacement_carry_all_rows",
        "model": MODEL_TAG,
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "tokenizer_revision": TOKENIZER_REVISION,
        "chat_template_sha256": QA.CHAT_TEMPLATE_SHA256,
        "add_generation_prompt": True,
        "enable_thinking": False,
        "transformers_version": transformers.__version__,
        "tokenizers_version": tokenizers.__version__,
        "torch_version": torch.__version__,
        "snapshot_revision": snapshot_attestation["revision"],
        "snapshot_file_count": snapshot_attestation["file_count"],
        "snapshot_inventory_sha256": snapshot_attestation["inventory_sha256"],
        "snapshot_metadata_sha256": dict(snapshot_attestation["metadata_sha256"]),
        "ctx": CTX,
        "max_prompt_tokens": MAX_PROMPT_TOKENS,
        "window": WINDOW,
        "budget": float(BUDGET),
        "cascade_bits": CASCADE_BITS,
        "dtype": DTYPE_NAME,
        "bit_list": list(BIT_LIST),
        "maxb": MAXB,
        "rot_seed": ROT_SEED,
        "norm_correct": NORM_CORRECT,
        "chunk": CHUNK,
        "n_layers": N_LAYERS,
        "n_attention_heads": N_ATTENTION_HEADS,
        "n_kv_heads": N_KV_HEADS,
        "head_dim": HEAD_DIM,
        "uniform_allocation_contract": "48_layers_x_4_kv_x_ctx_len_all_uint8_2",
        "attn_impl": C.IMPL,
        "device_placements": list(device_placements),
        "decode": "forced_choice_teacher_forced_argmax",
        "temperature": 1.0,
        "compress_at": "official_chat_prompt_end",
        "arms": list(ARMS),
        "allocation_id_algorithm": R8.ALLOCATION_ID_ALGORITHM,
        "scaffold_token_ids": list(QA.SCAFFOLD_TOKEN_IDS),
        "scaffold_token_hash": PD.token_hash(QA.SCAFFOLD_TOKEN_IDS),
        "choice_branch_ids": dict(QA.CHOICE_BRANCH_IDS),
        "choice_branch_ids_hash": PD.token_hash(
            [QA.CHOICE_BRANCH_IDS[choice] for choice in "ABCD"]
        ),
        "choice_position": len(QA.SCAFFOLD_TOKEN_IDS),
        "no_truncation": True,
        "no_free_generation": True,
        "no_raw_logits": True,
        "no_labels": True,
        "executed_source_sha256": source_hashes,
        "runner_source": runner_key,
        "runner_source_sha256": source_hashes[runner_key],
        "parquet": parquet_path.name,
        "parquet_sha256": LB.sha256_file(parquet_path),
        "rows": len(frame),
        "expected_rows": EXPECTED_ITEMS * len(ARMS),
        "row_key": ["item_id", "arm"],
        "elapsed_seconds": float(elapsed_seconds),
    }


def run(args: argparse.Namespace) -> Path:
    config_path = Path(args.config).resolve()
    config = _validate_config(config_path)
    model_source, model_kwargs = _model_source(args.model_source)
    captured_source_hashes = executed_source_hashes(config_path)
    snapshot_attestation = QA.authenticate_snapshot(model_source)
    tokenizer = QA.load_tokenizer(model_source)
    manifest_path = Path(args.manifest).resolve()
    source_manifest_path = Path(args.source_manifest).resolve()
    manifest, manifest_file_hash = QA.authenticate_manifest(
        manifest_path,
        dataset_path=args.dataset,
        source_manifest_path=source_manifest_path,
        tokenizer=tokenizer,
    )
    data = LB.load_dataset(args.dataset, authenticate=True)
    by_id = LB.index_by_id(data)
    entries = [
        row for row in manifest["examples"] if row["split"] == SPLIT
    ]
    if len(entries) != EXPECTED_ITEMS:
        _fail(f"qualification has {len(entries)} items, expected {EXPECTED_ITEMS}")
    if len({str(row["group_id"]) for row in entries}) != EXPECTED_COMPONENTS:
        _fail("qualification component count drifted")

    from transformers import AutoModelForCausalLM

    C.install()
    model = AutoModelForCausalLM.from_pretrained(
        model_source,
        dtype=getattr(torch, DTYPE_NAME),
        device_map=config.get("device_map", "auto"),
        attn_implementation=C.IMPL,
        trust_remote_code=True,
        **model_kwargs,
    ).eval()
    device_placements = validate_cuda_placement(model)
    device = next(model.parameters()).device
    cf = model.config
    architecture = {
        "n_layers": int(cf.num_hidden_layers),
        "n_attention_heads": int(cf.num_attention_heads),
        "n_kv_heads": int(cf.num_key_value_heads),
        "head_dim": int(getattr(cf, "head_dim", None) or cf.hidden_size // cf.num_attention_heads),
    }
    expected_architecture = {
        "n_layers": N_LAYERS, "n_attention_heads": N_ATTENTION_HEADS,
        "n_kv_heads": N_KV_HEADS, "head_dim": HEAD_DIM,
    }
    if architecture != expected_architecture:
        _fail(f"Qwen attention architecture {architecture} differs from {expected_architecture}")
    n_layers = architecture["n_layers"]
    head_dim = architecture["head_dim"]
    rotation = quant.random_rotation(
        head_dim, device, torch.float32, seed=ROT_SEED
    )
    if not router.is_width(BUDGET, MAXB, list(BIT_LIST)):
        _fail(f"uniform B={BUDGET} is absent from bit list {BIT_LIST}")
    prefix_tokens, branch_ids = FC.canonical_choice_contract(
        tokenizer,
        expected_prefix=QA.SCAFFOLD_TOKEN_IDS,
        expected_branches=QA.CHOICE_BRANCH_IDS,
    )

    output_rows: list[dict[str, Any]] = []
    start_all = time.time()
    print(
        f"V6 Qwen qualification: items={len(entries)} arms={list(ARMS)} "
        f"B={BUDGET} ctx={CTX} W={WINDOW}; gold unused, labels absent from artifacts",
        flush=True,
    )
    for index, entry in enumerate(entries):
        item_id = str(entry["id"])
        item = by_id[item_id]
        prompt_ids = QA.qwen_input_ids(tokenizer, item)
        if len(prompt_ids) != int(entry["input_tokens"]):
            _fail(f"{item_id}: runtime prompt token count differs from manifest")
        if PD.token_hash(prompt_ids) != str(entry["prompt_token_hash"]):
            _fail(f"{item_id}: runtime prompt token hash differs from manifest")
        if len(prompt_ids) > MAX_PROMPT_TOKENS:
            _fail(f"{item_id}: prompt plus response scaffold exceeds CTX={CTX}")

        ids = torch.tensor([prompt_ids], dtype=torch.long, device=device)
        t0 = time.time()
        past, _ = R8.prefill(model, ids, WINDOW, CHUNK, h2o=False)
        cache_length = C.cache_len(past)
        prefill_seconds = time.time() - t0
        if cache_length != len(prompt_ids) - 1:
            _fail(f"{item_id}: prefill boundary is not prompt length minus one")
        if cache_length - C.STATE.ctx_len != WINDOW:
            _fail(f"{item_id}: protected observation window drifted")

        bits, errors, route_log, answer_mass = R8.precompute(
            past,
            cache_length,
            {"uniform"},
            [],
            [BUDGET],
            rotation,
            NORM_CORRECT,
            MAXB,
            list(BIT_LIST),
            n_layers,
            cascade_bits=CASCADE_BITS,
            need_err=False,
            routes={},
            theta=1.0,
            ans_mask=None,
            bls={},
            wo=None,
        )
        if errors or route_log or answer_mass:
            _fail(f"{item_id}: qualification precompute emitted oracle data")
        if set(bits) != {("uniform", BUDGET)}:
            _fail(f"{item_id}: uniform allocation keys drifted: {set(bits)}")
        uniform_allocation_id = validate_uniform_allocation(
            bits[("uniform", BUDGET)], ctx_len=int(C.STATE.ctx_len)
        )
        allocations = {
            "fp": R8.allocation_id(None),
            "uniform": uniform_allocation_id,
        }
        common = _common_row(
            item,
            entry,
            manifest=manifest,
            manifest_file_hash=manifest_file_hash,
            prompt_ids=prompt_ids,
        )
        for arm_order, arm in enumerate(ARMS):
            allocation = None if arm == "fp" else bits[("uniform", BUDGET)]
            endpoint_logits, audit = FC.policy_choice_logits(
                model,
                past,
                last_prompt_token=prompt_ids[-1],
                prefix_tokens=prefix_tokens,
                branch_ids=branch_ids,
                bits_by_layer=allocation,
                rotation=rotation,
                norm_correct=NORM_CORRECT,
                cache_length=cache_length,
                device=device,
            )
            summary = FC.choice_summary(endpoint_logits)
            output_rows.append(
                {
                    **common,
                    "B": 0 if arm == "fp" else BUDGET,
                    "arm": arm,
                    "arm_order": arm_order,
                    **summary,
                    "scaffold_token_hash": PD.token_hash(prefix_tokens),
                    "choice_branch_ids_hash": PD.token_hash(
                        [branch_ids[choice] for choice in "ABCD"]
                    ),
                    **audit,
                    "allocation_id": allocations[arm],
                    "ctx_len": int(C.STATE.ctx_len),
                    "observed_queries": int(cache_length - C.STATE.ctx_len),
                    "maxb": MAXB,
                    "rot_seed": ROT_SEED,
                    "norm_correct": NORM_CORRECT,
                }
            )
            del endpoint_logits
        print(
            f"  {index + 1:2d}/{len(entries)} {item_id} "
            f"n={len(prompt_ids):,} prefill={prefill_seconds:.1f}s",
            flush=True,
        )
        del past, bits
        if device.type == "cuda":
            torch.cuda.empty_cache()

    elapsed = time.time() - start_all
    item_ids = [str(entry["id"]) for entry in entries]
    validate_output_rows(output_rows, item_ids)
    frame = pd.DataFrame(output_rows, columns=PREDICTION_COLUMNS)
    output_dir = Path(args.out_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    parquet_path = output_dir / f"{ARTIFACT_BASENAME}.parquet"
    sidecar_path = output_dir / f"{ARTIFACT_BASENAME}.json"
    if parquet_path.exists() or sidecar_path.exists():
        _fail(f"refusing to overwrite existing qualification artifact in {output_dir}")
    final_source_hashes = executed_source_hashes(config_path)
    if final_source_hashes != captured_source_hashes:
        _fail("executed source files changed between pre-model capture and artifact write")
    final_snapshot_attestation = QA.authenticate_snapshot(model_source)
    if final_snapshot_attestation != snapshot_attestation:
        _fail("local model snapshot changed during qualification execution")
    frame.to_parquet(parquet_path, index=False)
    sidecar = _sidecar(
        manifest=manifest,
        manifest_path=manifest_path,
        manifest_file_hash=manifest_file_hash,
        source_manifest_path=source_manifest_path,
        frame=frame,
        parquet_path=parquet_path,
        elapsed_seconds=elapsed,
        device_placements=device_placements,
        config_path=config_path,
        source_hashes=captured_source_hashes,
        snapshot_attestation=snapshot_attestation,
    )
    _write_json(sidecar_path, sidecar)
    print(f"wrote {parquet_path} ({len(frame)} rows)")
    print(f"wrote {sidecar_path}")
    return parquet_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--source-manifest", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--config", default=str(HERE / "models.yaml"))
    parser.add_argument("--model-source", required=True)
    parser.add_argument("--out-dir", required=True)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        run(args)
    except (QwenQualificationRunnerError, QA.QwenManifestError, OSError, ValueError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
