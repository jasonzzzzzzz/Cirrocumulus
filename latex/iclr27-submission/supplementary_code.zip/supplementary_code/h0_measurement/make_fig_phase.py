#!/usr/bin/env python3
"""
make_fig_phase.py -- docs/fig5_phase.png, the headline figure, from valid data.

Reproducible companion to the pitch/proposal. Regenerate after any campaign:

  python h0_measurement/make_fig_phase.py \
      "h0_measurement/results/job199*/*.parquet" -o docs/fig5_phase.png

Four panels:

  0  ROUTED GAIN vs dead-2-bit-tier fraction. The phase axis against the robust
     statistic. dead-2 is derived (tau^2*c_b vs the derived eviction cost c0=1)
     and contains no L. Reported with model identity PARTIALLED OUT, because 24
     configurations nested in 6 models are not 24 independent points -- and the
     within-model relationship is stronger than the pooled one. phi=n95/L inset
     for contrast: still null-to-wrong-signed.
  1  BAND FRACTION vs dead-2. The same story in the thresholded statistic, kept
     because the GO/STOP verdicts are defined on it, but demoted: it is a count
     at a 2x boundary and a 1.02-1.41x change in corner error moves it 6-29 pts.
     Both panels plot the oracle corner hollow for contrast.
  2  the context sweep, against the real evictor (the verdict corner).
  3  the theory's FORWARD prediction: the linearized cost model against the
     exactly-recomputed gain. This replaced a tau/ln2 panel that plotted x
     against x -- std_i(log2 a_i) = tau/ln2 identically; see
     sievelib/alloc.py and tests/test_units.py::test_ladder_identity.

THE VERDICT SERIES IS THE SYMMETRIC CELL (--target sym, the default since v9):
gain_pp3_accum, where the interior AND the corner both score on lagged attention.
Two earlier targets are kept for the contrast markers and for reproducing older
figures: `e2` (gain_best_practical3 -- corner demoted only, the v8 headline) and
`oracle` (gain_best3). A file may only contribute `sym` if its sidecar carries
"interior_unseen_policy": "floor_maxb"; and only cells whose corner set matches
--evictors are pooled, so the five-corner R7 blocks do not mix with the accum
grid the boundary was fitted on. Rows where only SOME evictors scored are
dropped first (report.drop_partial_corners) -- on the first decode step only
`recency` has a score, so min-over-corners silently collapses onto the weakest
one and the band reads ~29 points high.
"""
from __future__ import annotations
import argparse, glob, os, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

F_STOP, F_GO, BAND_MIN = 15.0, 35.0, 2.0
COL = {"llama31-8b": "#1d6f80", "llama33-70b": "#12414f", "mistral-7b": "#1f6b52",
       "qwen15-moe-a2.7b": "#a8611f", "qwen3-8b": "#7c3aed",
       "qwen3-30b-a3b-2507": "#c2334d"}


def fixed_interior(parquet):
    """The symmetric columns are only valid with the floor policy in place
    (bugs/2 R3-report section 5); an unfixed run must not enter the grid."""
    import json
    try:
        with open(parquet[: -len(".parquet")] + ".json") as fh:
            return json.load(fh).get("interior_unseen_policy") == "floor_maxb"
    except (OSError, ValueError):
        return False


def debug_tags():
    """Debug-tier models (the cheap controls) are not phase-diagram points."""
    import yaml
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "models.yaml")) as fh:
        cfg = yaml.safe_load(fh)
    return {m["tag"] for m in cfg["models"] if m.get("tier") == "debug"}


def collect(pats, score="accum", evictors="oracle,accum", include_debug=False):
    """One record per (model, ctx), pooling ROWS across runs.

    Replicates -- two runs of the same cell, e.g. R7's disjoint prompt blocks --
    are one phase-diagram point. Their ROWS are concatenated before the per-head
    median is taken, which is how bugs/6's boundary.py pools them; averaging the
    two runs' band fractions instead gives a slightly different number, because
    the band is a count of per-head medians and the median is not linear."""
    from report import drop_partial_corners, cfg_value
    sym_col = f"gain_pp3_{score}"
    skip_models = set() if include_debug else debug_tags()
    keep = ["layer", "head", "gain_best3", "gain_best_practical3", sym_col,
            "evict_beats_b2", "tau", "ladder_bits", "eff_frac", "lin_ratio3"]
    cells, n_blank, skipped, n_runs = {}, 0, [], {}
    for pat in pats:
        for f in sorted(glob.glob(pat)):
            d = pd.read_parquet(f)
            if "gain_best3" not in d:
                continue
            if "quantized" in d:
                d = d[d.quantized]
            d, nb = drop_partial_corners(d)
            n_blank += nb
            if sym_col in d and not fixed_interior(f):
                d = d.drop(columns=[sym_col])
                skipped.append(f"{os.path.basename(os.path.dirname(f))}: no floor_maxb marker")
            # COMPLETE-CORNER ROWS ONLY, as bugs/2 R3-report section 1 and bugs/6
            # define the population: a row where the practical aggregate is null
            # had only some evictors scored (step 0 has no lagged history), and
            # keeping it shifts dead-2 by ~1 point.
            pr_col = "gain_best_practical3"
            if pr_col in d and d[pr_col].notna().any():
                d = d[d[pr_col].notna()]
            for (m, c), g in d.groupby(["model", "ctx"]):
                if m in skip_models:
                    continue
                ev = cfg_value(g, "evictors")
                if evictors != "any" and ev != evictors:
                    skipped.append(f"{os.path.basename(os.path.dirname(f))}: {m}@{int(c)} "
                                   f"corner set {ev!r} != {evictors!r}")
                    continue
                cells.setdefault((m, int(c)), []).append(
                    g[[k for k in keep if k in g.columns]].copy())
                n_runs[(m, int(c))] = n_runs.get((m, int(c)), 0) + 1
    if n_blank:
        print(f"  dropped the practical aggregate on {n_blank:,} partial-corner row(s)")
    for line in dict.fromkeys(skipped):
        print(f"  skipped {line}")

    rows = []
    for (m, c), parts in cells.items():
        ph = pd.concat(parts, ignore_index=True).groupby(["layer", "head"]).median(
            numeric_only=True)
        gb = ph["gain_best3"].dropna()
        if not len(gb):
            continue
        pr = (ph["gain_best_practical3"].dropna()
              if "gain_best_practical3" in ph else pd.Series(dtype=float))
        sy = ph[sym_col].dropna() if sym_col in ph else pd.Series(dtype=float)
        band = lambda v: 100 * (v >= BAND_MIN).mean() if len(v) else np.nan
        med = lambda v: float(v.median()) if len(v) else np.nan
        routed = lambda v: (float(np.exp(np.log(np.maximum(v, 1.0)).mean()))
                            if len(v) else np.nan)
        if n_runs[(m, c)] > 1:
            print(f"  pooled {n_runs[(m, c)]} runs of {m}@{c:,}")
        rows.append(dict(
            model=m, ctx=c, runs=n_runs[(m, c)],
            band_or=band(gb), band_pr=band(pr), band_sy=band(sy),
            gain_or=med(gb), gain_pr=med(pr), gain_sy=med(sy),
            # routed gain = geometric mean of max(gain,1): a magnitude, not a
            # count, so it does not inherit the band's fragility at the 2x line
            routed_or=routed(gb), routed_pr=routed(pr), routed_sy=routed(sy),
            dead2=100 * ph["evict_beats_b2"].mean(),
            tau=ph["tau"].median(), lad=ph["ladder_bits"].median(),
            phi=100 * ph["eff_frac"].median(),
            lin=(float(ph["lin_ratio3"].median()) if "lin_ratio3" in ph else np.nan)))
    return pd.DataFrame(rows).reset_index(drop=True)


def pick_target(t, target):
    """Set the VERDICT series (`band`, `gain`, `routed`) and the CONTRAST series
    plotted hollow (`band_c`, `routed_c`) from --target."""
    if target == "sym":
        t = t[t.band_sy.notna()].reset_index(drop=True)
        t["band"], t["gain"], t["routed"] = t.band_sy, t.gain_sy, t.routed_sy
        t["band_c"], t["routed_c"] = t.band_or, t.routed_or      # all-oracle contrast
        t["contrast"] = "all-oracle"
    elif target == "e2":
        t = t[t.band_pr.notna()].reset_index(drop=True)
        t["band"], t["gain"], t["routed"] = t.band_pr, t.gain_pr, t.routed_pr
        t["band_c"], t["routed_c"] = t.band_or, t.routed_or
        t["contrast"] = "all-oracle"
    else:
        t["band"], t["gain"], t["routed"] = t.band_or, t.gain_or, t.routed_or
        t["band_c"], t["routed_c"] = np.nan, np.nan
        t["contrast"] = ""
    t["has_c"] = t.band_c.notna()
    return t


def spearman(a, b):
    return float(np.corrcoef(pd.Series(a).rank(), pd.Series(b).rank())[0, 1])


def partial_spearman(x, y, group):
    """Spearman with `group` residualised out of BOTH ranks.

    24 configurations nested in 6 models are not 24 independent points, and a
    reviewer will say so. This answers it: regress each rank on model one-hots
    and correlate the residuals, i.e. the purely WITHIN-model relationship.
    """
    r = lambda v: pd.Series(v).rank().values
    X = pd.get_dummies(pd.Series(list(group)), drop_first=True).astype(float).values
    X = np.column_stack([np.ones(len(X)), X])
    res = []
    for v in (r(x), r(y)):
        beta, *_ = np.linalg.lstsq(X, v, rcond=None)
        res.append(v - X @ beta)
    return float(np.corrcoef(res[0], res[1])[0, 1])


def crossings(t):
    """Where the band crosses GO and STOP, as an ISOTONIC (monotone) crossing in
    dead-2 -- the same estimator bugs/6 uses. A parametric fit is the wrong tool
    here: it can leave the bracket the data actually supports."""
    out = {}
    d = t.sort_values("dead2")
    x, y = d.dead2.to_numpy(float), d.band.to_numpy(float)
    # pool-adjacent-violators for a NON-INCREASING fit
    yy, w = list(y), [1.0] * len(y)
    i = 0
    while i < len(yy) - 1:
        if yy[i] < yy[i + 1] - 1e-12:
            tot = w[i] + w[i + 1]
            yy[i] = (yy[i] * w[i] + yy[i + 1] * w[i + 1]) / tot
            w[i] = tot
            del yy[i + 1], w[i + 1]
            i = max(i - 1, 0)
        else:
            i += 1
    fit, k = [], 0
    for v, ww in zip(yy, w):
        fit += [v] * int(round(ww))
        k += int(round(ww))
    fit = np.array(fit[: len(x)])
    for name, line in (("GO", F_GO), ("STOP", F_STOP)):
        hit = np.where(fit <= line)[0]
        if not len(hit) or hit[0] == 0:
            out[name] = float("nan"); continue
        j = hit[0]
        x0, x1_, y0, y1_ = x[j - 1], x[j], fit[j - 1], fit[j]
        out[name] = float(x0 if y0 == y1_ else x0 + (y0 - line) * (x1_ - x0) / (y0 - y1_))
    return out


def disagreement(t, max_dx=2.0):
    """R6's architecture-scatter finding, drawn: two cells from DIFFERENT models
    at nearly the same dead-2 whose bands disagree. Pairs that STRADDLE a verdict
    line are preferred, because "same phase variable, different verdict" is the
    claim; among those, the closest in dead-2 wins."""
    best, rows = None, list(t.itertuples())
    for i, r1 in enumerate(rows):
        for r2 in rows[i + 1:]:
            if r1.model == r2.model:
                continue
            dx, dy = abs(r1.dead2 - r2.dead2), abs(r1.band - r2.band)
            if dx > max_dx or dy < 5.0:
                continue
            lo, hi = sorted((r1.band, r2.band))
            straddles = any(lo < line < hi for line in (F_STOP, F_GO))
            score = (1 if straddles else 0, -dx)
            if best is None or score > best[0]:
                best = (score, (r1.dead2, r1.band, f"{r1.model}@{r1.ctx // 1024}k"),
                        (r2.dead2, r2.band, f"{r2.model}@{r2.ctx // 1024}k"))
    return None if best is None else (best[1], best[2])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("-o", "--out", default="docs/fig5_phase.png")
    ap.add_argument("--target", default="sym", choices=("sym", "e2", "oracle"),
                    help="the VERDICT series: sym = interior AND corner lagged "
                         "(the v9 headline), e2 = corner demoted only (v8), oracle")
    ap.add_argument("--score", default="accum",
                    help="the lagged score behind the symmetric column gain_pp3_<score>")
    ap.add_argument("--evictors", default="oracle,accum",
                    help="pool only cells whose corner set is this ('any' to pool all)")
    ap.add_argument("--include-debug", action="store_true",
                    help="keep debug-tier models (they are not phase-diagram points)")
    a = ap.parse_args()
    t = pick_target(collect(a.inputs, a.score, a.evictors, a.include_debug), a.target)
    if t.empty:
        raise SystemExit("no measurement parquet matched")
    fig, ax = plt.subplots(1, 4, figsize=(19.5, 4.6))

    # ---- PANEL 0: the phase axis against the ROBUST statistic.
    # Band fraction is a thresholded count, and we report ourselves that a
    # 1.02-1.41x change in corner error moves it 6-29 points because the per-head
    # gain distribution is dense at the 2x boundary. So the primary panel uses
    # ROUTED GAIN -- geometric mean of max(gain,1), the paper's own magnitude
    # statistic and not a count. The thresholded version is panel 1, demoted.
    pr = t[t.has_c]
    lbl = {"sym": "symmetric: interior AND corner lagged",
           "e2": "corner demoted only", "oracle": "all-oracle"}[a.target]
    for m, g in t.groupby("model"):
        ax[0].scatter(g.dead2, g.routed, s=26 + 34 * np.log2(g.ctx / 4096),
                      color=COL.get(m, "#666"), label=m, zorder=3,
                      edgecolor="white", linewidth=.6)
    if len(pr):
        ax[0].scatter(pr.dead2, pr.routed_c, s=26 + 34 * np.log2(pr.ctx / 4096),
                      facecolor="none", edgecolor="#8a97a0", linewidth=.9,
                      zorder=2, label=f"same points, {pr.contrast.iloc[0]}")
        for _, r in pr.iterrows():
            ax[0].plot([r.dead2, r.dead2], [r.routed_c, r.routed],
                       color="#8a97a0", lw=.7, alpha=.55, zorder=1)
    ax[0].axhline(1.0, color="#c2334d", ls=":", lw=1.2)
    ax[0].text(.99, .02, "no gain", fontsize=7, color="#c2334d", ha="right",
               va="bottom", transform=ax[0].transAxes)
    ax[0].set_xlabel("dead 2-bit tier: heads with $\\tau^2 c_2 > c_0{=}1$   (%)")
    ax[0].set_ylabel("routed gain  (geo-mean of max(gain,1))")
    # The partial correlation is the headline number here: 24 configs nested in
    # 6 models are not 24 independent points, and residualising model identity
    # makes the relationship STRONGER, not weaker.
    pp = partial_spearman(t.dead2, t.routed, t.model)
    wm = [spearman(g.dead2, g.routed) for _, g in t.groupby("model") if len(g) >= 3]
    ax[0].set_title(f"The phase axis, against the robust statistic\n{lbl}\n"
                    f"Spearman {spearman(t.dead2, t.routed):+.3f} pooled, "
                    f"{pp:+.3f} with model identity partialled out\n"
                    f"within-model: {min(wm):+.2f} to {max(wm):+.2f} "
                    f"across {len(wm)} models", fontsize=8.6)
    ax[0].legend(fontsize=6.2, loc="upper right", framealpha=.9)
    ins = ax[0].inset_axes([.13, .07, .25, .22])
    ins.scatter(t.phi, t.routed, s=6, color="#9b2c3a")
    ins.set_title(f"retired: $\\varphi=n_{{95}}/L$   {spearman(t.phi, t.routed):+.2f}",
                  fontsize=5.8, pad=2)
    ins.tick_params(labelsize=4.5)

    # ---- PANEL 1: the same story in the FRAGILE statistic, kept because the
    # GO/STOP verdicts are defined on it and the oracle->practical shift is what
    # removed every STOP.
    for m, g in t.groupby("model"):
        ax[1].scatter(g.dead2, g.band, s=26 + 34 * np.log2(g.ctx / 4096),
                      color=COL.get(m, "#666"), zorder=3,
                      edgecolor="white", linewidth=.6)
    if len(pr):
        ax[1].scatter(pr.dead2, pr.band_c, s=26 + 34 * np.log2(pr.ctx / 4096),
                      facecolor="none", edgecolor="#8a97a0", linewidth=.9, zorder=2)
        for _, r in pr.iterrows():
            ax[1].plot([r.dead2, r.dead2], [r.band_c, r.band],
                       color="#8a97a0", lw=.7, alpha=.55, zorder=1)
    # THE ARCHITECTURE RESULT (R6): the pooled crossings, and the pair of cells
    # that disagree at the same dead-2. Drawn, because "pinned per model, not
    # universally" is the claim this panel now has to carry.
    cross = crossings(t)
    for line, d, col in ((F_GO, cross["GO"], "#1f6b52"), (F_STOP, cross["STOP"], "#c2334d")):
        if np.isfinite(d):
            ax[1].plot([d], [line], marker="v", color=col, ms=7, zorder=5,
                       markeredgecolor="white", markeredgewidth=.6)
            ax[1].annotate(f"{d:.1f}%", (d, line), textcoords="offset points",
                           xytext=(4, 6), fontsize=6.6, color=col)
    worst = disagreement(t)
    if worst is not None:
        (x1, y1, n1), (x2, y2, n2) = worst
        ax[1].annotate("", xy=(x2, y2), xytext=(x1, y1),
                       arrowprops=dict(arrowstyle="<->", color="#a8611f", lw=1.3))
        # the label goes in clear space (upper right), with a leader to the pair,
        # so it never collides with the GO/STOP rules
        ax[1].annotate(f"{abs(y1 - y2):.0f} band points across {abs(x1 - x2):.1f} pts of dead-2\n"
                       f"{n1} ({y1:.1f}%)  vs  {n2} ({y2:.1f}%)\n"
                       f"same phase variable, different verdict",
                       xy=((x1 + x2) / 2, (y1 + y2) / 2), xycoords="data",
                       xytext=(.44, .93), textcoords="axes fraction",
                       fontsize=6.6, color="#a8611f", va="top", ha="left",
                       arrowprops=dict(arrowstyle="-", color="#a8611f", lw=.7,
                                       alpha=.75, shrinkB=6),
                       bbox=dict(boxstyle="round,pad=.28", fc="#fdf3e7",
                                 ec="#a8611f", lw=.5, alpha=.95))
    ax[1].axhspan(F_GO, 100, color="#1f6b52", alpha=.07, zorder=0)
    ax[1].axhspan(0, F_STOP, color="#c2334d", alpha=.07, zorder=0)
    ax[1].axhline(F_GO, color="#1f6b52", ls="--", lw=1)
    ax[1].axhline(F_STOP, color="#c2334d", ls="--", lw=1)
    ax[1].text(.99, F_GO + 2, "GO", fontsize=8, color="#1f6b52", ha="right",
               transform=ax[1].get_yaxis_transform())
    ax[1].text(.99, F_STOP - 6, "STOP", fontsize=8, color="#c2334d", ha="right",
               transform=ax[1].get_yaxis_transform())
    ax[1].set_xlabel("dead 2-bit tier   (%)")
    ax[1].set_ylabel("% heads in band (thresholded at 2$\\times$)")
    ax[1].set_title("Secondary: the thresholded count\n"
                    f"Spearman {spearman(t.dead2, t.band):+.3f}; crossings GO "
                    f"{cross['GO']:.1f}% / STOP {cross['STOP']:.1f}% dead-2\n"
                    "PINNED PER MODEL, NOT UNIVERSALLY (arrow: two models, same dead-2)",
                    fontsize=8.6)

    # ---- CENTRE: context sweep
    for m, g in t.groupby("model"):
        if len(g) < 3:
            continue
        g = g.sort_values("ctx")
        ax[2].plot(g.ctx / 1024, g.band, "o-", color=COL.get(m, "#666"), lw=2,
                   label=f"{m}", zorder=3)
        if g.has_c.all():
            ax[2].plot(g.ctx / 1024, g.band_c, "o:", color=COL.get(m, "#666"),
                       lw=1, ms=3, alpha=.45, zorder=2)
    ax[2].axhspan(F_GO, 100, color="#1f6b52", alpha=.07)
    ax[2].axhspan(0, F_STOP, color="#c2334d", alpha=.07)
    ax[2].set_xscale("log", base=2)
    ax[2].set_xlabel("context length (k tokens)")
    ax[2].set_ylabel("% heads in band")
    slopes = []
    for m, g in t.groupby("model"):
        if len(g) >= 3:
            g = g.sort_values("ctx")
            slopes.append(np.polyfit(np.log2(g.ctx), g.band, 1)[0])
    ax[2].set_title("Context length is a phase variable\n"
                    f"solid = {lbl}, dotted = contrast\n"
                    f"{min(slopes):+.1f} to {max(slopes):+.1f} band-pts per ctx doubling",
                    fontsize=8.6)
    ax[2].legend(fontsize=6.6, loc="upper right")

    # ---- RIGHT: the theory's only forward prediction
    #
    # This panel used to plot tau/ln2 against the measured ladder width. That is
    # x against x: log2 a_i = s_i/ln2 - log2 Z with Z constant in i, so
    # std_i(log2 a_i) = tau/ln2 IDENTICALLY (8e-16 per head over all 24 configs,
    # pinned by tests/test_units.py::test_ladder_identity). The only empirical
    # content was the value term, which we separately measure at <=0.035 bits, so
    # the advertised "~1% agreement" measured a term we call negligible.
    #
    # Replaced with the real thing: the LINEARIZED COST MODEL against the
    # EXACTLY-RECOMPUTED gain. lin_ratio = predicted/measured, so predicted =
    # lin_ratio * measured, and nothing here is algebraically forced -- the cost
    # model could have been off by 5x, as it was before the probe fix.
    if "lin" in t and t.lin.notna().any():
        u = t.dropna(subset=["lin", "gain"])
        ax[3].scatter(u.gain, u.lin * u.gain, s=30,
                      color=[COL.get(m, "#666") for m in u.model],
                      zorder=3, edgecolor="white", linewidth=.6)
        lo = float(min(u.gain.min(), (u.lin * u.gain).min())) * .9
        hi = float(max(u.gain.max(), (u.lin * u.gain).max())) * 1.1
        ax[3].plot([lo, hi], [lo, hi], ls="--", color="#c2334d", lw=1.3,
                   label="exact agreement")
        # Band = the MEASURED envelope of the ratio, not a round number chosen to
        # contain it. If a future campaign widens the spread, the band widens too.
        rlo, rhi = float(u.lin.min()), float(u.lin.max())
        ax[3].fill_between([lo, hi], [lo * rlo, hi * rlo], [lo * rhi, hi * rhi],
                           color="#4ea8b8", alpha=.13, lw=0,
                           label=f"measured envelope {rlo:.2f}–{rhi:.2f}$\\times$")
        from matplotlib.ticker import FixedLocator, NullFormatter, ScalarFormatter
        ax[3].set_xscale("log"); ax[3].set_yscale("log")
        ticks = [t for t in (1, 1.5, 2, 3, 5, 8) if lo <= t <= hi]
        for axis in (ax[3].xaxis, ax[3].yaxis):
            axis.set_major_locator(FixedLocator(ticks))
            axis.set_major_formatter(ScalarFormatter())
            axis.set_minor_formatter(NullFormatter())
        ax[3].set_xlabel("measured gain over best corner @3b")
        ax[3].set_ylabel("predicted gain, linearized cost model")
        ax[3].set_title(f"The theory's forward prediction\n"
                        f"ratio {u.lin.min():.2f}–{u.lin.max():.2f} across "
                        f"{len(u)} configurations", fontsize=9.5)
        ax[3].legend(fontsize=6.4, loc="upper left")
    else:
        ax[3].text(.5, .5, "lin_ratio3 not present in these parquets",
                   ha="center", va="center", fontsize=8, transform=ax[3].transAxes)
        ax[3].set_title("The theory's forward prediction", fontsize=9.5)

    for x in ax:
        x.grid(alpha=.22)
        x.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(a.out, dpi=150)
    print(f"wrote {a.out}  ({len(t)} cells, target={a.target}, corner set {a.evictors})")
    c = crossings(t)
    print(f"  crossings: GO {c['GO']:.1f}%  STOP {c['STOP']:.1f}% dead-2")
    print(f"  Spearman(dead2, ROUTED)          = {spearman(t.dead2, t.routed):+.3f}"
          f"   partial (model out) = {partial_spearman(t.dead2, t.routed, t.model):+.3f}")
    print(f"  Spearman(dead2, band  VERDICT)   = {spearman(t.dead2, t.band):+.3f}"
          f"   partial (model out) = {partial_spearman(t.dead2, t.band, t.model):+.3f}")
    print(f"  Spearman(dead2, band  oracle)    = {spearman(t.dead2, t.band_or):+.3f}")
    print(f"  Spearman(ladder, ROUTED)         = {spearman(t.lad, t.routed):+.3f}"
          f"   partial (model out) = {partial_spearman(t.lad, t.routed, t.model):+.3f}")
    print(f"  Spearman(phi,   band)            = {spearman(t.phi, t.band):+.3f}")
    u = t.dropna(subset=["lin", "gain"])
    if len(u):
        print(f"  lin_ratio3 (forward prediction)  = {u.lin.min():.2f}-{u.lin.max():.2f}"
              f"  over {len(u)} configs")
    # The tau/ln2 "prediction" is an identity (std_i(log2 a_i) = tau/ln2 exactly);
    # it is no longer plotted or reported here. See alloc.py and
    # tests/test_units.py::test_ladder_identity.


if __name__ == "__main__":
    main()
