#!/usr/bin/env python3
"""Frozen R9 qualification: direct physical-KV-group K* at 8K.

This runner measures only label-free error curves and keep-count profiles.  It
does not decode answers, read task labels, choose a model/budget/task after the
run, or make an advance/stop decision.  The two models are separate Slurm array
tasks (``submit_kstar_budget_qualification.slurm``).

For each of the 12 fixed prompt units (three families x prompt IDs 0..3), the
prompt is made exactly 8,192 tokens while retaining its suffix.  ``run_r8`` then
prefills the first 8,191 tokens and captures the final 32 prefill queries.  This
leaves exactly 8,159 selectable context tokens and therefore k0=floor(3*C/8)
= 3,059.  Each physical KV group uses one canonical pooled SnapKV ranking.  Its
dense K=1..k0 curve is the mean squared relative output error over every window
query and every query head sharing that KV group; retained context keys use the
existing 8-bit quantizer and the 32-token tail remains exact.

The artifacts intentionally contain scalar rows and averaged error profiles
only.  No raw logits, attention matrices, text, decoded response, answer, or
correctness field is serialized.
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.metadata
import json
import math
import os
import stat
from pathlib import Path
import sys
import time
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from sievelib import baselines as BL  # noqa: E402
from sievelib import budget_policies as BP  # noqa: E402
from sievelib import compress as C  # noqa: E402
from sievelib import group_error_curve as GEC  # noqa: E402
from sievelib import prompts, quant, router  # noqa: E402
import run_h0  # noqa: E402
import run_r8  # noqa: E402


PROTOCOL = "r9_kstar_budget_qualification_v1"
RUNNER_VERSION = "r9_kstar_budget_qualification_runner_v1"
PROFILE_VERSION = "direct_shared_kv_group_dense_integer_curve_v1"
RANKING_VERSION = "canonical_snapkv_obs32_maxpool7_stable_index_ties_v1"
LOSS_VERSION = "mean_rows_squared_relative_output_error_v1"
PROMPT_VERSION = "prompts_build_suffix_preserving_exact8192_v1"
POLICY_VERSION = "bounded_equal_total_integer_projection_v1"
SOURCE_LEDGER_VERSION = "r9_kstar_budget_source_ledger_v1"
SOURCE_LEDGER_RELATIVE = "h0_measurement/bugs/10_kstar_budget/source_ledger.json"
INPUT_MANIFEST_VERSION = "r9_kstar_budget_qualification_input_manifest_v1"
INPUT_MANIFEST_RELATIVE = "h0_measurement/bugs/10_kstar_budget/qualification_input_manifest.json"
INPUT_MANIFEST_CONTENT_SHA256 = "33e6e064970085571db3e4e2e041316b97c160cd537d24b2286cd0d7deaeb8c2"
INPUT_MANIFEST_FILE_SHA256 = "2bbc6093c54aebc017d2e69ff3aaef28cd5985b6d7c7fd81f0041a87571f893e"
PG19_MANIFEST_SHA256 = "64f3b2cd00e1718d5a4f184070f332c3ac3574c34cbaad389537f1f2b41d30a5"
PG19_CORPUS_SHA = "0a26bc1e05a1eea8"
QUANTIZER_CACHE_RELATIVE = "sievelib/.lloyd_cache.pt"
QUANTIZER_CACHE_SHA256 = "e2104a1db92d1caccfa2326087c50a867a5949b1757ecabe01be9b996a44cf4f"
QUANTIZER_LEVEL8_SHA256 = "f1fce245e99a020ee0979e4f07acac3da1a10b3fb86a6cc157dcb549b3ac0196"

CTX = 8192
BUILDER_CTX = 9000
WINDOW = 32
BUDGET = 3
MAXB = 8
KSTAR_TOLERANCE = 0.10
KSTAR_ATOL = 1e-12
CURVE_CHUNK = 128
FAMILIES = ("niah", "qa", "cont")
PROMPT_IDS = (0, 1, 2, 3)
UNIT_ORDER = tuple((p, family) for p in PROMPT_IDS for family in FAMILIES)
CALIBRATION_PROMPT_IDS = (0, 1)
HELDOUT_PROMPT_IDS = (2, 3)
CALIBRATION_UNIT_ORDER = tuple(
    (p, family) for p in CALIBRATION_PROMPT_IDS for family in FAMILIES)
HELDOUT_UNIT_ORDER = tuple(
    (p, family) for p in HELDOUT_PROMPT_IDS for family in FAMILIES)
SPLITS = {
    "calibration": CALIBRATION_PROMPT_IDS,
    "cal_p0": (0,),
    "cal_p1": (1,),
}

FROZEN_POLICIES = (
    "fixed",
    "kstar_prop_calibrated",
    "kstar_shrink20_calibrated",
    "kappa4_rebalanced_calibrated",
    "kappa4_natural_calibrated",
    "adakv_alpha02_calibrated",
    "layer_flat_calibrated",
    "snapkv_global_calibrated",
)
DYNAMIC_POLICIES = (
    "kappa4_rebalanced_dynamic",
    "kappa4_natural_dynamic",
    "adakv_alpha02_dynamic",
    "layer_flat_dynamic",
    "snapkv_global_dynamic",
)
HELDOUT_POLICIES = FROZEN_POLICIES + DYNAMIC_POLICIES

# run_r8.prefill holds out ids[-1] as the next-token query.  These constants
# make that convention explicit and stop an apparently harmless +1 drift.
PREFILL_TOKENS = CTX - 1
CONTEXT_TOKENS = PREFILL_TOKENS - WINDOW
K0 = int(BUDGET * CONTEXT_TOKENS // MAXB)

EXPECTED_RUNTIME_VERSIONS = {
    "numpy": "2.4.2",
    "pandas": "3.0.0",
    "torch": "2.13.0",
    "transformers": "5.16.1",
    "tokenizers": "0.23.1",
    "fastparquet": "2025.12.0+<site>",
    "pyyaml": "6.0.3+<site>",
    "accelerate": "1.14.0+<site>",
    "safetensors": "0.8.0+<site>",
    "huggingface_hub": "1.28.0+<site>",
    "pyarrow": None,
}

MODELS: dict[str, dict[str, Any]] = {
    "llama31-8b": {
        "id": "meta-llama/Llama-3.1-8B-Instruct",
        "revision": "0e9e39f249a16976918f6564b8830bc894c89659",
        "cache_dir": "models--meta-llama--Llama-3.1-8B-Instruct",
        "snapshot_entries": 12,
        "snapshot_inventory_sha256": "7c87347bf1629bc308709853aace9c41348d4cc118c13fa90d4e19995e240315",
        "geometry": {"layers": 32, "query_heads": 32, "kv_heads": 8,
                     "head_dim": 128, "native_ctx": 131072, "model_type": "llama"},
    },
    "qwen15-moe-a2.7b": {
        "id": "Qwen/Qwen1.5-MoE-A2.7B-Chat",
        "revision": "ec052fda178e241c7c443468d2fa1db6618996be",
        "cache_dir": "models--Qwen--Qwen1.5-MoE-A2.7B-Chat",
        "snapshot_entries": 16,
        "snapshot_inventory_sha256": "96c90f38988b38e5b884ac67f0515126791399126f0fc78a83326b42ade4b995",
        "geometry": {"layers": 24, "query_heads": 16, "kv_heads": 16,
                     "head_dim": 128, "native_ctx": 32768,
                     "model_type": "qwen2_moe"},
    },
}

SOURCE_FILES = (
    "h0_measurement/bugs/10_kstar_budget/qualification_protocol_frozen.md",
    "h0_measurement/bugs/10_kstar_budget/qualification_input_manifest.json",
    "h0_measurement/bugs/10_kstar_budget/read_qualification.py",
    "h0_measurement/bugs/10_kstar_budget/steps.sh",
    "h0_measurement/run_kstar_budget_qualification.py",
    "h0_measurement/submit_kstar_budget_qualification.slurm",
    "h0_measurement/run_h0.py",
    "h0_measurement/run_r8.py",
    "h0_measurement/models.yaml",
    "sievelib/__init__.py",
    "sievelib/.lloyd_cache.pt",
    "sievelib/alloc.py",
    "sievelib/baselines.py",
    "sievelib/budget_policies.py",
    "sievelib/compress.py",
    "sievelib/evict.py",
    "sievelib/group_error_curve.py",
    "sievelib/policy_diagnostic.py",
    "sievelib/probe.py",
    "sievelib/prompts.py",
    "sievelib/quant.py",
    "sievelib/router.py",
    "sievelib/tasks_ruler.py",
    "sievelib/validate.py",
    "sievelib/validity.py",
)

UNIT_COLUMNS = (
    "protocol", "runner_version", "profile_version", "ranking_version",
    "loss_version", "model", "model_id", "family", "prompt_idx", "half",
    "layer", "kv_head", "n_rep", "ctx", "n_prompt_tokens",
    "prefill_tokens", "context_tokens", "protected_tail", "B", "maxb",
    "k0", "kstar_tolerance", "kstar_atol", "full_integer_scan", "kstar",
    "kstar_frac", "E_kstar", "E_full", "threshold", "n95",
    "g1_reference_available", "g1_max_abs", "g1_kstar", "g1_kstar_match",
    "builder_ctx", "pre_crop_tokens", "crop_offset", "special_prefix_tokens",
    "special_prefix_sha256", "query_suffix_sha256", "prompt_token_sha256",
    "corpus_sha", "corpus_doc", "corpus_offset", "corpus_spliced",
    "synthetic", "curve_seconds",
)

GROUP_COLUMNS = (
    "protocol", "runner_version", "profile_version", "ranking_version",
    "loss_version", "policy_version", "model", "model_id", "split",
    "split_prompt_ids", "n_units", "layer", "kv_head", "n_rep", "ctx",
    "prefill_tokens", "context_tokens", "protected_tail", "B", "maxb", "k0",
    "kstar_tolerance", "kstar_atol", "full_integer_scan", "kstar",
    "kstar_frac", "E_kstar", "E_full", "threshold", "n95_mean",
    "g1_reference_available", "g1_max_abs", "g1_kstar",
    "g1_kstar_match",
)

COUNT_COLUMNS = (
    "protocol", "runner_version", "policy_version", "model", "model_id",
    "layer", "kv_head", "n_rep", "ctx", "context_tokens", "protected_tail",
    "B", "maxb", "k0", "calibration_prompt_ids", "calibration_units",
    "kstar", "n95_mean", "count_fixed", "count_kstar_prop_calibrated",
    "count_kstar_shrink20_calibrated", "count_kappa4_rebalanced_calibrated",
    "count_kappa4_natural_calibrated", "count_adakv_alpha02_calibrated",
    "count_layer_flat_calibrated", "count_snapkv_global_calibrated",
)

HELDOUT_COLUMNS = (
    "protocol", "runner_version", "profile_version", "ranking_version",
    "loss_version", "policy_version", "model", "model_id", "family",
    "prompt_idx", "layer", "kv_head", "n_rep", "policy", "policy_order",
    "calibrated", "dynamic", "ctx", "n_prompt_tokens", "prefill_tokens",
    "context_tokens", "protected_tail", "B", "maxb", "k0", "keep_count",
    "bits_per_context_token", "budget_matched", "exact_checkpoint",
    "squared_relative_output_error", "n95", "builder_ctx", "pre_crop_tokens",
    "crop_offset", "special_prefix_tokens", "special_prefix_sha256",
    "query_suffix_sha256", "prompt_token_sha256", "corpus_sha", "corpus_doc",
    "corpus_offset", "corpus_spliced", "synthetic",
 )

SUMMARY_KEYS = {
    "protocol", "runner_version", "model", "model_id", "experiment_config",
    "experiment_config_sha256", "models_yaml_sha256", "model_config_sha256",
    "effective_registry", "input_manifest", "model_snapshot", "quantizer_cache",
    "quantizer_levels8", "rotation", "cuda_environment", "placement",
    "corpus_sha", "corpus_preflight", "prompt_records", "source_ledger",
    "source_hashes", "source_set_sha256", "runtime_versions", "row_counts",
    "profile_shape", "g1_reference_shape", "g1_unit_audit",
    "frozen_policy_summaries", "calibration_profile_stability",
    "heldout_policy_summaries", "heldout_policy_totals", "elapsed_seconds",
    "artifact_sha256",
}
PROMPT_RECORD_KEYS = {
    "prompt_idx", "family", "builder_ctx", "pre_crop_tokens", "crop_offset",
    "special_prefix_tokens", "special_prefix_sha256", "query_suffix_sha256",
    "prompt_token_sha256", "corpus_sha", "corpus_doc", "corpus_offset",
    "corpus_spliced", "synthetic", "n_prompt_tokens", "prefill_tokens",
    "context_tokens", "prefill_seconds",
}


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha256(path: str | os.PathLike[str]) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def canonical_sha256(value: Any) -> str:
    return _sha256_bytes(json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
        allow_nan=False).encode("utf-8"))


def token_sha256(ids: Sequence[int]) -> str:
    a = np.asarray([int(x) for x in ids], dtype="<i8")
    return _sha256_bytes(a.tobytes(order="C"))


def float32_tensor_attestation(value: torch.Tensor) -> dict[str, Any]:
    tensor = value.detach().to(device="cpu", dtype=torch.float32).contiguous()
    payload = tensor.numpy().astype("<f4", copy=False).tobytes(order="C")
    return {
        "shape": list(tensor.shape),
        "dtype": "float32",
        "sha256": _sha256_bytes(payload),
    }


def cuda_environment(device: torch.device) -> dict[str, Any]:
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("CUDA environment attestation requires a CUDA device")
    index = device.index if device.index is not None else torch.cuda.current_device()
    props = torch.cuda.get_device_properties(index)
    return {
        "torch_cuda_runtime": str(torch.version.cuda),
        "device_index": int(index),
        "device_name": torch.cuda.get_device_name(index),
        "compute_capability": [int(props.major), int(props.minor)],
        "total_memory_bytes": int(props.total_memory),
        "matmul_allow_tf32": bool(torch.backends.cuda.matmul.allow_tf32),
        "cudnn_allow_tf32": bool(torch.backends.cudnn.allow_tf32),
        "float32_matmul_precision": torch.get_float32_matmul_precision(),
    }


def source_hashes() -> dict[str, str]:
    out = {}
    for rel in SOURCE_FILES:
        p = ROOT / rel
        if not p.is_file() or p.is_symlink():
            raise RuntimeError(f"required source is missing, nonregular, or symlinked: {p}")
        out[rel] = file_sha256(p)
    return out


def source_ledger_object() -> dict[str, Any]:
    body = {
        "ledger_version": SOURCE_LEDGER_VERSION,
        "source_sha256": source_hashes(),
    }
    return {**body, "content_sha256": canonical_sha256(body)}


def verify_source_ledger(path: str | os.PathLike[str]) -> dict[str, Any]:
    p = Path(path)
    if not p.is_file() or p.is_symlink():
        raise RuntimeError(f"source ledger is missing, nonregular, or symlinked: {p}")
    canonical_path = (ROOT / SOURCE_LEDGER_RELATIVE).resolve()
    if p.resolve() != canonical_path:
        raise RuntimeError(f"source ledger must be the canonical path {canonical_path}")
    value = strict_json_load(p)
    if set(value) != {"ledger_version", "source_sha256", "content_sha256"}:
        raise RuntimeError("source ledger has missing or extra top-level keys")
    if value["ledger_version"] != SOURCE_LEDGER_VERSION:
        raise RuntimeError("source ledger version mismatch")
    hashes = value["source_sha256"]
    if not isinstance(hashes, dict) or set(hashes) != set(SOURCE_FILES):
        raise RuntimeError("source ledger path set differs from the executed source closure")
    for rel, digest in hashes.items():
        if not isinstance(rel, str) or not isinstance(digest, str) or len(digest) != 64 \
                or digest != digest.lower() or any(c not in "0123456789abcdef" for c in digest):
            raise RuntimeError("source ledger contains an invalid path/hash entry")
    body = {"ledger_version": value["ledger_version"], "source_sha256": hashes}
    if value["content_sha256"] != canonical_sha256(body):
        raise RuntimeError("source ledger content hash mismatch")
    actual = source_hashes()
    if hashes != actual:
        changed = sorted(rel for rel in hashes if hashes.get(rel) != actual.get(rel))
        raise RuntimeError(f"source ledger does not match executed sources: {changed}")
    return {
        "path": SOURCE_LEDGER_RELATIVE,
        "ledger_version": SOURCE_LEDGER_VERSION,
        "content_sha256": value["content_sha256"],
        "file_sha256": file_sha256(p),
    }


def runtime_versions() -> dict[str, str | None]:
    def dist(name: str) -> str | None:
        try:
            return importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            return None

    return {
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "torch": torch.__version__.split("+")[0],
        "transformers": dist("transformers"),
        "tokenizers": dist("tokenizers"),
        "fastparquet": dist("fastparquet"),
        "pyyaml": dist("PyYAML"),
        "accelerate": dist("accelerate"),
        "safetensors": dist("safetensors"),
        "huggingface_hub": dist("huggingface-hub"),
        "pyarrow": dist("pyarrow"),
    }


def validate_runtime_dependencies() -> dict[str, str | None]:
    versions = runtime_versions()
    required = (
        "numpy", "pandas", "torch", "transformers", "tokenizers", "fastparquet",
        "pyyaml", "accelerate", "safetensors", "huggingface_hub")
    missing = [name for name in required if not versions.get(name)]
    if missing:
        raise RuntimeError(f"missing qualification dependencies: {missing}")
    # This project writes Parquet through fastparquet.  Refuse an environment
    # where pandas could silently choose a different engine and schema encoding.
    if versions != EXPECTED_RUNTIME_VERSIONS:
        raise RuntimeError(
            f"qualification dependency versions drifted: got {versions}, "
            f"expected {EXPECTED_RUNTIME_VERSIONS}")
    return versions


def experiment_config(model_tag: str) -> dict[str, Any]:
    if model_tag not in MODELS:
        raise ValueError(f"unknown model {model_tag!r}; expected {sorted(MODELS)}")
    return {
        "protocol": PROTOCOL,
        "runner_version": RUNNER_VERSION,
        "profile_version": PROFILE_VERSION,
        "ranking_version": RANKING_VERSION,
        "loss_version": LOSS_VERSION,
        "prompt_version": PROMPT_VERSION,
        "policy_version": POLICY_VERSION,
        "model": model_tag,
        "model_spec": MODELS[model_tag],
        "ctx": CTX,
        "builder_ctx": BUILDER_CTX,
        "prefill_tokens": PREFILL_TOKENS,
        "context_tokens": CONTEXT_TOKENS,
        "protected_tail": WINDOW,
        "B": BUDGET,
        "maxb": MAXB,
        "k0": K0,
        "families": list(FAMILIES),
        "prompt_ids": list(PROMPT_IDS),
        "unit_order": [[p, f] for p, f in UNIT_ORDER],
        "splits": {k: list(v) for k, v in SPLITS.items()},
        "calibration_prompt_ids": list(CALIBRATION_PROMPT_IDS),
        "heldout_prompt_ids": list(HELDOUT_PROMPT_IDS),
        "frozen_policies": list(FROZEN_POLICIES),
        "dynamic_policies": list(DYNAMIC_POLICIES),
        "heldout_policies": list(HELDOUT_POLICIES),
        "kstar_tolerance": KSTAR_TOLERANCE,
        "kstar_atol": KSTAR_ATOL,
        "curve_chunk": CURVE_CHUNK,
        "execution": {
            "dtype": "bfloat16", "device_map": "auto", "chunk": 4096,
            "norm_correct": True, "rot_seed": 0,
        },
        "quantizer": {"norm_correct": True, "rot_seed": 0, "retained_bits": MAXB},
    }


def resolve_model_snapshot(model_tag: str, explicit: str = "") -> Path:
    spec = MODELS[model_tag]
    if explicit:
        raw = Path(explicit)
        if raw.is_symlink():
            raise RuntimeError(f"pinned model snapshot root may not be a symlink: {raw}")
        p = raw.resolve()
    else:
        hf_home = Path(os.environ.get("HF_HOME", ROOT / ".hf_cache")).resolve()
        p = hf_home / "hub" / spec["cache_dir"] / "snapshots" / spec["revision"]
    if not p.is_dir() or p.is_symlink():
        raise RuntimeError(f"pinned model snapshot is absent or symlinked: {p}")
    if p.name != spec["revision"]:
        raise RuntimeError(
            f"{model_tag} must use pinned revision {spec['revision']}, got {p.name}")
    return p


def _reject_duplicate_pairs(pairs: Sequence[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise RuntimeError(f"duplicate JSON key: {key!r}")
        out[key] = value
    return out


def _reject_json_constant(value: str) -> None:
    raise RuntimeError(f"non-finite JSON constant is forbidden: {value}")


def strict_json_load(path: str | os.PathLike[str]) -> Any:
    try:
        return json.loads(
            Path(path).read_text(encoding="utf-8"),
            object_pairs_hook=_reject_duplicate_pairs,
            parse_constant=_reject_json_constant,
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"cannot strictly decode JSON {path}: {exc}") from exc


def _require_keys(value: Any, keys: set[str], label: str) -> None:
    if not isinstance(value, dict) or set(value) != keys:
        got = sorted(value) if isinstance(value, dict) else type(value).__name__
        raise RuntimeError(f"{label} schema mismatch: got {got}, expected {sorted(keys)}")


def _require_sha256(value: Any, label: str) -> str:
    if not isinstance(value, str) or len(value) != 64 or value != value.lower() \
            or any(ch not in "0123456789abcdef" for ch in value):
        raise RuntimeError(f"{label} is not a lowercase SHA-256")
    return value


def _safe_relative(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise RuntimeError(f"{label} must be a nonempty relative path")
    p = Path(value)
    if p.is_absolute() or p.as_posix() != value or any(x in ("", ".", "..") for x in p.parts):
        raise RuntimeError(f"{label} is not a canonical safe relative path: {value!r}")
    return value


def validate_quantizer_cache() -> dict[str, Any]:
    path = ROOT / QUANTIZER_CACHE_RELATIVE
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f"8-bit quantizer cache is missing/nonregular: {path}")
    digest = file_sha256(path)
    if digest != QUANTIZER_CACHE_SHA256:
        raise RuntimeError("8-bit quantizer cache file hash mismatch")
    try:
        disk = torch.load(path, map_location="cpu", weights_only=True)
    except Exception as exc:
        raise RuntimeError("cannot load the sealed quantizer cache") from exc
    if not isinstance(disk, dict) or 8 not in disk:
        raise RuntimeError("sealed quantizer cache has no 8-bit level tensor")
    levels = disk[8]
    if not isinstance(levels, torch.Tensor) or levels.shape != (256,) \
            or levels.dtype != torch.float32 or not bool(torch.isfinite(levels).all()) \
            or not bool((levels[1:] > levels[:-1]).all()):
        raise RuntimeError("sealed 8-bit quantizer levels violate shape/dtype/order")
    level_digest = _sha256_bytes(
        levels.contiguous().numpy().astype("<f4", copy=False).tobytes())
    if level_digest != QUANTIZER_LEVEL8_SHA256:
        raise RuntimeError("sealed 8-bit quantizer level tensor hash mismatch")
    return {
        "path": QUANTIZER_CACHE_RELATIVE,
        "file_sha256": digest,
        "bits": 8,
        "levels": 256,
        "dtype": "float32",
        "level_tensor_sha256": level_digest,
    }


def _validate_manifest_snapshot_schema(tag: str, record: Any) -> None:
    _require_keys(record, {
        "model_id", "revision", "root", "directories", "file_count",
        "total_bytes", "inventory_sha256", "files",
    }, f"input_manifest.model_snapshots.{tag}")
    spec = MODELS[tag]
    expected_root = (
        f".hf_cache/hub/{spec['cache_dir']}/snapshots/{spec['revision']}")
    if record["model_id"] != spec["id"] or record["revision"] != spec["revision"] \
            or record["root"] != expected_root:
        raise RuntimeError(f"input manifest identity mismatch for {tag}")
    directories = record["directories"]
    files = record["files"]
    if not isinstance(directories, list) or directories != sorted(set(directories)):
        raise RuntimeError(f"input manifest directory list is not sorted/unique for {tag}")
    for i, rel in enumerate(directories):
        _safe_relative(rel, f"{tag}.directories[{i}]")
    if not isinstance(files, list) or not files:
        raise RuntimeError(f"input manifest has no snapshot files for {tag}")
    file_paths: list[str] = []
    total = 0
    for i, item in enumerate(files):
        _require_keys(item, {
            "path", "kind", "symlink_target", "content_blob_id", "bytes", "sha256",
        }, f"{tag}.files[{i}]")
        rel = _safe_relative(item["path"], f"{tag}.files[{i}].path")
        file_paths.append(rel)
        if item["kind"] not in ("symlink", "regular"):
            raise RuntimeError(f"unsupported input-manifest entry kind for {tag}/{rel}")
        if item["kind"] == "symlink":
            if not isinstance(item["symlink_target"], str) or not item["symlink_target"] \
                    or not isinstance(item["content_blob_id"], str) \
                    or not item["content_blob_id"]:
                raise RuntimeError(f"invalid symlink identity for {tag}/{rel}")
        elif item["symlink_target"] is not None or item["content_blob_id"] is not None:
            raise RuntimeError(f"regular entry carries symlink identity for {tag}/{rel}")
        if not isinstance(item["bytes"], int) or isinstance(item["bytes"], bool) \
                or item["bytes"] < 0:
            raise RuntimeError(f"invalid byte size for {tag}/{rel}")
        _require_sha256(item["sha256"], f"{tag}/{rel}.sha256")
        total += item["bytes"]
    if file_paths != sorted(set(file_paths)):
        raise RuntimeError(f"input manifest file list is not sorted/unique for {tag}")
    if record["file_count"] != len(files) or record["total_bytes"] != total:
        raise RuntimeError(f"input manifest file count/byte total mismatch for {tag}")
    if record["inventory_sha256"] != canonical_sha256({
            "directories": directories, "files": files}):
        raise RuntimeError(f"input manifest inventory hash mismatch for {tag}")
    _require_sha256(record["inventory_sha256"], f"{tag}.inventory_sha256")
    if record["file_count"] != spec["snapshot_entries"] \
            or record["inventory_sha256"] != spec["snapshot_inventory_sha256"]:
        raise RuntimeError(f"input manifest differs from frozen inventory constants for {tag}")


def _authenticate_snapshot(tag: str, record: Mapping[str, Any], snapshot: Path) -> None:
    _validate_manifest_snapshot_schema(tag, record)
    canonical = (ROOT / str(record["root"])).resolve()
    if snapshot.resolve() != canonical:
        raise RuntimeError(f"{tag} snapshot is not the canonical frozen input path")
    if not snapshot.is_dir() or snapshot.is_symlink():
        raise RuntimeError(f"{tag} snapshot root is absent, non-directory, or symlinked")

    actual_dirs: list[str] = []
    actual_files: list[str] = []
    for current, dirnames, filenames in os.walk(snapshot, topdown=True, followlinks=False):
        dirnames.sort()
        filenames.sort()
        base = Path(current)
        for name in dirnames:
            child = base / name
            rel = child.relative_to(snapshot).as_posix()
            if child.is_symlink() or not child.is_dir():
                raise RuntimeError(f"snapshot directory is nonregular/symlinked: {tag}/{rel}")
            actual_dirs.append(rel)
        for name in filenames:
            child = base / name
            actual_files.append(child.relative_to(snapshot).as_posix())
    if sorted(actual_dirs) != list(record["directories"]):
        raise RuntimeError(f"snapshot directory inventory drifted for {tag}")
    expected_files = [str(item["path"]) for item in record["files"]]
    if sorted(actual_files) != expected_files:
        raise RuntimeError(f"snapshot file inventory drifted for {tag}")

    for item in record["files"]:
        rel = str(item["path"])
        path = snapshot / rel
        mode = path.lstat().st_mode
        if item["kind"] == "symlink":
            if not stat.S_ISLNK(mode) or os.readlink(path) != item["symlink_target"]:
                raise RuntimeError(f"snapshot symlink identity drifted: {tag}/{rel}")
            resolved = path.resolve(strict=True)
            if not resolved.is_file() or resolved.is_symlink() \
                    or resolved.name != item["content_blob_id"]:
                raise RuntimeError(f"snapshot blob identity drifted: {tag}/{rel}")
            target = resolved
        else:
            if not stat.S_ISREG(mode):
                raise RuntimeError(f"snapshot regular file changed kind: {tag}/{rel}")
            target = path
        if target.stat().st_size != item["bytes"] or file_sha256(target) != item["sha256"]:
            raise RuntimeError(f"snapshot file bytes/hash drifted: {tag}/{rel}")


def _authenticate_corpus_record(record: Any, corpus_dir: str | os.PathLike[str]) -> None:
    _require_keys(record, {
        "root", "manifest", "file_count", "total_bytes", "inventory_sha256", "files",
    }, "input_manifest.corpus")
    if record["root"] != ".h0_corpus/pg19":
        raise RuntimeError("input manifest corpus root mismatch")
    raw_root = Path(corpus_dir)
    if raw_root.is_symlink():
        raise RuntimeError("H0_CORPUS root may not be a symlink")
    root = raw_root.resolve()
    if root != (ROOT / record["root"]).resolve() or not root.is_dir() or root.is_symlink():
        raise RuntimeError("H0_CORPUS is not the canonical regular PG19 directory")
    manifest_record = record["manifest"]
    _require_keys(manifest_record, {
        "path", "bytes", "sha256", "declared_corpus_sha", "declared_n_books",
        "declared_total_chars",
    }, "input_manifest.corpus.manifest")
    if manifest_record["path"] != record["root"] + "/MANIFEST.json" \
            or manifest_record["sha256"] != PG19_MANIFEST_SHA256 \
            or manifest_record["declared_corpus_sha"] != PG19_CORPUS_SHA:
        raise RuntimeError("PG19 MANIFEST identity mismatch")
    manifest_path = ROOT / manifest_record["path"]
    if not manifest_path.is_file() or manifest_path.is_symlink() \
            or manifest_path.stat().st_size != manifest_record["bytes"] \
            or file_sha256(manifest_path) != manifest_record["sha256"]:
        raise RuntimeError("PG19 MANIFEST bytes/hash mismatch")
    source = strict_json_load(manifest_path)
    _require_keys(source, {
        "source", "fetched_utc", "n_books", "total_chars", "corpus_sha", "files",
    }, "PG19 MANIFEST")
    if source["corpus_sha"] != manifest_record["declared_corpus_sha"] \
            or source["n_books"] != manifest_record["declared_n_books"] \
            or source["total_chars"] != manifest_record["declared_total_chars"]:
        raise RuntimeError("PG19 MANIFEST declared identity drifted")

    files = record["files"]
    if not isinstance(files, list) or not files:
        raise RuntimeError("input manifest has no corpus files")
    names: list[str] = []
    total_bytes = 0
    for i, item in enumerate(files):
        _require_keys(item, {"path", "bytes", "sha256"}, f"corpus.files[{i}]")
        rel = _safe_relative(item["path"], f"corpus.files[{i}].path")
        if len(Path(rel).parts) != 1:
            raise RuntimeError(f"corpus file is not directly under the frozen root: {rel}")
        names.append(rel)
        if not isinstance(item["bytes"], int) or isinstance(item["bytes"], bool) \
                or item["bytes"] < 0:
            raise RuntimeError(f"invalid corpus byte size: {rel}")
        _require_sha256(item["sha256"], f"corpus/{rel}.sha256")
        path = root / rel
        if not path.is_file() or path.is_symlink() \
                or path.stat().st_size != item["bytes"] \
                or file_sha256(path) != item["sha256"]:
            raise RuntimeError(f"corpus file bytes/hash drifted: {rel}")
        total_bytes += item["bytes"]
    if names != sorted(set(names)):
        raise RuntimeError("corpus file list is not sorted/unique")
    if record["file_count"] != len(files) or record["total_bytes"] != total_bytes \
            or record["inventory_sha256"] != canonical_sha256({"files": files}):
        raise RuntimeError("corpus inventory count/bytes/hash mismatch")
    _require_sha256(record["inventory_sha256"], "corpus.inventory_sha256")
    actual_entries = sorted(child.name for child in root.iterdir())
    if actual_entries != sorted(names + ["MANIFEST.json"]):
        raise RuntimeError("PG19 directory has missing or extra entries")

    manifest_files = source["files"]
    if not isinstance(manifest_files, list) or len(manifest_files) != len(files):
        raise RuntimeError("PG19 MANIFEST file count differs from frozen input inventory")
    source_by_name: dict[str, Mapping[str, Any]] = {}
    total_chars = 0
    for i, item in enumerate(manifest_files):
        _require_keys(item, {
            "file", "gutenberg_id", "slug", "n_chars", "sha256",
            "boilerplate_stripped",
        }, f"PG19 MANIFEST.files[{i}]")
        name = item["file"]
        if name in source_by_name:
            raise RuntimeError(f"duplicate PG19 MANIFEST file entry: {name}")
        source_by_name[name] = item
        total_chars += int(item["n_chars"])
    for item in files:
        source_item = source_by_name.get(item["path"])
        if source_item is None or source_item["sha256"] != item["sha256"]:
            raise RuntimeError(f"PG19 declared-vs-byte inventory mismatch: {item['path']}")
    if source["n_books"] != len(files) or source["total_chars"] != total_chars:
        raise RuntimeError("PG19 declared book/character totals are inconsistent")


def verify_input_manifest(path: str | os.PathLike[str], model_tag: str,
                          snapshot: Path,
                          corpus_dir: str | os.PathLike[str]) -> dict[str, Any]:
    if model_tag not in MODELS:
        raise ValueError(f"unknown model tag: {model_tag}")
    p = Path(path)
    if not p.is_file() or p.is_symlink():
        raise RuntimeError(f"input manifest is missing, nonregular, or symlinked: {p}")
    canonical_path = (ROOT / INPUT_MANIFEST_RELATIVE).resolve()
    if p.resolve() != canonical_path:
        raise RuntimeError(f"input manifest must be the canonical path {canonical_path}")
    if file_sha256(p) != INPUT_MANIFEST_FILE_SHA256:
        raise RuntimeError("input manifest file hash mismatch")
    value = strict_json_load(p)
    _require_keys(value, {
        "manifest_version", "corpus", "model_snapshots", "content_sha256",
    }, "input manifest")
    if value["manifest_version"] != INPUT_MANIFEST_VERSION:
        raise RuntimeError("input manifest version mismatch")
    body = {key: value[key] for key in ("manifest_version", "corpus", "model_snapshots")}
    if value["content_sha256"] != INPUT_MANIFEST_CONTENT_SHA256 \
            or value["content_sha256"] != canonical_sha256(body):
        raise RuntimeError("input manifest canonical content hash mismatch")
    _require_sha256(value["content_sha256"], "input_manifest.content_sha256")
    snapshots = value["model_snapshots"]
    if not isinstance(snapshots, dict) or list(snapshots) != list(MODELS):
        raise RuntimeError("input manifest model order/set mismatch")
    for tag in MODELS:
        _validate_manifest_snapshot_schema(tag, snapshots[tag])
    _authenticate_corpus_record(value["corpus"], corpus_dir)
    _authenticate_snapshot(model_tag, snapshots[model_tag], snapshot)
    # Carry the complete frozen input declaration into every result.  A task
    # authenticates its own selected snapshot; the two-task array covers both.
    return {
        "path": INPUT_MANIFEST_RELATIVE,
        "manifest_version": INPUT_MANIFEST_VERSION,
        "content_sha256": value["content_sha256"],
        "file_sha256": INPUT_MANIFEST_FILE_SHA256,
        "corpus": value["corpus"],
        "model_snapshots": value["model_snapshots"],
    }

def validate_registry_config(config_path: str, model_tag: str) -> dict[str, Any]:
    cfg = run_h0.load_cfg(config_path, model_tag, [])
    spec = MODELS[model_tag]
    if cfg.get("id") != spec["id"]:
        raise RuntimeError(f"registry model id drift: {cfg.get('id')} != {spec['id']}")
    if int(cfg.get("native_ctx", 0)) != int(spec["geometry"]["native_ctx"]):
        raise RuntimeError("models.yaml native_ctx does not match the frozen model geometry")
    if CTX > int(cfg["native_ctx"]):
        raise RuntimeError(f"ctx={CTX} exceeds native_ctx={cfg['native_ctx']}")
    expected = {
        "dtype": "bfloat16",
        "device_map": "auto",
        "chunk": 4096,
        "norm_correct": True,
        "rot_seed": 0,
        "maxb": MAXB,
    }
    for key, want in expected.items():
        got = cfg.get(key)
        if isinstance(want, bool):
            valid = isinstance(got, bool) and got is want
        elif isinstance(want, int):
            valid = isinstance(got, int) and not isinstance(got, bool) and got == want
        else:
            valid = got == want
        if not valid:
            raise RuntimeError(f"effective registry setting {key}={got!r}, expected {want!r}")
    return cfg


def validate_live_geometry(cf: Any, model_tag: str) -> dict[str, Any]:
    want = MODELS[model_tag]["geometry"]
    got = {
        "layers": int(getattr(cf, "num_hidden_layers", -1)),
        "query_heads": int(getattr(cf, "num_attention_heads", -1)),
        "kv_heads": int(getattr(cf, "num_key_value_heads", -1)),
        "head_dim": int(getattr(cf, "head_dim", 0) or
                        getattr(cf, "hidden_size", 0) // max(1, getattr(cf, "num_attention_heads", 1))),
        "native_ctx": int(getattr(cf, "max_position_embeddings", -1)),
        "model_type": str(getattr(cf, "model_type", "")),
    }
    if got != want:
        raise RuntimeError(f"live model geometry mismatch: got {got}, expected {want}")
    if got["query_heads"] % got["kv_heads"]:
        raise RuntimeError("query-head count is not divisible by KV-head count")
    return got


def assert_full_cuda(model: Any) -> dict[str, Any]:
    if not torch.cuda.is_available():
        raise RuntimeError("qualification requires CUDA")
    devices = sorted({str(p.device) for p in model.parameters()})
    if not devices or any(not d.startswith("cuda") for d in devices):
        raise RuntimeError(f"model is not fully CUDA-resident: parameter devices={devices}")
    dmap = getattr(model, "hf_device_map", None)
    if dmap:
        bad = {k: v for k, v in dmap.items()
               if str(v).lower() in ("cpu", "disk", "meta")}
        if bad:
            raise RuntimeError(f"model has CPU/disk/meta placement: {bad}")
    return {"parameter_devices": devices,
            "hf_device_map_sha256": canonical_sha256(dmap) if dmap else None}


def _encoding_ids(enc: Any) -> list[int]:
    ids = enc["input_ids"] if isinstance(enc, Mapping) else enc.input_ids
    if ids and isinstance(ids[0], list):
        ids = ids[0]
    return [int(x) for x in ids]


def _encoding_offsets(enc: Any) -> list[tuple[int, int]]:
    offsets = enc["offset_mapping"] if isinstance(enc, Mapping) else enc.offset_mapping
    if offsets and isinstance(offsets[0], list):
        offsets = offsets[0]
    return [(int(a), int(b)) for a, b in offsets]


def build_exact_prompt(tok: Any, family: str, prompt_idx: int, corpus_dir: str,
                       target_tokens: int = CTX) -> tuple[torch.Tensor, dict[str, Any]]:
    """Build from one frozen shared haystack and crop only its text prefix.

    ``BUILDER_CTX`` is identical across families, so prompts.build selects the
    same underlying 8,280-token haystack/doc/offset for niah, qa and cont at a
    given absolute prompt ID.  Keeping leading tokenizer specials and the final
    suffix gives exactly 8,192 tokens without moving or truncating the query.
    """
    if family not in FAMILIES or prompt_idx not in PROMPT_IDS:
        raise ValueError("family/prompt is outside the frozen qualification grid")
    if target_tokens != CTX:
        raise ValueError(f"qualification target must be exactly {CTX}")
    text, meta = prompts.build(
        tok, family, BUILDER_CTX, prompt_idx=prompt_idx,
        corpus_dir=corpus_dir, require_real=True)
    if bool(meta.get("synthetic", True)):
        raise RuntimeError(f"p{prompt_idx}/{family}: prompt builder returned synthetic text")
    try:
        enc = tok(text, return_offsets_mapping=True)
        ids = _encoding_ids(enc)
        offsets = _encoding_offsets(enc)
    except Exception as exc:
        raise RuntimeError(
            "qualification requires a fast tokenizer with offset mappings") from exc
    pre_crop_tokens = len(ids)
    if pre_crop_tokens < target_tokens:
        raise RuntimeError(
            f"p{prompt_idx}/{family}: frozen builder_ctx={BUILDER_CTX} produced only "
            f"{pre_crop_tokens} tokens, fewer than {target_tokens}")
    crop = pre_crop_tokens - target_tokens
    leading_special = 0
    for a, b in offsets:
        if a == b == 0:
            leading_special += 1
        else:
            break
    if leading_special + crop > pre_crop_tokens:
        raise RuntimeError("exact prompt crop exceeds content tokens")
    if family == "niah":
        lo = int(meta.get("needle_char_start", -1))
        hi = int(meta.get("needle_char_end", -1))
        span = [i for i, (a, b) in enumerate(offsets)
                if b > lo and a < hi and b > a]
        if lo < 0 or hi <= lo or not span:
            raise RuntimeError(f"p{prompt_idx}: NIAH needle has no exact token span")
        if min(span) < leading_special + crop:
            raise RuntimeError(
                f"p{prompt_idx}: exact-length prefix crop would remove NIAH needle")
    final = ids[:leading_special] + ids[leading_special + crop:]
    if len(final) != target_tokens:
        raise RuntimeError("exact prompt construction produced the wrong token count")
    suffix_width = min(WINDOW + 1, pre_crop_tokens - leading_special)
    if suffix_width < WINDOW + 1 or final[-suffix_width:] != ids[-suffix_width:]:
        raise RuntimeError("exact prompt construction changed the final query suffix")
    provenance = {
        "builder_ctx": BUILDER_CTX,
        "pre_crop_tokens": pre_crop_tokens,
        "crop_offset": crop,
        "special_prefix_tokens": leading_special,
        "special_prefix_sha256": token_sha256(ids[:leading_special]),
        "query_suffix_sha256": token_sha256(final[-suffix_width:]),
        "prompt_token_sha256": token_sha256(final),
        "corpus_sha": str(meta.get("corpus_sha") or ""),
        "corpus_doc": str(meta.get("doc") or ""),
        "corpus_offset": int(meta.get("offset") or 0),
        "corpus_spliced": bool(meta.get("spliced", False)),
        "synthetic": False,
    }
    if not provenance["corpus_sha"] or not provenance["corpus_doc"]:
        raise RuntimeError(f"p{prompt_idx}/{family}: incomplete corpus provenance")
    return torch.tensor(final, dtype=torch.long).view(1, -1), provenance


def canonical_order_n95_from_scores(
    pooled_score: torch.Tensor,
    raw_score: torch.Tensor,
    *,
    expected_kv_heads: int | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """SnapKV order from pooled score; n95_u from unpooled window mass."""
    Hkv, width = pooled_score.shape
    if tuple(raw_score.shape) != tuple(pooled_score.shape):
        raise RuntimeError("pooled and raw SnapKV scores have different shapes")
    if width != CONTEXT_TOKENS or (expected_kv_heads is not None and Hkv != expected_kv_heads):
        raise RuntimeError(f"canonical SnapKV score has invalid shape {tuple(pooled_score.shape)}")
    pooled = pooled_score.double()
    raw = raw_score.double()
    for label, value in (("pooled", pooled), ("raw", raw)):
        if not bool(torch.isfinite(value).all()) or bool((value < 0).any()):
            raise RuntimeError(f"canonical {label} SnapKV score is nonfinite or negative")
        if not bool((value.sum(-1) > 0).all()):
            raise RuntimeError(f"canonical {label} SnapKV score has a zero-mass KV group")
    # Stable index ties freeze a total order for the shared kept sets.
    order = torch.argsort(pooled, dim=-1, descending=True, stable=True)
    # n95_u is the support of the UNPOOLED group-summed observation-window
    # attention.  Pooling deliberately affects ranking, not this support signal.
    raw_order = torch.argsort(raw, dim=-1, descending=True, stable=True)
    raw_prob = raw / raw.sum(-1, keepdim=True)
    sorted_prob = raw_prob.gather(1, raw_order)
    threshold = torch.full((Hkv, 1), 0.95, dtype=torch.float64, device=raw.device)
    n95 = torch.searchsorted(torch.cumsum(sorted_prob, -1), threshold).squeeze(1) + 1
    return order, n95.long()


def canonical_order_and_n95(ctx: router.LayerCtx) -> tuple[torch.Tensor, torch.Tensor]:
    pooled = BL.score_snapkv(ctx, obs=WINDOW, pool="max", pool_k=router.SNAPKV_POOL)
    return canonical_order_n95_from_scores(
        pooled, ctx.snap, expected_kv_heads=ctx.Kc.shape[0])


def captured_snapkv_scores(
    geometry: Mapping[str, int],
) -> tuple[dict[int, torch.Tensor], dict[int, torch.Tensor]]:
    expected = set(range(int(geometry["layers"])))
    if set(C.STATE.score) != expected:
        raise RuntimeError("canonical SnapKV capture is missing one or more layers")
    pooled, raw = {}, {}
    for li in range(int(geometry["layers"])):
        raw_score = C.STATE.score[li].float()
        pooled_score = router.snapkv_pool(raw_score, router.SNAPKV_POOL).float()
        canonical_order_n95_from_scores(
            pooled_score, raw_score, expected_kv_heads=int(geometry["kv_heads"]))
        pooled[li], raw[li] = pooled_score, raw_score
    return pooled, raw


def group_inputs(ctx: router.LayerCtx, kv_head: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return full logits, 8-bit context logits, and shared values for one group."""
    Cn = int(ctx.Kc.shape[1])
    W = int(ctx.Kw.shape[1])
    r = int(ctx.n_rep)
    if Cn != CONTEXT_TOKENS or W != WINDOW:
        raise RuntimeError(f"layer context has C={Cn}, W={W}; expected {CONTEXT_TOKENS}, {WINDOW}")
    if MAXB not in ctx.Kq:
        raise RuntimeError("8-bit context-key capture is missing")
    q = ctx.qwin[kv_head * r:(kv_head + 1) * r].float().to(ctx.Kc.device)
    if tuple(q.shape[1:]) != (WINDOW, ctx.Kc.shape[-1]):
        raise RuntimeError(f"window queries have invalid shape {tuple(q.shape)}")
    k_full = torch.cat([ctx.Kc[kv_head], ctx.Kw[kv_head]], dim=0).float()
    values = torch.cat([ctx.Vc[kv_head], ctx.Vw[kv_head]], dim=0).float()
    full = torch.einsum("rtd,kd->rtk", q, k_full) * float(ctx.scaling)
    pos = torch.arange(WINDOW, device=full.device) + Cn
    key_pos = torch.arange(Cn + WINDOW, device=full.device)
    full = full.masked_fill(
        key_pos.view(1, 1, -1) > pos.view(1, -1, 1), -torch.inf)
    qctx = torch.einsum(
        "rtd,kd->rtk", q, ctx.Kq[MAXB][kv_head].float()) * float(ctx.scaling)
    return full, qctx, values


def group_curve(ctx: router.LayerCtx, kv_head: int, order: torch.Tensor,
                k0: int = K0) -> torch.Tensor:
    """Exact shared-ranking curve for one physical KV group."""
    full, qctx, values = group_inputs(ctx, kv_head)
    curve = GEC.dense_group_error_curve(
        full, qctx, values, order, k_max=k0, chunk_size=CURVE_CHUNK,
        eps=KSTAR_ATOL)
    if curve.shape != (k0,) or not bool(torch.isfinite(curve).all()) \
            or bool((curve < 0).any()):
        raise RuntimeError("dense group curve is incomplete, nonfinite, or negative")
    return curve


def independent_single_head_curve(
    full_logits: torch.Tensor,
    quantized_context_logits: torch.Tensor,
    values: torch.Tensor,
    order: torch.Tensor,
    *,
    k_max: int = K0,
) -> torch.Tensor:
    """Independent G=1 profile with a stable softmax for every prefix.

    This path intentionally does not call any ``group_error_curve`` helper.  It
    forms prefix log-sum-exp states directly, including signed value numerators,
    and separately handles positive infinities.  The exact full-logit ``-inf``
    mask overrides finite quantized dot products.
    """
    if full_logits.shape[0] != 1:
        raise ValueError("single-head reference requires exactly one query head")
    if not isinstance(k_max, int) or isinstance(k_max, bool) \
            or not 1 <= k_max <= quantized_context_logits.shape[-1]:
        raise ValueError("single-head reference k_max is outside the context")
    Cn = int(quantized_context_logits.shape[-1])
    N = int(full_logits.shape[-1])
    if full_logits.shape[:-1] != quantized_context_logits.shape[:-1] \
            or values.shape[0] != N or not Cn <= N:
        raise ValueError("single-head reference input shapes disagree")
    od = torch.as_tensor(order, device=full_logits.device, dtype=torch.long)
    if od.shape != (Cn,) or not torch.equal(
            torch.sort(od).values, torch.arange(Cn, device=od.device)):
        raise ValueError("single-head reference order is not a context permutation")

    fd = full_logits.reshape(-1, N).double()
    qd = quantized_context_logits.reshape(-1, Cn).double()
    vd = values.double()
    if bool(torch.isnan(fd).any()) or bool(torch.isnan(qd).any()) \
            or not bool(torch.isfinite(vd).all()):
        raise ValueError("single-head reference received NaN logits or nonfinite values")
    qd = qd.masked_fill(torch.isneginf(fd[:, :Cn]), -torch.inf)

    def direct_softmax_output(logits: torch.Tensor) -> torch.Tensor:
        posinf = torch.isposinf(logits)
        finite = torch.isfinite(logits)
        if not bool((posinf.any(-1) | finite.any(-1)).all()):
            raise RuntimeError("single-head reference has a fully masked row")
        finite_logits = torch.where(
            finite, logits, torch.full_like(logits, -torch.inf))
        maximum = finite_logits.amax(-1, keepdim=True)
        maximum = torch.where(torch.isfinite(maximum), maximum,
                              torch.zeros_like(maximum))
        finite_weights = torch.where(
            finite, torch.exp(logits - maximum), torch.zeros_like(logits))
        finite_weights = finite_weights / finite_weights.sum(
            -1, keepdim=True).clamp_min(1e-300)
        inf_weights = posinf.to(logits.dtype) / posinf.sum(
            -1, keepdim=True).clamp_min(1)
        weights = torch.where(posinf.any(-1, keepdim=True),
                              inf_weights, finite_weights)
        return weights @ vd

    reference = direct_softmax_output(fd)
    scale = reference.norm(dim=-1).clamp_min(KSTAR_ATOL).square()
    ranked_logits = qd[:, od[:k_max]]
    ranked_values = vd[:Cn][od[:k_max]]
    tail_logits = fd[:, Cn:]
    tail_values = vd[Cn:]

    finite_q = torch.isfinite(ranked_logits)
    qlog = torch.where(
        finite_q, ranked_logits, torch.full_like(ranked_logits, -torch.inf))
    finite_tail = torch.isfinite(tail_logits)
    tail_log = torch.where(
        finite_tail, tail_logits, torch.full_like(tail_logits, -torch.inf))
    rows, dim = fd.shape[0], vd.shape[1]
    if tail_logits.shape[1]:
        base_den = torch.logsumexp(tail_log, dim=1)
    else:
        base_den = torch.full((rows,), -torch.inf, dtype=torch.float64,
                              device=fd.device)
    prefix_den = torch.logcumsumexp(qlog, dim=1)
    log_den = torch.logaddexp(base_den[:, None], prefix_den)

    positive_log = torch.where(
        vd > 0, vd.log(), torch.full_like(vd, -torch.inf))
    negative_log = torch.where(
        vd < 0, (-vd).log(), torch.full_like(vd, -torch.inf))

    def signed_component(value_log: torch.Tensor) -> torch.Tensor:
        if tail_logits.shape[1]:
            base = torch.logsumexp(
                tail_log[:, :, None] + value_log[Cn:][None, :, :], dim=1)
        else:
            base = torch.full((rows, dim), -torch.inf, dtype=torch.float64,
                              device=fd.device)
        prefix = torch.logcumsumexp(
            qlog[:, :, None] + value_log[:Cn][od[:k_max]][None, :, :], dim=1)
        total = torch.logaddexp(base[:, None, :], prefix)
        return torch.where(
            torch.isfinite(total), torch.exp(total - log_den[:, :, None]),
            torch.zeros_like(total))

    finite_outputs = signed_component(positive_log) - signed_component(negative_log)

    qinf = torch.isposinf(ranked_logits)
    if tail_logits.shape[1]:
        tail_inf = torch.isposinf(tail_logits)
        inf_count = tail_inf.sum(-1).long()
        inf_num = tail_inf.to(torch.float64) @ tail_values
    else:
        inf_count = torch.zeros(rows, dtype=torch.long, device=fd.device)
        inf_num = torch.zeros((rows, dim), dtype=torch.float64, device=fd.device)
    prefix_inf_count = inf_count[:, None] + qinf.cumsum(-1)
    prefix_inf_num = inf_num[:, None, :] + (
        qinf.to(torch.float64)[:, :, None] * ranked_values[None, :, :]).cumsum(1)
    inf_outputs = prefix_inf_num / prefix_inf_count.clamp_min(1)[:, :, None]
    has_inf = prefix_inf_count > 0
    outputs = torch.where(has_inf[:, :, None], inf_outputs, finite_outputs)
    valid = has_inf | torch.isfinite(log_den)
    if not bool(valid.all()):
        raise RuntimeError("single-head reference has a fully masked kept prefix")
    losses = (outputs - reference[:, None, :]).square().sum(-1) / scale[:, None]
    result = losses.mean(0)
    if result.shape != (k_max,) or not bool(torch.isfinite(result).all()) \
            or bool((result < 0).any()):
        raise RuntimeError("single-head reference curve is incomplete/nonfinite")
    return result

def curve_scalars(curve: torch.Tensor, k0: int = K0) -> dict[str, Any]:
    c = torch.as_tensor(curve, dtype=torch.float64).reshape(-1)
    kstar = int(GEC.exact_kstar(
        c, k0, tolerance=KSTAR_TOLERANCE, atol=KSTAR_ATOL))
    e_full = float(c[k0 - 1])
    threshold = (1.0 + KSTAR_TOLERANCE) * e_full + KSTAR_ATOL
    e_kstar = float(c[kstar - 1])
    if e_kstar > threshold + 1e-15:
        raise RuntimeError("exact_kstar does not satisfy its threshold")
    if kstar > 1 and float(c[:kstar - 1].min()) <= threshold:
        raise RuntimeError("exact_kstar did not choose the first passing integer")
    return {
        "kstar": kstar,
        "kstar_frac": kstar / k0,
        "E_kstar": e_kstar,
        "E_full": e_full,
        "threshold": threshold,
    }


def policy_counts(kstars: torch.Tensor, n95: torch.Tensor,
                  geometry: Mapping[str, int]) -> dict[str, torch.Tensor]:
    shape = (int(geometry["layers"]), int(geometry["kv_heads"]))
    if tuple(kstars.shape) != shape or tuple(n95.shape) != shape:
        raise ValueError(f"policy signals must have shape {shape}")
    keys = [(li, g) for li in range(shape[0]) for g in range(shape[1])]
    flat_k = kstars.reshape(-1).double()
    flat_n = n95.reshape(-1).double()
    n = int(flat_k.numel())
    out = {
        "uniform": BP.fixed_uniform_counts(n, K0, CONTEXT_TOKENS, keys=keys),
        "prop": BP.kstar_prop_counts(flat_k, K0, CONTEXT_TOKENS, keys=keys),
        "shrink20": BP.shrink20_counts(flat_k, K0, CONTEXT_TOKENS, keys=keys),
        "n95": BP.kappa4_rebalanced_counts(
            flat_n, K0, CONTEXT_TOKENS, keys=keys, kappa=4.0, floor=256),
        "n95_raw": BP.kappa4_raw_counts(
            flat_n, K0, CONTEXT_TOKENS, kappa=4.0, floor=256),
    }
    target = n * K0
    for name in ("uniform", "prop", "shrink20", "n95"):
        x = out[name]
        if x.dtype != torch.long or int(x.sum()) != target:
            raise RuntimeError(f"{name} policy does not spend exact target {target}")
        if bool((x < 1).any()) or bool((x > CONTEXT_TOKENS).any()):
            raise RuntimeError(f"{name} policy violates count bounds")
    return {name: x.reshape(shape) for name, x in out.items()}


def snapkv_allocator_counts(
    scores: Mapping[int, torch.Tensor], geometry: Mapping[str, int]
) -> dict[str, torch.Tensor]:
    """Published count allocators applied once to a complete score snapshot."""
    layers, heads = int(geometry["layers"]), int(geometry["kv_heads"])
    if set(scores) != set(range(layers)):
        raise RuntimeError("SnapKV allocator needs every layer score")
    for li, score in scores.items():
        if tuple(score.shape) != (heads, CONTEXT_TOKENS):
            raise RuntimeError(f"layer {li}: invalid allocator score shape {tuple(score.shape)}")
    ada = BL.parse("adakv")
    layer_flat = BL.parse("snapkv:alloc=layer")
    model_global = BL.parse("snapkv:alloc=global")
    out = {
        "adakv_alpha02": torch.stack([
            BL.counts_layer(ada, scores[li], K0) for li in range(layers)]),
        "layer_flat": torch.stack([
            BL.counts_layer(layer_flat, scores[li], K0) for li in range(layers)]),
    }
    global_dict = BL.counts_model(model_global, dict(scores), K0)
    out["snapkv_global"] = torch.stack([global_dict[li] for li in range(layers)])
    target = layers * heads * K0
    for name, counts in out.items():
        counts = counts.cpu().long()
        if tuple(counts.shape) != (layers, heads) or int(counts.sum()) != target:
            raise RuntimeError(f"{name} counts are incomplete or budget-mismatched")
        if bool((counts < 0).any()) or bool((counts > CONTEXT_TOKENS).any()):
            raise RuntimeError(f"{name} counts violate [0,C]")
        out[name] = counts
    return out


def freeze_calibrated_counts(
    kstars: torch.Tensor,
    n95: torch.Tensor,
    scores: Mapping[int, torch.Tensor],
    geometry: Mapping[str, int],
) -> dict[str, torch.Tensor]:
    core = policy_counts(kstars, n95, geometry)
    published = snapkv_allocator_counts(scores, geometry)
    return {
        "fixed": core["uniform"],
        "kstar_prop_calibrated": core["prop"],
        "kstar_shrink20_calibrated": core["shrink20"],
        "kappa4_rebalanced_calibrated": core["n95"],
        "kappa4_natural_calibrated": core["n95_raw"],
        "adakv_alpha02_calibrated": published["adakv_alpha02"],
        "layer_flat_calibrated": published["layer_flat"],
        "snapkv_global_calibrated": published["snapkv_global"],
    }


def heldout_dynamic_counts(
    n95: torch.Tensor,
    scores: Mapping[int, torch.Tensor],
    geometry: Mapping[str, int],
) -> dict[str, torch.Tensor]:
    layers, heads = int(geometry["layers"]), int(geometry["kv_heads"])
    keys = [(li, g) for li in range(layers) for g in range(heads)]
    flat = n95.reshape(-1).double()
    rebalanced = BP.kappa4_rebalanced_counts(
        flat, K0, CONTEXT_TOKENS, keys=keys, kappa=4.0, floor=256
    ).reshape(layers, heads)
    natural = BP.kappa4_raw_counts(
        flat, K0, CONTEXT_TOKENS, kappa=4.0, floor=256
    ).reshape(layers, heads)
    published = snapkv_allocator_counts(scores, geometry)
    return {
        "kappa4_rebalanced_dynamic": rebalanced.cpu().long(),
        "kappa4_natural_dynamic": natural.cpu().long(),
        "adakv_alpha02_dynamic": published["adakv_alpha02"],
        "layer_flat_dynamic": published["layer_flat"],
        "snapkv_global_dynamic": published["snapkv_global"],
    }


def _rankdata(x: np.ndarray) -> np.ndarray:
    return pd.Series(np.asarray(x, dtype=np.float64)).rank(method="average").to_numpy()


def _correlation(x: np.ndarray, y: np.ndarray, *, rank: bool = False) -> float | None:
    x = _rankdata(x) if rank else np.asarray(x, dtype=np.float64)
    y = _rankdata(y) if rank else np.asarray(y, dtype=np.float64)
    if x.size != y.size or x.size < 2 or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("correlation inputs must be same-size finite vectors")
    if float(x.std()) == 0.0 or float(y.std()) == 0.0:
        return None
    return float(np.corrcoef(x, y)[0, 1])


def policy_summary(counts: Mapping[str, torch.Tensor]) -> dict[str, Any]:
    base_key = "uniform" if "uniform" in counts else "fixed"
    n = counts[base_key].numel()
    target = n * K0
    out = {}
    base = counts[base_key].reshape(-1).long()
    for name, tensor in counts.items():
        x = tensor.reshape(-1).long()
        actual = int(x.sum())
        l1 = int((x - base).abs().sum())
        out[name] = {
            "target_tokens": target if "natural" not in name and name != "n95_raw" else None,
            "actual_tokens": actual,
            "budget_delta": actual - target,
            "mean_count": float(x.double().mean()),
            "min_count": int(x.min()),
            "max_count": int(x.max()),
            "groups": n,
            "groups_below_k0": int((x < K0).sum()),
            "groups_at_k0": int((x == K0).sum()),
            "groups_above_k0": int((x > K0).sum()),
            "groups_at_zero": int((x == 0).sum()),
            "groups_at_lower_bound": int((x == 1).sum()),
            "groups_at_capacity": int((x == CONTEXT_TOKENS).sum()),
            "l1_movement_tokens": l1,
            "movement_fraction": l1 / (2.0 * target),
        }
    return out


def stability_summary(split_kstars: Mapping[str, torch.Tensor],
                      split_counts: Mapping[str, Mapping[str, torch.Tensor]]) -> dict[str, Any]:
    a = split_kstars["cal_p0"].cpu().numpy().reshape(-1)
    b = split_kstars["cal_p1"].cpu().numpy().reshape(-1)
    d = np.abs(a - b)
    out: dict[str, Any] = {
        "kstar_half_spearman": _correlation(a, b, rank=True),
        "kstar_half_pearson": _correlation(a, b),
        "kstar_half_exact_fraction": float(np.mean(a == b)),
        "kstar_half_median_abs_delta": float(np.median(d)),
        "kstar_half_mean_abs_delta": float(np.mean(d)),
        "kstar_half_median_abs_delta_over_k0": float(np.median(d) / K0),
    }
    for policy in ("uniform", "prop", "shrink20", "n95"):
        x = split_counts["cal_p0"][policy].cpu().numpy().reshape(-1)
        y = split_counts["cal_p1"][policy].cpu().numpy().reshape(-1)
        delta = np.abs(x - y)
        out[f"{policy}_half_spearman"] = _correlation(x, y, rank=True)
        out[f"{policy}_half_exact_fraction"] = float(np.mean(x == y))
        out[f"{policy}_half_median_abs_delta"] = float(np.median(delta))
        out[f"{policy}_half_mean_abs_delta"] = float(np.mean(delta))
    return out


def _atomic_parquet(df: pd.DataFrame, path: Path) -> None:
    tmp = path.with_name(path.name + ".tmp")
    df.to_parquet(tmp, index=False, engine="fastparquet")
    os.replace(tmp, path)


def _atomic_json(value: Any, path: Path) -> None:
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _atomic_npz(path: Path, **arrays: Any) -> None:
    tmp = path.with_name(path.name + ".tmp.npz")
    np.savez_compressed(tmp, **arrays)
    os.replace(tmp, path)


def _check_frame_finite(df: pd.DataFrame, columns: Iterable[str], label: str) -> None:
    for col in columns:
        vals = pd.to_numeric(df[col], errors="raise").to_numpy(dtype=np.float64)
        if not np.isfinite(vals).all():
            raise RuntimeError(f"{label}.{col} contains nonfinite values")


def validate_artifacts(out_dir: str | os.PathLike[str], model_tag: str,
                       source_ledger: str, input_manifest: str,
                       model_source: str = "", *,
                       verify_environment: bool = True) -> dict[str, Any]:
    """Strict, label-free validation used before the worker writes COMPLETE."""
    out = Path(out_dir)
    paths = {
        "units": out / "kstar_budget_units.parquet",
        "groups": out / "kstar_budget_groups.parquet",
        "counts": out / "kstar_budget_frozen_counts.parquet",
        "heldout": out / "kstar_budget_heldout.parquet",
        "curves": out / "kstar_budget_curves.npz",
        "summary": out / "kstar_budget_summary.json",
    }
    for name, path in paths.items():
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"missing/nonregular {name} artifact: {path}")
    allowed = {p.name for p in paths.values()} | {"COMPLETE"}
    extra = sorted(p.name for p in out.iterdir() if p.name not in allowed)
    if extra:
        raise RuntimeError(f"unexpected files in qualification task directory: {extra}")
    summary = strict_json_load(paths["summary"])
    _require_keys(summary, SUMMARY_KEYS, "qualification summary")
    config = experiment_config(model_tag)
    geom = MODELS[model_tag]["geometry"]
    if summary["protocol"] != PROTOCOL or summary["runner_version"] != RUNNER_VERSION \
            or summary["model"] != model_tag \
            or summary["model_id"] != MODELS[model_tag]["id"]:
        raise RuntimeError("summary protocol/runner/model identity mismatch")
    if summary["experiment_config"] != config \
            or summary["experiment_config_sha256"] != canonical_sha256(config):
        raise RuntimeError("experiment config body/hash mismatch")
    expected_effective = {
        "dtype": "bfloat16", "device_map": "auto", "chunk": 4096,
        "norm_correct": True, "rot_seed": 0, "maxb": MAXB,
    }
    if summary["effective_registry"] != expected_effective:
        raise RuntimeError("effective registry settings mismatch")
    manifest_value = strict_json_load(input_manifest)
    expected_inputs = {
        "path": INPUT_MANIFEST_RELATIVE,
        "manifest_version": INPUT_MANIFEST_VERSION,
        "content_sha256": INPUT_MANIFEST_CONTENT_SHA256,
        "file_sha256": INPUT_MANIFEST_FILE_SHA256,
        "corpus": manifest_value.get("corpus"),
        "model_snapshots": manifest_value.get("model_snapshots"),
    }
    if summary["input_manifest"] != expected_inputs \
            or summary["model_snapshot"] != expected_inputs["model_snapshots"][model_tag]:
        raise RuntimeError("summary frozen input declaration mismatch")
    if summary["corpus_sha"] != PG19_CORPUS_SHA:
        raise RuntimeError("summary corpus identity mismatch")
    if summary["quantizer_cache"] != {
            "path": QUANTIZER_CACHE_RELATIVE,
            "file_sha256": QUANTIZER_CACHE_SHA256,
            "bits": 8, "levels": 256, "dtype": "float32",
            "level_tensor_sha256": QUANTIZER_LEVEL8_SHA256} \
            or summary["quantizer_levels8"] != {
                "shape": [256], "dtype": "float32",
                "sha256": QUANTIZER_LEVEL8_SHA256}:
        raise RuntimeError("summary quantizer attestation mismatch")
    rotation = summary["rotation"]
    _require_keys(rotation, {"shape", "dtype", "sha256"}, "summary.rotation")
    if rotation["shape"] != [geom["head_dim"], geom["head_dim"]] \
            or rotation["dtype"] != "float32":
        raise RuntimeError("summary rotation shape/dtype mismatch")
    _require_sha256(rotation["sha256"], "summary.rotation.sha256")
    cuda = summary["cuda_environment"]
    _require_keys(cuda, {
        "torch_cuda_runtime", "device_index", "device_name", "compute_capability",
        "total_memory_bytes", "matmul_allow_tf32", "cudnn_allow_tf32",
        "float32_matmul_precision",
    }, "summary.cuda_environment")
    if not isinstance(cuda["torch_cuda_runtime"], str) \
            or not isinstance(cuda["device_name"], str) \
            or not isinstance(cuda["device_index"], int) \
            or not isinstance(cuda["compute_capability"], list) \
            or len(cuda["compute_capability"]) != 2 \
            or not all(isinstance(x, int) for x in cuda["compute_capability"]) \
            or not isinstance(cuda["total_memory_bytes"], int) \
            or cuda["total_memory_bytes"] <= 0 \
            or cuda["float32_matmul_precision"] not in ("highest", "high", "medium"):
        raise RuntimeError("summary CUDA environment has invalid values")
    placement = summary["placement"]
    _require_keys(placement, {"parameter_devices", "hf_device_map_sha256"},
                  "summary.placement")
    if not isinstance(placement["parameter_devices"], list) \
            or not placement["parameter_devices"] \
            or any(not isinstance(x, str) or not x.startswith("cuda")
                   for x in placement["parameter_devices"]):
        raise RuntimeError("summary placement is not fully CUDA")
    if placement["hf_device_map_sha256"] is not None:
        _require_sha256(placement["hf_device_map_sha256"],
                        "summary.placement.hf_device_map_sha256")
    if summary["runtime_versions"] != EXPECTED_RUNTIME_VERSIONS:
        raise RuntimeError("summary runtime-version contract mismatch")
    if set(summary["source_hashes"]) != set(SOURCE_FILES) \
            or summary["source_set_sha256"] != canonical_sha256(summary["source_hashes"]):
        raise RuntimeError("summary source closure/hash mismatch")
    records = summary["prompt_records"]
    if not isinstance(records, list) or len(records) != len(UNIT_ORDER):
        raise RuntimeError("summary prompt-record count mismatch")
    for i, record in enumerate(records):
        _require_keys(record, PROMPT_RECORD_KEYS, f"prompt_records[{i}]")
    _assert_shared_haystack(records)
    for name in ("units", "groups", "counts", "heldout", "curves"):
        if summary.get("artifact_sha256", {}).get(name) != file_sha256(paths[name]):
            raise RuntimeError(f"{name} artifact hash mismatch")
    if set(summary.get("artifact_sha256", {})) != {
            "units", "groups", "counts", "heldout", "curves"}:
        raise RuntimeError("summary artifact hash set mismatch")
    if verify_environment:
        ledger = verify_source_ledger(source_ledger)
        if summary.get("source_ledger") != ledger:
            raise RuntimeError("source ledger attestation mismatch")
        if summary.get("source_hashes") != source_hashes():
            raise RuntimeError("source hash mismatch at validate-only")
        if summary.get("runtime_versions") != validate_runtime_dependencies():
            raise RuntimeError("runtime dependency versions changed")
        corpus = prompts.resolve_corpus_dir(os.environ.get("H0_CORPUS"))
        if corpus is None:
            raise RuntimeError("corpus is absent at validate-only")
        snapshot = resolve_model_snapshot(model_tag, model_source)
        inputs = verify_input_manifest(input_manifest, model_tag, snapshot, corpus)
        if summary.get("input_manifest") != inputs:
            raise RuntimeError("qualification input-manifest attestation mismatch")
        if summary.get("model_snapshot") != inputs["model_snapshots"][model_tag]:
            raise RuntimeError("selected model snapshot summary mismatch")
        if summary.get("corpus_sha") != PG19_CORPUS_SHA:
            raise RuntimeError("summary corpus identity mismatch")
        if summary.get("quantizer_cache") != validate_quantizer_cache():
            raise RuntimeError("quantizer-cache attestation mismatch")

    units = pd.read_parquet(paths["units"], engine="fastparquet")
    groups = pd.read_parquet(paths["groups"], engine="fastparquet")
    counts = pd.read_parquet(paths["counts"], engine="fastparquet")
    heldout = pd.read_parquet(paths["heldout"], engine="fastparquet")
    if tuple(units.columns) != UNIT_COLUMNS or tuple(groups.columns) != GROUP_COLUMNS \
            or tuple(counts.columns) != COUNT_COLUMNS \
            or tuple(heldout.columns) != HELDOUT_COLUMNS:
        raise RuntimeError("artifact schema/order mismatch")
    n_groups = geom["layers"] * geom["kv_heads"]
    expected_rows = {
        "units": len(CALIBRATION_UNIT_ORDER) * n_groups,
        "groups": len(SPLITS) * n_groups,
        "counts": n_groups,
        "heldout": len(HELDOUT_UNIT_ORDER) * n_groups * len(HELDOUT_POLICIES),
    }
    got_rows = {"units": len(units), "groups": len(groups),
                "counts": len(counts), "heldout": len(heldout)}
    if got_rows != expected_rows:
        raise RuntimeError(f"row count mismatch: got {got_rows}, expected {expected_rows}")
    for frame_name, frame in (("units", units), ("groups", groups),
                              ("counts", counts), ("heldout", heldout)):
        exact = {"ctx": CTX, "context_tokens": CONTEXT_TOKENS,
                 "protected_tail": WINDOW, "B": BUDGET, "maxb": MAXB,
                 "k0": K0}
        if "prefill_tokens" in frame:
            exact["prefill_tokens"] = PREFILL_TOKENS
        if "n_prompt_tokens" in frame:
            exact["n_prompt_tokens"] = CTX
        for col, want in exact.items():
            if not bool((frame[col] == want).all()):
                raise RuntimeError(f"{frame_name}.{col} drifted from {want}")
    if bool(units["synthetic"].any()) or bool(heldout["synthetic"].any()) \
            or not bool(units["full_integer_scan"].all()) \
            or not bool(groups["full_integer_scan"].all()) \
            or not bool(heldout["exact_checkpoint"].all()):
        raise RuntimeError("synthetic row or incomplete exact scan/checkpoint")
    _check_frame_finite(units, (
        "kstar", "kstar_frac", "E_kstar", "E_full", "threshold", "n95",
        "g1_max_abs", "g1_kstar", "builder_ctx", "pre_crop_tokens", "crop_offset", "special_prefix_tokens",
        "curve_seconds"), "units")
    _check_frame_finite(groups, (
        "kstar", "kstar_frac", "E_kstar", "E_full", "threshold", "n95_mean",
        "g1_max_abs", "g1_kstar"), "groups")
    _check_frame_finite(counts, (
        "kstar", "n95_mean", "count_fixed", "count_kstar_prop_calibrated",
        "count_kstar_shrink20_calibrated", "count_kappa4_rebalanced_calibrated",
        "count_kappa4_natural_calibrated", "count_adakv_alpha02_calibrated",
        "count_layer_flat_calibrated", "count_snapkv_global_calibrated"), "counts")
    _check_frame_finite(heldout, (
        "keep_count", "bits_per_context_token", "squared_relative_output_error",
        "n95", "builder_ctx", "pre_crop_tokens", "crop_offset",
        "special_prefix_tokens"), "heldout")
    if bool((units.kstar < 1).any()) or bool((units.kstar > K0).any()) \
            or bool((groups.kstar < 1).any()) or bool((groups.kstar > K0).any()):
        raise RuntimeError("K* outside 1..k0")
    if model_tag == "qwen15-moe-a2.7b":
        if not bool(units.g1_reference_available.all()) \
                or not bool(units.g1_kstar_match.all()) \
                or bool((units.g1_max_abs > 1e-10).any()) \
                or bool((units.g1_kstar < 1).any()) \
                or bool((units.g1_kstar > K0).any()):
            raise RuntimeError("Qwen per-unit G=1 reduction audit failed")
    elif bool(units.g1_reference_available.any()) \
            or bool(units.g1_kstar_match.any()) \
            or bool((units.g1_max_abs != 0).any()) \
            or bool((units.g1_kstar != 0).any()):
        raise RuntimeError("Llama carries noncanonical per-unit G=1 fields")

    expected_unit_keys = [
        (p, f, li, g) for p, f in CALIBRATION_UNIT_ORDER
        for li in range(geom["layers"]) for g in range(geom["kv_heads"])]
    if list(zip(units.prompt_idx, units.family, units.layer, units.kv_head)) != expected_unit_keys:
        raise RuntimeError("calibration unit row order/keys mismatch")
    expected_group_keys = [
        (split, li, g) for split in SPLITS
        for li in range(geom["layers"]) for g in range(geom["kv_heads"])]
    if list(zip(groups.split, groups.layer, groups.kv_head)) != expected_group_keys:
        raise RuntimeError("profile group row order/keys mismatch")
    expected_count_keys = [
        (li, g) for li in range(geom["layers"]) for g in range(geom["kv_heads"])]
    if list(zip(counts.layer, counts.kv_head)) != expected_count_keys:
        raise RuntimeError("frozen-count row order/keys mismatch")
    expected_heldout_keys = [
        (p, f, li, g, policy) for p, f in HELDOUT_UNIT_ORDER
        for li in range(geom["layers"]) for g in range(geom["kv_heads"])
        for policy in HELDOUT_POLICIES]
    if list(zip(heldout.prompt_idx, heldout.family, heldout.layer,
                heldout.kv_head, heldout.policy)) != expected_heldout_keys:
        raise RuntimeError("held-out row order/keys mismatch")

    with np.load(paths["curves"], allow_pickle=False) as z:
        if set(z.files) != {"curves", "g1_reference_curves", "split_names"}:
            raise RuntimeError("curve profile members mismatch")
        curves = z["curves"]
        g1_curves = z["g1_reference_curves"]
        split_names = z["split_names"].tolist()
    want_shape = (len(SPLITS), geom["layers"], geom["kv_heads"], K0)
    if curves.shape != want_shape or curves.dtype != np.float64 \
            or not np.isfinite(curves).all() or np.any(curves < 0):
        raise RuntimeError(f"invalid curve profile shape/dtype/values: {curves.shape}")
    if split_names != list(SPLITS):
        raise RuntimeError("curve split order mismatch")
    if model_tag == "qwen15-moe-a2.7b":
        if g1_curves.shape != want_shape or g1_curves.dtype != np.float64 \
                or not np.isfinite(g1_curves).all() or np.any(g1_curves < 0):
            raise RuntimeError("invalid Qwen G=1 reference profiles")
        if float(np.max(np.abs(curves - g1_curves))) > 1e-10:
            raise RuntimeError("Qwen physical-group curve differs from single-head reference")
    elif g1_curves.shape != (0, 0, 0, 0) or g1_curves.dtype != np.float64:
        raise RuntimeError("Llama must carry the canonical empty G=1 reference profile")

    for si, split in enumerate(SPLITS):
        block = groups[groups.split == split].reset_index(drop=True)
        for row_i, row in block.iterrows():
            curve = torch.from_numpy(curves[si, int(row.layer), int(row.kv_head)])
            scalars = curve_scalars(curve)
            for col in ("kstar", "kstar_frac", "E_kstar", "E_full", "threshold"):
                if not math.isclose(float(row[col]), float(scalars[col]),
                                    rel_tol=1e-12, abs_tol=1e-14):
                    raise RuntimeError(f"{split} row {row_i}: curve/{col} mismatch")
            if model_tag == "qwen15-moe-a2.7b":
                ref = torch.from_numpy(g1_curves[si, int(row.layer), int(row.kv_head)])
                ref_kstar = GEC.exact_kstar(
                    ref, K0, tolerance=KSTAR_TOLERANCE, atol=KSTAR_ATOL)
                max_abs = float(torch.max(torch.abs(curve - ref)))
                if not bool(row.g1_reference_available) or not bool(row.g1_kstar_match) \
                        or int(row.g1_kstar) != ref_kstar \
                        or not math.isclose(float(row.g1_max_abs), max_abs,
                                            rel_tol=0.0, abs_tol=1e-15):
                    raise RuntimeError("Qwen G=1 row/profile audit mismatch")
            elif bool(row.g1_reference_available):
                raise RuntimeError("Llama row incorrectly claims a G=1 reference")

    matched_frozen = [p for p in FROZEN_POLICIES if "natural" not in p]
    for policy in matched_frozen:
        col = "count_" + policy
        x = counts[col].to_numpy(dtype=np.int64)
        lower = 0 if policy in {
            "adakv_alpha02_calibrated", "layer_flat_calibrated",
            "snapkv_global_calibrated"} else 1
        if x.sum() != n_groups * K0 or np.any(x < lower) or np.any(x > CONTEXT_TOKENS):
            raise RuntimeError(f"frozen {policy} budget/bounds mismatch")
    natural = counts.count_kappa4_natural_calibrated.to_numpy(dtype=np.int64)
    if natural.sum() > n_groups * K0 or np.any(natural < 1) \
            or np.any(natural > CONTEXT_TOKENS):
        raise RuntimeError("frozen natural-kappa budget/bounds mismatch")
    frozen_lookup = {
        policy: counts["count_" + policy].to_numpy(dtype=np.int64)
        for policy in FROZEN_POLICIES}
    for (prompt_idx, family), unit in heldout.groupby(
            ["prompt_idx", "family"], sort=False, observed=True):
        for policy, block in unit.groupby("policy", sort=False, observed=True):
            block = block.reset_index(drop=True)
            x = block.keep_count.to_numpy(dtype=np.int64)
            if policy in FROZEN_POLICIES and not np.array_equal(x, frozen_lookup[policy]):
                raise RuntimeError(f"p{prompt_idx}/{family}: calibrated {policy} count drift")
            total = int(x.sum())
            matched = policy not in {
                "kappa4_natural_calibrated", "kappa4_natural_dynamic"}
            if matched and total != n_groups * K0:
                raise RuntimeError(f"p{prompt_idx}/{family}/{policy}: budget mismatch")
            if not matched and total > n_groups * K0:
                raise RuntimeError(f"p{prompt_idx}/{family}/{policy}: natural rule overspent")
            if not bool((block.budget_matched == matched).all()):
                raise RuntimeError(f"p{prompt_idx}/{family}/{policy}: budget flag mismatch")
    return summary


def _assert_shared_haystack(prompt_records: Sequence[Mapping[str, Any]]) -> None:
    if [(r["prompt_idx"], r["family"]) for r in prompt_records] != list(UNIT_ORDER):
        raise RuntimeError("prompt provenance is not in canonical prompt/family order")
    for prompt_idx in PROMPT_IDS:
        block = [r for r in prompt_records if r["prompt_idx"] == prompt_idx]
        for field in ("builder_ctx", "corpus_sha", "corpus_doc", "corpus_offset",
                      "corpus_spliced"):
            if len({r[field] for r in block}) != 1:
                raise RuntimeError(
                    f"p{prompt_idx}: cross-family shared-haystack field {field} differs")
        if block[0]["builder_ctx"] != BUILDER_CTX:
            raise RuntimeError(f"p{prompt_idx}: builder_ctx is not frozen to {BUILDER_CTX}")


def _capture_checks(family: str, prompt_idx: int, n: int, past: Any,
                    geometry: Mapping[str, int]) -> int:
    L0 = C.cache_len(past)
    if n != CTX or L0 != PREFILL_TOKENS or C.STATE.ctx_len != CONTEXT_TOKENS:
        raise RuntimeError(
            f"p{prompt_idx}/{family}: n/L0/C={n}/{L0}/{C.STATE.ctx_len}, "
            f"expected {CTX}/{PREFILL_TOKENS}/{CONTEXT_TOKENS}")
    expected_layers = set(range(int(geometry["layers"])))
    for label, captured in (("score", C.STATE.score), ("score_h", C.STATE.score_h),
                            ("qwin", C.STATE.qwin), ("scaling", C.STATE.scaling)):
        if set(captured) != expected_layers:
            raise RuntimeError(f"p{prompt_idx}/{family}: incomplete {label} capture")
    return L0


def _cleanup_prompt() -> None:
    C.STATE.reset_prompt()
    gc.collect()
    torch.cuda.empty_cache()


def run(model_tag: str, config_path: str, model_source: str, out_dir: str,
        source_ledger: str, input_manifest: str) -> None:
    if model_tag not in MODELS:
        raise ValueError(f"--model must be one of {sorted(MODELS)}")
    out = Path(out_dir)
    if out.exists():
        raise RuntimeError(f"refusing to reuse existing output directory: {out}")
    versions = validate_runtime_dependencies()
    ledger_attestation = verify_source_ledger(source_ledger)
    start_sources = source_hashes()
    quantizer_cache = validate_quantizer_cache()
    config_path = str(Path(config_path).resolve())
    cfg = validate_registry_config(config_path, model_tag)
    snapshot = resolve_model_snapshot(model_tag, model_source)
    corpus = prompts.resolve_corpus_dir(os.environ.get("H0_CORPUS"))
    if corpus is None:
        raise RuntimeError("qualification requires a real H0_CORPUS")
    input_attestation = verify_input_manifest(
        input_manifest, model_tag, snapshot, corpus)
    corpus_id = prompts.corpus_sha(corpus)
    if not corpus_id or corpus_id != PG19_CORPUS_SHA:
        raise RuntimeError("H0_CORPUS has no stable frozen corpus hash")
    out.mkdir(parents=True, mode=0o750)

    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(str(snapshot), trust_remote_code=True,
                                        local_files_only=True)
    if not getattr(tok, "is_fast", False):
        raise RuntimeError("qualification requires a fast tokenizer")
    if len(tok("tokenizer health check", add_special_tokens=False).input_ids) == 0:
        raise RuntimeError("tokenizer health check encoded zero tokens")
    pf = prompts.preflight(
        tok, BUILDER_CTX, corpus, require_real=True, n_prompts=len(PROMPT_IDS))
    if pf.get("synthetic") or pf.get("corpus_sha") != corpus_id:
        raise RuntimeError("real-corpus preflight failed or corpus identity drifted")

    C.install()
    dtype = getattr(torch, str(cfg.get("dtype", "bfloat16")))
    model = AutoModelForCausalLM.from_pretrained(
        str(snapshot), dtype=dtype, device_map=cfg.get("device_map", "auto"),
        attn_implementation=C.IMPL, trust_remote_code=True,
        local_files_only=True).eval()
    placement = assert_full_cuda(model)
    geometry = validate_live_geometry(model.config, model_tag)
    model_config_sha = canonical_sha256(model.config.to_dict())
    dev = next(model.parameters()).device
    rotation = quant.random_rotation(
        geometry["head_dim"], dev, torch.float32,
        seed=int(cfg["rot_seed"]))
    levels8 = quant.levels_for(MAXB, dev)
    rotation_attestation = float32_tensor_attestation(rotation)
    levels8_attestation = float32_tensor_attestation(levels8)
    if levels8_attestation != {
        "shape": [256], "dtype": "float32", "sha256": QUANTIZER_LEVEL8_SHA256}:
        raise RuntimeError("live 8-bit quantizer levels differ from the sealed cache")
    cuda_attestation = cuda_environment(dev)
    chunk = int(cfg["chunk"])
    print(
        f"R9 K* qualification model={model_tag} ctx={CTX} builder_ctx={BUILDER_CTX} "
        f"prefill={PREFILL_TOKENS} C={CONTEXT_TOKENS} W={WINDOW} "
        f"B={BUDGET} maxb={MAXB} k0={K0} calibration={CALIBRATION_PROMPT_IDS} "
        f"heldout={HELDOUT_PROMPT_IDS} geometry={geometry}", flush=True)

    curve_shape = (geometry["layers"], geometry["kv_heads"], K0)
    score_shape = (geometry["layers"], geometry["kv_heads"], CONTEXT_TOKENS)
    curve_sums = {split: torch.zeros(curve_shape, dtype=torch.float64) for split in SPLITS}
    # Qwen1.5-MoE is the frozen n_rep=1 control.
    is_g1 = geometry["query_heads"] // geometry["kv_heads"] == 1
    g1_sums = ({split: torch.zeros(curve_shape, dtype=torch.float64) for split in SPLITS}
               if is_g1 else None)
    n95_sums = {split: torch.zeros(curve_shape[:2], dtype=torch.float64) for split in SPLITS}
    split_n = {split: 0 for split in SPLITS}
    calibration_score_sum = torch.zeros(score_shape, dtype=torch.float64)
    unit_rows: list[dict[str, Any]] = []
    prompt_records: list[dict[str, Any]] = []
    all_t0 = time.time()

    # ---------------- calibration: dense K=1..k0 profiles, prompts 0 and 1 only
    for prompt_idx, family in CALIBRATION_UNIT_ORDER:
        ids_cpu, provenance = build_exact_prompt(tok, family, prompt_idx, corpus, CTX)
        if provenance["corpus_sha"] != corpus_id:
            raise RuntimeError(f"p{prompt_idx}/{family}: corpus identity changed")
        ids = ids_cpu.to(dev)
        t0 = time.time()
        with torch.no_grad():
            past, n = run_r8.prefill(model, ids, WINDOW, chunk, h2o=False)
        prefill_seconds = time.time() - t0
        L0 = _capture_checks(family, prompt_idx, n, past, geometry)
        pooled_scores, raw_scores = captured_snapkv_scores(geometry)
        for li in range(geometry["layers"]):
            calibration_score_sum[li].add_(pooled_scores[li].detach().cpu().double())
        unit_splits = ["calibration", "cal_p0" if prompt_idx == 0 else "cal_p1"]
        prompt_records.append({
            "prompt_idx": prompt_idx, "family": family, **provenance,
            "n_prompt_tokens": n, "prefill_tokens": L0,
            "context_tokens": int(C.STATE.ctx_len), "prefill_seconds": prefill_seconds,
        })
        for split in unit_splits:
            split_n[split] += 1

        for li in range(geometry["layers"]):
            pooled_order, n95 = canonical_order_n95_from_scores(
                pooled_scores[li], raw_scores[li],
                expected_kv_heads=geometry["kv_heads"])
            lc = router.build_layer_ctx(
                li, past, rotation, [MAXB], norm_correct=True, need_noise=False)
            if lc.n_rep != geometry["query_heads"] // geometry["kv_heads"]:
                raise RuntimeError(f"layer {li}: invalid n_rep={lc.n_rep}")
            if tuple(lc.Kc.shape[:2]) != (geometry["kv_heads"], CONTEXT_TOKENS) \
                    or tuple(lc.Kw.shape[:2]) != (geometry["kv_heads"], WINDOW):
                raise RuntimeError(f"layer {li}: invalid cache partition")
            order_check, n95_check = canonical_order_and_n95(lc)
            if not torch.equal(pooled_order, order_check) or not torch.equal(n95, n95_check):
                raise RuntimeError(f"layer {li}: captured score and LayerCtx disagree")
            for g in range(geometry["kv_heads"]):
                tc = time.time()
                full, qctx, values = group_inputs(lc, g)
                curve = GEC.dense_group_error_curve(
                    full, qctx, values, pooled_order[g], k_max=K0,
                    chunk_size=CURVE_CHUNK, eps=KSTAR_ATOL).detach().cpu().double()
                if curve.shape != (K0,) or not bool(torch.isfinite(curve).all()) \
                        or bool((curve < 0).any()):
                    raise RuntimeError("dense group curve is invalid")
                reference = None
                if is_g1:
                    reference = independent_single_head_curve(
                        full, qctx, values, pooled_order[g], k_max=K0
                    ).detach().cpu().double()
                    g1_max_abs = float(torch.max(torch.abs(curve - reference)))
                    g1_kstar = int(curve_scalars(reference)["kstar"])
                    if g1_max_abs > 1e-10:
                        raise RuntimeError(
                            f"p{prompt_idx}/{family}/l{li}/g{g}: G=1 max abs {g1_max_abs}")
                else:
                    g1_max_abs, g1_kstar = 0.0, 0
                elapsed = time.time() - tc
                scalar = curve_scalars(curve)
                g1_kstar_match = bool(reference is not None and
                                      g1_kstar == int(scalar["kstar"]))
                if reference is not None and not g1_kstar_match:
                    raise RuntimeError(
                        f"p{prompt_idx}/{family}/l{li}/g{g}: G=1 K* mismatch")
                for split in unit_splits:
                    curve_sums[split][li, g].add_(curve)
                    n95_sums[split][li, g] += int(n95[g])
                    if reference is not None:
                        assert g1_sums is not None
                        g1_sums[split][li, g].add_(reference)
                unit_rows.append({
                    "protocol": PROTOCOL, "runner_version": RUNNER_VERSION,
                    "profile_version": PROFILE_VERSION, "ranking_version": RANKING_VERSION,
                    "loss_version": LOSS_VERSION, "model": model_tag,
                    "model_id": MODELS[model_tag]["id"], "family": family,
                    "prompt_idx": prompt_idx, "half": prompt_idx,
                    "layer": li, "kv_head": g, "n_rep": lc.n_rep, "ctx": CTX,
                    "n_prompt_tokens": n, "prefill_tokens": L0,
                    "context_tokens": CONTEXT_TOKENS, "protected_tail": WINDOW,
                    "B": BUDGET, "maxb": MAXB, "k0": K0,
                    "kstar_tolerance": KSTAR_TOLERANCE, "kstar_atol": KSTAR_ATOL,
                    "full_integer_scan": True, **scalar, "n95": int(n95[g]),
                    "g1_reference_available": is_g1, "g1_max_abs": g1_max_abs,
                    "g1_kstar": g1_kstar, "g1_kstar_match": g1_kstar_match,
                    **provenance, "curve_seconds": elapsed,
                })
                del full, qctx, values
            del lc
        del past, ids, pooled_scores, raw_scores, pooled_order, order_check
        _cleanup_prompt()
        print(
            f"  calibration p{prompt_idx}/{family}: prefill={prefill_seconds:.1f}s "
            f"elapsed={time.time() - all_t0:.1f}s", flush=True)

    expected_split_n = {"calibration": 6, "cal_p0": 3, "cal_p1": 3}
    if split_n != expected_split_n:
        raise RuntimeError(f"calibration split unit counts mismatch: {split_n}")
    averaged_curves: dict[str, torch.Tensor] = {}
    averaged_g1: dict[str, torch.Tensor] = {}
    averaged_n95: dict[str, torch.Tensor] = {}
    split_kstars: dict[str, torch.Tensor] = {}
    split_core_counts: dict[str, dict[str, torch.Tensor]] = {}
    group_rows: list[dict[str, Any]] = []

    for split, prompt_ids in SPLITS.items():
        curves = curve_sums[split] / split_n[split]
        n95_mean = n95_sums[split] / split_n[split]
        if not bool(torch.isfinite(curves).all()) or not bool(torch.isfinite(n95_mean).all()):
            raise RuntimeError(f"{split}: nonfinite averaged profile")
        refs = g1_sums[split] / split_n[split] if is_g1 else None
        kstars = torch.empty(curve_shape[:2], dtype=torch.long)
        scalars: dict[tuple[int, int], dict[str, Any]] = {}
        for li in range(geometry["layers"]):
            for g in range(geometry["kv_heads"]):
                scalar = curve_scalars(curves[li, g])
                scalars[(li, g)] = scalar
                kstars[li, g] = scalar["kstar"]
        core_counts = policy_counts(kstars, n95_mean, geometry)
        averaged_curves[split] = curves
        averaged_n95[split] = n95_mean
        split_kstars[split] = kstars
        split_core_counts[split] = core_counts
        if refs is not None:
            averaged_g1[split] = refs
        for li in range(geometry["layers"]):
            for g in range(geometry["kv_heads"]):
                if refs is not None:
                    max_abs = float(torch.max(torch.abs(curves[li, g] - refs[li, g])))
                    ref_kstar = int(GEC.exact_kstar(
                        refs[li, g], K0, tolerance=KSTAR_TOLERANCE,
                        atol=KSTAR_ATOL))
                    ref_match = ref_kstar == int(kstars[li, g])
                else:
                    max_abs, ref_kstar, ref_match = 0.0, 0, False
                group_rows.append({
                    "protocol": PROTOCOL, "runner_version": RUNNER_VERSION,
                    "profile_version": PROFILE_VERSION, "ranking_version": RANKING_VERSION,
                    "loss_version": LOSS_VERSION, "policy_version": POLICY_VERSION,
                    "model": model_tag, "model_id": MODELS[model_tag]["id"],
                    "split": split, "split_prompt_ids": json.dumps(list(prompt_ids)),
                    "n_units": split_n[split], "layer": li, "kv_head": g,
                    "n_rep": geometry["query_heads"] // geometry["kv_heads"],
                    "ctx": CTX, "prefill_tokens": PREFILL_TOKENS,
                    "context_tokens": CONTEXT_TOKENS, "protected_tail": WINDOW,
                    "B": BUDGET, "maxb": MAXB, "k0": K0,
                    "kstar_tolerance": KSTAR_TOLERANCE, "kstar_atol": KSTAR_ATOL,
                    "full_integer_scan": True, **scalars[(li, g)],
                    "n95_mean": float(n95_mean[li, g]),
                    "g1_reference_available": is_g1, "g1_max_abs": max_abs,
                    "g1_kstar": ref_kstar, "g1_kstar_match": ref_match,
                })

    calibration_scores = {
        li: (calibration_score_sum[li] / expected_split_n["calibration"]).float()
        for li in range(geometry["layers"])}
    frozen_counts = freeze_calibrated_counts(
        split_kstars["calibration"], averaged_n95["calibration"],
        calibration_scores, geometry)
    if tuple(frozen_counts) != FROZEN_POLICIES:
        raise RuntimeError("frozen policy order drift")
    count_rows = []
    for li in range(geometry["layers"]):
        for g in range(geometry["kv_heads"]):
            count_rows.append({
                "protocol": PROTOCOL, "runner_version": RUNNER_VERSION,
                "policy_version": POLICY_VERSION, "model": model_tag,
                "model_id": MODELS[model_tag]["id"], "layer": li,
                "kv_head": g, "n_rep": geometry["query_heads"] // geometry["kv_heads"],
                "ctx": CTX, "context_tokens": CONTEXT_TOKENS,
                "protected_tail": WINDOW, "B": BUDGET, "maxb": MAXB, "k0": K0,
                "calibration_prompt_ids": json.dumps(list(CALIBRATION_PROMPT_IDS)),
                "calibration_units": expected_split_n["calibration"],
                "kstar": int(split_kstars["calibration"][li, g]),
                "n95_mean": float(averaged_n95["calibration"][li, g]),
                **{"count_" + policy: int(frozen_counts[policy][li, g])
                   for policy in FROZEN_POLICIES},
            })

    # ------------- heldout: prompts 2/3 never affect profiles or frozen counts
    heldout_rows: list[dict[str, Any]] = []
    heldout_policy_totals: dict[tuple[int, str], dict[str, int]] = {}
    for prompt_idx, family in HELDOUT_UNIT_ORDER:
        ids_cpu, provenance = build_exact_prompt(tok, family, prompt_idx, corpus, CTX)
        if provenance["corpus_sha"] != corpus_id:
            raise RuntimeError(f"p{prompt_idx}/{family}: corpus identity changed")
        ids = ids_cpu.to(dev)
        t0 = time.time()
        with torch.no_grad():
            past, n = run_r8.prefill(model, ids, WINDOW, chunk, h2o=False)
        prefill_seconds = time.time() - t0
        L0 = _capture_checks(family, prompt_idx, n, past, geometry)
        pooled_scores, raw_scores = captured_snapkv_scores(geometry)
        orders, n95_by_layer = {}, torch.empty(curve_shape[:2], dtype=torch.long)
        for li in range(geometry["layers"]):
            orders[li], n95 = canonical_order_n95_from_scores(
                pooled_scores[li], raw_scores[li],
                expected_kv_heads=geometry["kv_heads"])
            n95_by_layer[li] = n95.detach().cpu()
        dynamic_counts = heldout_dynamic_counts(n95_by_layer, pooled_scores, geometry)
        all_counts = {**frozen_counts, **dynamic_counts}
        if tuple(all_counts) != HELDOUT_POLICIES:
            raise RuntimeError("held-out policy order drift")
        n_groups = geometry["layers"] * geometry["kv_heads"]
        target = n_groups * K0
        totals = {policy: int(value.sum()) for policy, value in all_counts.items()}
        for policy, total in totals.items():
            natural = policy in {
                "kappa4_natural_calibrated", "kappa4_natural_dynamic"}
            if (not natural and total != target) or (natural and total > target):
                raise RuntimeError(f"p{prompt_idx}/{family}/{policy}: invalid total {total}")
        heldout_policy_totals[(prompt_idx, family)] = totals
        prompt_records.append({
            "prompt_idx": prompt_idx, "family": family, **provenance,
            "n_prompt_tokens": n, "prefill_tokens": L0,
            "context_tokens": int(C.STATE.ctx_len), "prefill_seconds": prefill_seconds,
        })

        for li in range(geometry["layers"]):
            lc = router.build_layer_ctx(
                li, past, rotation, [MAXB], norm_correct=True, need_noise=False)
            order_check, n95_check = canonical_order_and_n95(lc)
            if not torch.equal(orders[li], order_check) \
                    or not torch.equal(n95_by_layer[li], n95_check.cpu()):
                raise RuntimeError(f"heldout layer {li}: capture/LayerCtx score disagreement")
            for g in range(geometry["kv_heads"]):
                full, qctx, values = group_inputs(lc, g)
                requested = [int(all_counts[p][li, g]) for p in HELDOUT_POLICIES]
                losses = GEC.group_error_checkpoints(
                    full, qctx, values, orders[li][g], requested,
                    eps=KSTAR_ATOL)
                if len(losses) != len(requested):
                    raise RuntimeError("checkpoint evaluator returned the wrong length")
                for policy_order, (policy, keep, loss) in enumerate(
                        zip(HELDOUT_POLICIES, requested, losses)):
                    error = float(loss)
                    if not math.isfinite(error) or error < 0:
                        raise RuntimeError("held-out checkpoint error is nonfinite/negative")
                    natural = policy in {
                        "kappa4_natural_calibrated", "kappa4_natural_dynamic"}
                    heldout_rows.append({
                        "protocol": PROTOCOL, "runner_version": RUNNER_VERSION,
                        "profile_version": PROFILE_VERSION,
                        "ranking_version": RANKING_VERSION,
                        "loss_version": LOSS_VERSION, "policy_version": POLICY_VERSION,
                        "model": model_tag, "model_id": MODELS[model_tag]["id"],
                        "family": family, "prompt_idx": prompt_idx, "layer": li,
                        "kv_head": g, "n_rep": lc.n_rep, "policy": policy,
                        "policy_order": policy_order,
                        "calibrated": policy in FROZEN_POLICIES,
                        "dynamic": policy in DYNAMIC_POLICIES,
                        "ctx": CTX, "n_prompt_tokens": n, "prefill_tokens": L0,
                        "context_tokens": CONTEXT_TOKENS, "protected_tail": WINDOW,
                        "B": BUDGET, "maxb": MAXB, "k0": K0,
                        "keep_count": keep,
                        "bits_per_context_token": keep * MAXB / CONTEXT_TOKENS,
                        "budget_matched": not natural, "exact_checkpoint": True,
                        "squared_relative_output_error": error,
                        "n95": int(n95_by_layer[li, g]), **provenance,
                    })
                del full, qctx, values, losses
            del lc
        del past, ids, pooled_scores, raw_scores, orders
        _cleanup_prompt()
        print(
            f"  heldout p{prompt_idx}/{family}: prefill={prefill_seconds:.1f}s "
            f"elapsed={time.time() - all_t0:.1f}s", flush=True)

    _assert_shared_haystack(prompt_records)
    # Reauthenticate every mutable execution input before any artifact bytes are
    # committed.  This repeats full selected-snapshot and all-corpus hashing.
    if start_sources != source_hashes():
        raise RuntimeError("qualification source changed during inference")
    if ledger_attestation != verify_source_ledger(source_ledger):
        raise RuntimeError("source ledger changed during inference")
    if input_attestation != verify_input_manifest(
            input_manifest, model_tag, snapshot, corpus):
        raise RuntimeError("qualification input manifest changed during inference")
    if quantizer_cache != validate_quantizer_cache():
        raise RuntimeError("quantizer cache changed during inference")
    if rotation_attestation != float32_tensor_attestation(rotation):
        raise RuntimeError("rotation tensor changed during inference")
    if levels8_attestation != float32_tensor_attestation(levels8):
        raise RuntimeError("live 8-bit quantizer levels changed during inference")
    if cuda_attestation != cuda_environment(dev):
        raise RuntimeError("CUDA numerical environment changed during inference")

    units_df = pd.DataFrame(unit_rows, columns=UNIT_COLUMNS)
    groups_df = pd.DataFrame(group_rows, columns=GROUP_COLUMNS)
    counts_df = pd.DataFrame(count_rows, columns=COUNT_COLUMNS)
    heldout_df = pd.DataFrame(heldout_rows, columns=HELDOUT_COLUMNS)
    units_path = out / "kstar_budget_units.parquet"
    groups_path = out / "kstar_budget_groups.parquet"
    counts_path = out / "kstar_budget_frozen_counts.parquet"
    heldout_path = out / "kstar_budget_heldout.parquet"
    curves_path = out / "kstar_budget_curves.npz"
    _atomic_parquet(units_df, units_path)
    _atomic_parquet(groups_df, groups_path)
    _atomic_parquet(counts_df, counts_path)
    _atomic_parquet(heldout_df, heldout_path)
    curve_array = np.stack(
        [averaged_curves[split].numpy() for split in SPLITS], axis=0).astype(np.float64)
    g1_array = (np.stack([averaged_g1[split].numpy() for split in SPLITS], axis=0)
                .astype(np.float64) if is_g1 else np.empty((0, 0, 0, 0), dtype=np.float64))
    _atomic_npz(curves_path, curves=curve_array, g1_reference_curves=g1_array,
                split_names=np.asarray(list(SPLITS), dtype="U16"))

    heldout_summary = {}
    for policy in HELDOUT_POLICIES:
        block = heldout_df[heldout_df.policy == policy]
        values = block.squared_relative_output_error.to_numpy(dtype=np.float64)
        heldout_summary[policy] = {
            "rows": len(block), "mean_error": float(values.mean()),
            "median_error": float(np.median(values)),
            "q90_error": float(np.quantile(values, 0.90, method="linear")),
            "calibrated": policy in FROZEN_POLICIES,
            "dynamic": policy in DYNAMIC_POLICIES,
        }
    summary = {
        "protocol": PROTOCOL,
        "runner_version": RUNNER_VERSION,
        "model": model_tag,
        "model_id": MODELS[model_tag]["id"],
        "experiment_config": experiment_config(model_tag),
        "experiment_config_sha256": canonical_sha256(experiment_config(model_tag)),
        "models_yaml_sha256": file_sha256(config_path),
        "model_config_sha256": model_config_sha,
        "effective_registry": {
            key: cfg[key] for key in (
                "dtype", "device_map", "chunk", "norm_correct", "rot_seed", "maxb")},
        "input_manifest": input_attestation,
        "model_snapshot": input_attestation["model_snapshots"][model_tag],
        "quantizer_cache": quantizer_cache,
        "quantizer_levels8": levels8_attestation,
        "rotation": rotation_attestation,
        "cuda_environment": cuda_attestation,
        "placement": placement,
        "corpus_sha": corpus_id,
        "corpus_preflight": pf,
        "prompt_records": prompt_records,
        "source_ledger": ledger_attestation,
        "source_hashes": start_sources,
        "source_set_sha256": canonical_sha256(start_sources),
        "runtime_versions": versions,
        "row_counts": {"units": len(units_df), "groups": len(groups_df),
                       "counts": len(counts_df), "heldout": len(heldout_df)},
        "profile_shape": list(curve_array.shape),
        "g1_reference_shape": list(g1_array.shape),
        "g1_unit_audit": {
            "reference_available": is_g1,
            "rows": len(units_df),
            "max_abs": float(units_df.g1_max_abs.max()),
            "all_kstar_match": bool(units_df.g1_kstar_match.all()) if is_g1 else False,
        },
        "frozen_policy_summaries": policy_summary(frozen_counts),
        "calibration_profile_stability": stability_summary(
            split_kstars, split_core_counts),
        "heldout_policy_summaries": heldout_summary,
        "heldout_policy_totals": {
            f"p{p}:{family}": totals
            for (p, family), totals in heldout_policy_totals.items()},
        "elapsed_seconds": time.time() - all_t0,
        "artifact_sha256": {
            "units": file_sha256(units_path),
            "groups": file_sha256(groups_path),
            "counts": file_sha256(counts_path),
            "heldout": file_sha256(heldout_path),
            "curves": file_sha256(curves_path),
        },
    }
    summary_path = out / "kstar_budget_summary.json"
    _atomic_json(summary, summary_path)
    validate_artifacts(
        out, model_tag, source_ledger, input_manifest, model_source,
        verify_environment=False)
    print(f"validated {out} ({time.time() - all_t0:.1f}s)", flush=True)

def main(argv: Sequence[str] | None = None) -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", required=True, choices=tuple(MODELS))
    ap.add_argument("--config", default=str(HERE / "models.yaml"))
    ap.add_argument("--model-source", default="",
                    help="exact pinned local snapshot; defaults to HF_HOME/hub")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--source-ledger", required=True)
    ap.add_argument(
        "--input-manifest", default=str(ROOT / INPUT_MANIFEST_RELATIVE),
        help="canonical frozen corpus/model byte inventory")
    ap.add_argument("--validate-only", action="store_true",
                    help="validate existing label-free artifacts; load no model")
    args = ap.parse_args(argv)
    if args.validate_only:
        validate_artifacts(
            args.out_dir, args.model, args.source_ledger, args.input_manifest,
            args.model_source, verify_environment=True)
        print(f"PASS {PROTOCOL} validate-only model={args.model} out={args.out_dir}")
        return
    run(args.model, args.config, args.model_source, args.out_dir,
        args.source_ledger, args.input_manifest)


if __name__ == "__main__":
    main()
